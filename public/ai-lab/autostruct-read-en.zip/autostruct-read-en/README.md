# autostruct-read-en

Claude skill that reads **Auto Market Structure & Liquidity by [Itto-Ryu]** on 1H / 4H / 1D / 1W from price data
and writes an English structure report (plain text + one HTML page with a structure map). v0.2 adds the indicator's v5 volume layers (order blocks, leg volume profile, Smart POC levels) when the bars carry volume. v0.3 (indicator v5.3) is wording only: the Bottom-out areas are described as recovery depth of the down leg, not Fibonacci support.
Describes state only. MPL-2.0. See SKILL.md.
