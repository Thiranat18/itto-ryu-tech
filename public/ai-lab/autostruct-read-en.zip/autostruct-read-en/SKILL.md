---
name: autostruct-read-en
description: Read Auto Market Structure & Liquidity (Auto Structure) on 1H/4H/D/W for a symbol (e.g. "autostruct-read-en BTCUSD") and report the structure by principle as an English plain-text summary plus an HTML page with a structure map. Works with the TradingView connector or CSV files. Describes state only, never buy/sell advice.
license: MPL-2.0
---

# autostruct-read-en (v0.5, quick + full mode, English edition)

Companion skill for the TradingView indicator **Auto Market Structure & Liquidity by [Itto-Ryu]** (v5.3).
Give it a symbol and it rebuilds the indicator's structure readings from price data on 1H, 4H, 1D and 1W:
Dow structure with BOS / CHoCH, the Protected level, the Fibonacci leg, the Bottom-out areas (recovery depth of a down leg), the
liquidity zones with sweeps, and (when the bars carry volume) the v5 volume layers: order blocks with the volume
traded inside them, the leg volume profile (POC, 70% value area) and Smart POC levels. v0.4 adds three descriptive
readings: timeframe alignment with the chart timeframe nested in the next higher leg, the distance to every state-change
level in ATR (this timeframe and the 1D ATR), and the age and size of the current leg against the symbol's own swing legs.
**Full mode** (v0.5, `... full`) also rebuilds the indicator's 12-state dashboard: 待 WAIT / 構 READY / 流 TREND state with its Reason
(momentum, Efficiency Ratio, ATR rank), HTF flag, Move, Levels and Preset rows, from about a year of bars per timeframe.
Then it explains the state by principle. The user makes every decision. This
skill never tells anyone to buy, sell, enter, exit, or where to put a stop or target.

Python 3 standard library only; nothing is downloaded at run time.

```
SKILL.md
config.yaml                defaults: chart TF, swing size, style, symbol defaults
references/principles.md   structure principles (mirror the indicator source)
scripts/ohlcv_to_data.py   TradingView OHLCV results -> data.json
scripts/compute.py         data.json -> astr.json (port of the Pine structure engine, closed bars only)
scripts/render.py          astr.json (+ chart read) -> report.html + report.txt
scripts/lint_report.py     blocks advice language before anything is shown
tests/selftest.py          synthetic self-test: python3 -I tests/selftest.py (run after any change)

Full mode also reads the dashboard state from the chart when the optional chart read (§5) is used, and the parity line then compares the state cell too.
```

## 1. Understand the request

`autostruct-read-en <SYMBOL> [chart TF] [swing K] [quick|full]` — e.g. `autostruct-read-en BTCUSD`,
`autostruct-read-en OANDA:XAUUSD 4H`, `autostruct-read-en NYSE:BB 1D swing 2.5`, `autostruct-read-en S50 full`.
Plain words work too: "full" / "dashboard" / "states" / "แบบเต็ม" = full; "quick" / "ดูเร็วๆ" = quick.
English only. Defaults come from `config.yaml` (chart TF `1D`, swing 2.0 × ATR(14), Style Auto).
If the user's indicator uses another "Swing size (× ATR)" or Style, use the same values, otherwise the
levels will not match their chart.

**Modes.** `quick` (default): structure, Protected level, Fibonacci leg, Bottom-out, liquidity, volume layers, alignment, ATR distances,
leg age / size, 300 bars per TF. `full`: the same plus the **12-state dashboard** (state + group, Reason, HTF, Move, Levels,
Preset) with the indicator's defaults (Market Classic, Pullback ATR / Mid, ER 0.30, holds 3 / 3, smoothing 3); it needs about a year of bars,
so it fetches more (1H 2000 · 4H 800 · 1D 600 · 1W 300). The structure engine then runs on that longer window too, so swing-leg
percentiles and the volume histories can differ slightly from a quick run of the same day; the report says so. If the user's Market is Crypto
or FX & Gold, pass `--market`. If the user asks for states in quick mode, say in one line that `full` rebuilds them.

**First run.** Do not ask setup questions first (except an ambiguous symbol). Run with the defaults; the
report opens with a QUICK MODE box that shows the settings used and asks whether they match the chart.

## 2. Pick the input route (check silently, tell the user in one line)

| Route | When | What happens |
|---|---|---|
| **A. TradingView connector** (recommended) | an OHLCV tool is available (`get-ohlcv`) | fetch bars, compute everything |
| **B. CSV** | the user attaches TradingView CSV exports | convert to data.json, compute everything |
| **+ Chart read** (optional) | a TradingView desktop MCP that reads Pine tables, with Auto Structure on a chart of the same symbol | read the real Structure row and run the parity check |

If none is available, say which one would work and stop.

## 3. Route A — TradingView connector

1. **Resolve the symbol.** No exchange prefix: search for it; prefer `config.yaml` -> `symbol_defaults`.
2. **Fetch OHLCV** for `1h`, `4h`, `1D`, `1W` with `format: columns` and `count` **300 each in quick mode; 2000 / 800 / 600 / 300 in
   full mode** (the rank windows need about a year of bars). Keep the volume column (`v`): the volume layers need it; without it they are
   skipped and the report says so. A large result may be saved to a file by the host instead of shown inline: use that file as is.
3. **Save each result to a file exactly as returned** (`h1.json`, `h4.json`, `d.json`, `w.json`). If the host
   saved the tool result to a file, copy that file; never retype selected numbers.
4. **Data status.** Call the symbol-data tool for the same symbol with columns `close` and `update_mode` and keep
   `update_mode` (e.g. `streaming` = real-time, `delayed_streaming_900` = 15 min delayed on the user's plan).
5. `python3 -I scripts/ohlcv_to_data.py --symbol <SYMBOL> 1H=h1.json 4H=h4.json 1D=d.json 1W=w.json --out data.json`
6. `python3 -I scripts/compute.py --data data.json --chart-tf 1D --out astr.json [--swing-k 2.0] [--style Auto] [--closed 1D] [--mode full] [--market Classic]`
   Every reading uses the last **closed** bar, like the indicator. When the 1H feed has had no new bar for 3+ hours
   the session is over and the latest 1D bar counts as closed automatically (a lunch break is shorter; 24h markets
   never trigger it). `--closed 1D` forces it.

**Fresh data, every run.** The reader is a trader: always fetch new bars at the start of each run, never reuse
data files from an earlier run. The report header shows the last price and the time of the newest bar, the TF table
shows each TF's last closed bar, a forming bar is shown as a "Live … not a reading until the bar closes" line, and a
⚠ warning appears when the newest bar is more than 4 days old. If that warning shows, fetch again before replying.

## 4. Route B — CSV

Build one `{"bars": {"t","o","h","l","c"}}` file per TF from the CSV columns (time as unix seconds), then run
steps 5–6 above.

## 5. Optional chart read (desktop MCP)

Read only. Never change symbol, timeframe, layout, inputs or indicators; never edit or save a Pine script;
never create alerts or drawings. If the chart shows a different symbol or TF, skip this step. Otherwise call
the Pine-tables tool filtered to `Auto Market Structure`, write the rows exactly as returned into `raw.json`
(`{"rows": [...]}`), and pass `--chart-table raw.json` to `render.py`.

## 6. Render, check, deliver

1. `python3 -I scripts/render.py --astr astr.json [--chart-table raw.json] [--update-mode <update_mode>] --generated YYYY-MM-DD --out-html <SYMBOL>_autostruct_read.html --out-txt <SYMBOL>_autostruct_read.txt`
   The report adds a **Bottom-out zone** section with a candlestick chart for every TF in a Downtrend, saying
   whether the last close is below the Stable area, inside Stable, inside Confirm, or above Confirm (✓), and a
   **Volume layers** section when the data has volume: for every TF a chart of the current leg with the leg volume profile
   (24 price rows, POC, 70% value area), the live order blocks and the Smart POC levels, followed by the plain-language lines and
   a how-to-read note. In full mode a **Dashboard · 12 states** card follows the Summary: per TF the state strip of the last 120 closed bars
   and the rows State, State age, Reason, HTF, Move, Structure, Levels, Preset, with a how-to-read note.
2. If the parity line shows ⚠, check symbol, TF, swing size, Style and data before showing the report, and say what differed.
3. `python3 -I scripts/lint_report.py <html> <txt>` must PASS; if not, fix wording and render again.
4. Reply with the plain-text summary in the report's order: settings line and its question, structure snapshot
   (every TF, distance to its Protected level, how the TFs line up, and in the mixed case the alignment count), Summary of the chart TF
   (including the higher-TF sentence with the chart leg nested in the higher leg, and the leg age / size sentence), structure by TF
   (since CHoCH, BOS count, last swings, leg position, leg age, leg size), in full mode the dashboard per TF (state and group, bars in the
   state, Reason, HTF, Levels), recent events, what changes the structure on each TF
   (distances in ATR and ATR_D; "Nearest change" when a TF has more than one level),
   position in the down leg (Bottom-out), volume layers, both sides, learning note, disclaimer. Deliver the HTML as an artifact when the host
   supports that, otherwise as a file.

## 7. Guardrails (every run)

- Describe state by principle. Words: Uptrend / Downtrend / Sideways, BOS, CHoCH, Protected level, sweep; in full mode the state names
  (Volatile, Breakout Up, Breakdown, Pullback Up / Down, Compressed, Chop, Up, Down, Sideways Up / Down, Neutral) are names for what price
  has been doing on closed bars, never a signal. No buy/sell, long/short, entry, exit, stop, target, "should", or forecasts.
- State-change levels say "a close above / below X = CHoCH / BOS / ✓" and are labelled as describing state,
  not trade levels.
- If the user asks "should I buy/sell?", give the structure reading and hand the decision back in one sentence.
- Values are computed by the skill from price data; values read from a chart are labelled as such.
- Keep both sides equal in weight: what supports the current structure, and what would change it.
- Volume layers are reference levels that describe where the leg traded. Describe the evidence as the report does, without figures
  (Smart POC first test held more often than random levels; order blocks ≈ random; no magnet effect) and never call them turning points.
- The indicator's Next 10 bars row is not part of the report; do not quote it, even from a chart read.
- Always end with the disclaimer that `render.py` adds.
