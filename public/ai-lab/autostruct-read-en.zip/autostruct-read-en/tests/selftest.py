"""Self-test for autostruct-read-en. Synthetic data only; standard library only.
Run: python3 -I tests/selftest.py   (exit 0 = all checks pass)"""
import json, math, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(HERE, "..", "scripts")
sys.path.insert(0, SCRIPTS)
import compute, render  # noqa: E402

fails = []


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        fails.append(name)


def series(path, t0, step):
    """Bars that follow a list of close prices, with small wicks."""
    o, h, l, c, t = [], [], [], [], []
    prev = path[0]
    for k, p in enumerate(path):
        o.append(prev); c.append(p)
        h.append(max(prev, p) + 0.3); l.append(min(prev, p) - 0.3)
        t.append(t0 + k * step); prev = p
    v = [1000 + (k * 37) % 400 + (300 if abs(c[k] - o[k]) > 0.5 else 0) for k in range(len(c))]
    return {"t": t, "o": o, "h": h, "l": l, "c": c, "v": v}


def wave():
    """Rise 100 -> 140 with pullbacks, then a fall to 110 (CHoCH down + BOS), then a bounce to `end`."""
    p = []
    for a, b, n in ((100, 120, 30), (120, 112, 10), (112, 135, 30), (135, 126, 10), (126, 140, 25),
                    (140, 118, 25), (118, 124, 8), (124, 110, 20), (110, 114, 12)):
        p += [a + (b - a) * k / n for k in range(n)]
    return p


T0 = 1_700_000_000
H1 = 3600

# 1. pivot rule: ties allowed on the left, strict on the right
s = [1, 3, 3, 2, 1]
check("pivot: later of two equal highs is the pivot", compute.pivot(s, 4, 2, True) == 3)
s = [1, 2, 3, 3, 1]
check("pivot: equal high on the right blocks the pivot", compute.pivot(s, 4, 2, True) is None)

# 2. structure engine on synthetic data
d = {"symbol": "TEST:WAVE", "tfs": {tf: series(wave(), T0, sec) for tf, sec in (("1H", H1), ("4H", 4 * H1), ("1D", 86400), ("1W", 604800))}}
tmp = tempfile.mkdtemp()
dp, ap_, hp, tp = (os.path.join(tmp, x) for x in ("data.json", "astr.json", "r.html", "r.txt"))
json.dump(d, open(dp, "w"))
last_1h = d["tfs"]["1H"]["t"][-1]
run = lambda *a: subprocess.run([sys.executable, "-I", *a], capture_output=True, text=True)
now_open = f"{__import__('datetime').datetime.fromtimestamp(last_1h + 1800, __import__('datetime').timezone.utc).isoformat()}"
r = run(os.path.join(SCRIPTS, "compute.py"), "--data", dp, "--chart-tf", "1H", "--now", now_open, "--out", ap_)
check("compute runs", r.returncode == 0)
A = json.load(open(ap_))
R = A["tfs"]["1H"]
check("structure is Downtrend after the fall", R["structure"] == "Downtrend")
check("Protected level is above the last close", R["protected"] is not None and R["protected"] > R["close"])
check("Bottom-out areas exist on a Downtrend leg", bool(R["fib"]) and "bottom_out" in R["fib"])
check("swing sequence is labelled", all(x["label"] in ("H", "L", "HH", "LH", "HL", "LL") for x in R["swing_seq"]))
check("BOS count is a non-negative int", isinstance(R["bos_count"], int) and R["bos_count"] >= 0)

# 2b. volume layers (v5): leg profile, Smart POC, order blocks; skipped without volume
V = R["volume"]
check("volume layers computed when bars have volume", isinstance(V, dict) and set(V) == {"leg_profile", "smart_poc", "order_blocks"})
lp = V["leg_profile"]
check("leg profile has POC inside its value area", bool(lp) and lp["val"] <= lp["poc"] <= lp["vah"] and 0 < lp["poc_share"] <= 1)
check("smart POC levels carry volrel >= 1", all(z["volrel"] >= 1 and z["half"] > 0 for z in V["smart_poc"]))
check("order blocks are mid/high volume with top > bot", all(z["rank"] in ("mid", "high") and z["top"] > z["bot"] for z in V["order_blocks"]))
d_nov = {"symbol": "TEST:NOVOL", "tfs": {tf: {k: v_ for k, v_ in cols.items() if k != "v"} for tf, cols in d["tfs"].items()}}
dp2, ap2 = os.path.join(tmp, "data2.json"), os.path.join(tmp, "astr2.json")
json.dump(d_nov, open(dp2, "w"))
r2 = run(os.path.join(SCRIPTS, "compute.py"), "--data", dp2, "--chart-tf", "1H", "--now", now_open, "--out", ap2)
check("compute runs without volume", r2.returncode == 0 and json.load(open(ap2))["tfs"]["1H"]["volume"] is None)

# 3. closed-bar handling: forming 1H bar inside the session, session over 3h+ after the last 1H bar
check("forming 1H bar is not read", R["forming"] is True and R["last_closed"] == R["bars"] - 2)
check("session not over while 1H bars are fresh", A["session_over"] is False)
now_late = __import__("datetime").datetime.fromtimestamp(last_1h + 5 * H1, __import__("datetime").timezone.utc).isoformat()
run(os.path.join(SCRIPTS, "compute.py"), "--data", dp, "--chart-tf", "1H", "--now", now_late, "--out", ap_)
check("session over after 3h+ without a new 1H bar", json.load(open(ap_))["session_over"] is True)

# 4. Bottom-out position in all four states
b = R["fib"]["bottom_out"]
cases = {"below": min(b["stable"]) - 0.01, "Stable": sum(b["stable"]) / 2, "Confirm": sum(b["confirm"]) / 2, "above": max(b["confirm"]) + 0.01}
for want, c in cases.items():
    check(f"bottom-out position: {want}", render.bo_pos(dict(R, close=c)) == want)

# 5. data status words
check("update_mode streaming = real-time", render.data_mode("streaming") == "real-time")
check("update_mode delayed 900 = 15 min", render.data_mode("delayed_streaming_900").startswith("delayed 15 min"))

# 6. full render + lint, stale warning, sections
run(os.path.join(SCRIPTS, "compute.py"), "--data", dp, "--chart-tf", "1H", "--now", "2030-01-01T00:00:00+00:00", "--out", ap_)
r = run(os.path.join(SCRIPTS, "render.py"), "--astr", ap_, "--update-mode", "delayed_streaming_900", "--out-html", hp, "--out-txt", tp)
check("render runs", r.returncode == 0)
txt = open(tp).read()
html = open(hp).read()
for sec in ("STRUCTURE SNAPSHOT", "SUMMARY", "STRUCTURE BY TIMEFRAME", "WHAT CHANGES THE STRUCTURE", "POSITION IN THE DOWN LEG", "VOLUME LAYERS", "DISCLAIMER"):
    check(f"text report has {sec}", sec in txt)
check("stale data warning shown", "WARNING" in txt and "days old" in txt)
check("delayed data shown in header", "delayed 15 min" in txt.splitlines()[0])
check("HTML has the structure map", "<svg class='map'" in html)
check("HTML has the volume layers card", "Volume layers" in html and "Smart POC" in html)
check("v0.4.1 HTML has a volume-layers chart per TF with volume", html.count("volume layers on the current leg") == 4 and "How to read the chart" in html)
check("v0.4.1 leg profile rows are shares that sum to 1", bool(lp) and len(lp["rows"]) == 24 and abs(sum(lp["rows"]) - 1) < 1e-3)
hp2, tp2 = os.path.join(tmp, "r2.html"), os.path.join(tmp, "r2.txt")
run(os.path.join(SCRIPTS, "render.py"), "--astr", ap2, "--out-html", hp2, "--out-txt", tp2)
check("report without volume says the layers are skipped", "no volume" in open(tp2).read())
check("lint passes on the report", run(os.path.join(SCRIPTS, "lint_report.py"), hp, tp).returncode == 0)
bad = os.path.join(tmp, "bad.txt")
open(bad, "w").write("You should buy here, target 150.\n")
check("lint blocks advice wording", run(os.path.join(SCRIPTS, "lint_report.py"), bad).returncode != 0)

# 7. v0.4 readings: alignment, ATR distances, leg age / size (descriptive, additive)
al = A.get("alignment")
check("v0.4 alignment present with order/top/agree/disagree", bool(al) and al["top"] == "1W" and set(al["agree"]) | set(al["disagree"]) == set(al["order"]))
check("v0.4 nested reading names the next higher TF", bool(al and al["nested"]) and al["nested"]["chart_tf"] == "1H" and al["nested"]["higher_tf"] == "4H")
check("v0.4 change levels carry atr and atr_d", all("atr" in z and "atr_d" in z for z in R["change_levels"]) and R["change_levels"])
nc = R["nearest_change"]
check("v0.4 nearest change is the smallest ATR distance", nc is not None and abs(nc["atr"]) == min(abs(z["atr"]) for z in R["change_levels"] if z["atr"] is not None))
g = R["leg"]
check("v0.4 leg has bars and height_atr; percentile only with 8+ completed swing legs",
      bool(g) and g["bars"] == R["last_closed"] - R["protected_bar"] and g["height_atr"] > 0
      and ((g["height_pct"] is None) == (g["hist_n"] < 8)) and (g["height_pct"] is None or 0 <= g["height_pct"] <= 100))
check("v0.4 report says 'no percentile' when the window has too few swing legs", g["hist_n"] >= 8 or "no percentile" in txt)
check("v0.4 report shows leg age / size and the ATR_D unit", all(s in txt for s in ("leg age", "leg size", "ATR_D = the same distance")))
check("v0.4 nearest-change line only when a TF has 2+ change levels",
      all((("Nearest change:" in blk) == (len(A["tfs"][t]["change_levels"]) > 1)) for t, blk in
          ((t, txt.split(f"\n{t} · ", 1)[1].split("\n\n", 1)[0]) for t in A["tfs"] if f"\n{t} · " in txt)))
check("v0.4 leg sentence is labelled a description", "A description of size, not a limit." in txt)

# 8. v0.5 full mode: the 12-state dashboard (quick output unchanged; full adds `dashboard` per TF)
check("v0.5 quick mode has no dashboard", "dashboard" not in A["tfs"]["1H"] and A["mode"] == "quick")
long_path = []
for rep in range(5):                                   # ~850 bars: five waves, each shifted so the series keeps a slow drift
    long_path += [p + rep * 6 for p in wave()]
d3 = {"symbol": "TEST:DEEP", "tfs": {"1D": series(long_path, T0, 86400), "1W": series(long_path[::5], T0, 604800)}}
dp3, ap3, hp3, tp3 = (os.path.join(tmp, x) for x in ("data3.json", "astr3.json", "r3.html", "r3.txt"))
json.dump(d3, open(dp3, "w"))
r3 = run(os.path.join(SCRIPTS, "compute.py"), "--data", dp3, "--chart-tf", "1D", "--mode", "full", "--now", "2030-01-01T00:00:00+00:00", "--out", ap3)
check("v0.5 full mode runs", r3.returncode == 0)
A3 = json.load(open(ap3))
D = A3["tfs"]["1D"]["dashboard"]
grp = lambda s: "—" if s == 0 else "WAIT" if s in (1, 7, 12) else "READY" if 4 <= s <= 6 else "TREND"
check("v0.5 state code 0..12 with the group rule", 0 <= D["state"] <= 12 and D["group"] == grp(D["state"]) and D["name"] == compute.STATE_NAME[D["state"]])
check("v0.5 states ran (trend states appear in the history)", any(s in (8, 9) for s in D["history"]) and len(D["history"]) == 120 and all(isinstance(s, int) for s in D["history"]))
check("v0.5 hold counters are positive", D["state_bars"] >= 1 and D["group_bars"] >= D["state_bars"] >= 1)
check("v0.5 reason string format", re.fullmatch(r"mL [+-]\d+\.\d ATR \(rank \d+%\) · ER \d\.\d\d · Vol rank \d+%", D["reason"]) is not None)
check("v0.5 next 10 bars = 2.07 / 5.71 x ATR(14)", abs(D["next_10"][0] - 2.07 * A3["tfs"]["1D"]["atr14"]) < 1e-9 and abs(D["next_10"][1] - 5.71 * A3["tfs"]["1D"]["atr14"]) < 1e-9)
check("v0.5 rank window 252 on 1D, 52 on 1W", D["rank_bars"] == 252 and A3["tfs"]["1W"]["dashboard"]["rank_bars"] == 52)
check("v0.5 HTF of 1D is 1W with a relation", D["htf"]["tf"] == "1W" and D["htf"]["relation"] in ("n/a", "conflict", "same", "weak") and D["htf"]["pct"] is not None)
check("v0.5 HTF of 1W is 1M (not in the data) = n/a", A3["tfs"]["1W"]["dashboard"]["htf"]["tf"] == "1M" and A3["tfs"]["1W"]["dashboard"]["htf"]["relation"] == "n/a")
check("v0.5 hysteresis: percentrank is a share of the previous window", compute._prank([1, 2, 3, 4, 5, 3], 5, 5) == 60.0 and compute._prank([1, 2, 3], 2, 5) is None)
check("v0.5 ema starts with the SMA of the first n values", compute._ema([None, 1.0, 2.0, 3.0, 4.0], 3)[3] == 2.0 and compute._ema([None, 1.0, 2.0, 3.0, 4.0], 3)[2] is None)
r3 = run(os.path.join(SCRIPTS, "render.py"), "--astr", ap3, "--out-html", hp3, "--out-txt", tp3)
t3, h3 = open(tp3).read(), open(hp3).read()
check("v0.5 full report carries the dashboard", r3.returncode == 0 and "FULL MODE" in t3.splitlines()[0] and "DASHBOARD · 12 STATES" in t3 and "Dashboard · 12 states" in h3 and "Dashboard: 1D reads" in t3)
check("v0.5 full report passes lint", run(os.path.join(SCRIPTS, "lint_report.py"), hp3, tp3).returncode == 0)
raw3 = os.path.join(tmp, "raw3.json")
json.dump({"rows": [f"{D['group']} | {D['name']}", f"Structure | {'Bullish' if A3['tfs']['1D']['structure'] == 'Uptrend' else 'Bearish'} (HH · HL) · protected {A3['tfs']['1D']['protected']}"]}, open(raw3, "w"))
r3c = run(os.path.join(SCRIPTS, "render.py"), "--astr", ap3, "--chart-table", raw3, "--out-html", hp3, "--out-txt", tp3)
check("v0.5 chart-table parity renders and compares the state cell", r3c.returncode == 0 and f"OK chart parity" in open(tp3).read() and f"/ state {D['name']}" in open(tp3).read())
json.dump({"rows": ["待 WAIT | 中 Neutral", "Structure | Bullish · protected 1"]}, open(raw3, "w"))
r3d = run(os.path.join(SCRIPTS, "render.py"), "--astr", ap3, "--chart-table", raw3, "--out-html", hp3, "--out-txt", tp3)
check("v0.5 chart-table parity flags a different state", r3d.returncode == 0 and "CHECK chart parity" in open(tp3).read())
r3q = run(os.path.join(SCRIPTS, "render.py"), "--astr", ap_, "--chart-table", raw3, "--out-html", hp3, "--out-txt", tp3)
check("v0.5 chart-table parity still works in quick mode", r3q.returncode == 0 and "chart parity" in open(tp3).read())

print(f"\n{'ALL PASS' if not fails else f'{len(fails)} FAILED'}")
sys.exit(1 if fails else 0)
