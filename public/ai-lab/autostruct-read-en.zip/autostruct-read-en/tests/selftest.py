"""Self-test for autostruct-read-en. Synthetic data only; standard library only.
Run: python3 -I tests/selftest.py   (exit 0 = all checks pass)"""
import json, math, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(HERE, "..", "scripts")
sys.path.insert(0, SCRIPTS)
import compute, render  # noqa: E402

fails = []


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        fails.append(name)


def series(path, t0, step):
    """Bars that follow a list of close prices, with small wicks."""
    o, h, l, c, t = [], [], [], [], []
    prev = path[0]
    for k, p in enumerate(path):
        o.append(prev); c.append(p)
        h.append(max(prev, p) + 0.3); l.append(min(prev, p) - 0.3)
        t.append(t0 + k * step); prev = p
    v = [1000 + (k * 37) % 400 + (300 if abs(c[k] - o[k]) > 0.5 else 0) for k in range(len(c))]
    return {"t": t, "o": o, "h": h, "l": l, "c": c, "v": v}


def wave():
    """Rise 100 -> 140 with pullbacks, then a fall to 110 (CHoCH down + BOS), then a bounce to `end`."""
    p = []
    for a, b, n in ((100, 120, 30), (120, 112, 10), (112, 135, 30), (135, 126, 10), (126, 140, 25),
                    (140, 118, 25), (118, 124, 8), (124, 110, 20), (110, 114, 12)):
        p += [a + (b - a) * k / n for k in range(n)]
    return p


T0 = 1_700_000_000
H1 = 3600

# 1. pivot rule: ties allowed on the left, strict on the right
s = [1, 3, 3, 2, 1]
check("pivot: later of two equal highs is the pivot", compute.pivot(s, 4, 2, True) == 3)
s = [1, 2, 3, 3, 1]
check("pivot: equal high on the right blocks the pivot", compute.pivot(s, 4, 2, True) is None)

# 2. structure engine on synthetic data
d = {"symbol": "TEST:WAVE", "tfs": {tf: series(wave(), T0, sec) for tf, sec in (("1H", H1), ("4H", 4 * H1), ("1D", 86400), ("1W", 604800))}}
tmp = tempfile.mkdtemp()
dp, ap_, hp, tp = (os.path.join(tmp, x) for x in ("data.json", "astr.json", "r.html", "r.txt"))
json.dump(d, open(dp, "w"))
last_1h = d["tfs"]["1H"]["t"][-1]
run = lambda *a: subprocess.run([sys.executable, "-I", *a], capture_output=True, text=True)
now_open = f"{__import__('datetime').datetime.fromtimestamp(last_1h + 1800, __import__('datetime').timezone.utc).isoformat()}"
r = run(os.path.join(SCRIPTS, "compute.py"), "--data", dp, "--chart-tf", "1H", "--now", now_open, "--out", ap_)
check("compute runs", r.returncode == 0)
A = json.load(open(ap_))
R = A["tfs"]["1H"]
check("structure is Downtrend after the fall", R["structure"] == "Downtrend")
check("Protected level is above the last close", R["protected"] is not None and R["protected"] > R["close"])
check("Bottom-out areas exist on a Downtrend leg", bool(R["fib"]) and "bottom_out" in R["fib"])
check("swing sequence is labelled", all(x["label"] in ("H", "L", "HH", "LH", "HL", "LL") for x in R["swing_seq"]))
check("BOS count is a non-negative int", isinstance(R["bos_count"], int) and R["bos_count"] >= 0)

# 2b. volume layers (v5): leg profile, Smart POC, order blocks; skipped without volume
V = R["volume"]
check("volume layers computed when bars have volume", isinstance(V, dict) and set(V) == {"leg_profile", "smart_poc", "order_blocks"})
lp = V["leg_profile"]
check("leg profile has POC inside its value area", bool(lp) and lp["val"] <= lp["poc"] <= lp["vah"] and 0 < lp["poc_share"] <= 1)
check("smart POC levels carry volrel >= 1", all(z["volrel"] >= 1 and z["half"] > 0 for z in V["smart_poc"]))
check("order blocks are mid/high volume with top > bot", all(z["rank"] in ("mid", "high") and z["top"] > z["bot"] for z in V["order_blocks"]))
d_nov = {"symbol": "TEST:NOVOL", "tfs": {tf: {k: v_ for k, v_ in cols.items() if k != "v"} for tf, cols in d["tfs"].items()}}
dp2, ap2 = os.path.join(tmp, "data2.json"), os.path.join(tmp, "astr2.json")
json.dump(d_nov, open(dp2, "w"))
r2 = run(os.path.join(SCRIPTS, "compute.py"), "--data", dp2, "--chart-tf", "1H", "--now", now_open, "--out", ap2)
check("compute runs without volume", r2.returncode == 0 and json.load(open(ap2))["tfs"]["1H"]["volume"] is None)

# 3. closed-bar handling: forming 1H bar inside the session, session over 3h+ after the last 1H bar
check("forming 1H bar is not read", R["forming"] is True and R["last_closed"] == R["bars"] - 2)
check("session not over while 1H bars are fresh", A["session_over"] is False)
now_late = __import__("datetime").datetime.fromtimestamp(last_1h + 5 * H1, __import__("datetime").timezone.utc).isoformat()
run(os.path.join(SCRIPTS, "compute.py"), "--data", dp, "--chart-tf", "1H", "--now", now_late, "--out", ap_)
check("session over after 3h+ without a new 1H bar", json.load(open(ap_))["session_over"] is True)

# 4. Bottom-out position in all four states
b = R["fib"]["bottom_out"]
cases = {"below": min(b["stable"]) - 0.01, "Stable": sum(b["stable"]) / 2, "Confirm": sum(b["confirm"]) / 2, "above": max(b["confirm"]) + 0.01}
for want, c in cases.items():
    check(f"bottom-out position: {want}", render.bo_pos(dict(R, close=c)) == want)

# 5. data status words
check("update_mode streaming = real-time", render.data_mode("streaming") == "real-time")
check("update_mode delayed 900 = 15 min", render.data_mode("delayed_streaming_900").startswith("delayed 15 min"))

# 6. full render + lint, stale warning, sections
run(os.path.join(SCRIPTS, "compute.py"), "--data", dp, "--chart-tf", "1H", "--now", "2030-01-01T00:00:00+00:00", "--out", ap_)
r = run(os.path.join(SCRIPTS, "render.py"), "--astr", ap_, "--update-mode", "delayed_streaming_900", "--out-html", hp, "--out-txt", tp)
check("render runs", r.returncode == 0)
txt = open(tp).read()
html = open(hp).read()
for sec in ("STRUCTURE SNAPSHOT", "SUMMARY", "STRUCTURE BY TIMEFRAME", "WHAT CHANGES THE STRUCTURE", "POSITION IN THE DOWN LEG", "VOLUME LAYERS", "DISCLAIMER"):
    check(f"text report has {sec}", sec in txt)
check("stale data warning shown", "WARNING" in txt and "days old" in txt)
check("delayed data shown in header", "delayed 15 min" in txt.splitlines()[0])
check("HTML has the structure map", "<svg class='map'" in html)
check("HTML has the volume layers card", "Volume layers" in html and "Smart POC" in html)
hp2, tp2 = os.path.join(tmp, "r2.html"), os.path.join(tmp, "r2.txt")
run(os.path.join(SCRIPTS, "render.py"), "--astr", ap2, "--out-html", hp2, "--out-txt", tp2)
check("report without volume says the layers are skipped", "no volume" in open(tp2).read())
check("lint passes on the report", run(os.path.join(SCRIPTS, "lint_report.py"), hp, tp).returncode == 0)
bad = os.path.join(tmp, "bad.txt")
open(bad, "w").write("You should buy here, target 150.\n")
check("lint blocks advice wording", run(os.path.join(SCRIPTS, "lint_report.py"), bad).returncode != 0)

print(f"\n{'ALL PASS' if not fails else f'{len(fails)} FAILED'}")
sys.exit(1 if fails else 0)
