# Structure principles (mirror Auto Market Structure & Liquidity v5.3)

- **Swings.** A swing high or low is confirmed only after price reverses at least Swing size × ATR(14) from it.
  Swings always alternate high / low.
- **BOS (break of structure).** A close beyond the last swing in the direction of the current structure.
  Uptrend = higher highs and higher lows (HH · HL); Downtrend = lower highs and lower lows (LH · LL).
- **Protected level.** The extreme between the broken swing and the BOS bar: the swing low that an Uptrend
  keeps, or the swing high that a Downtrend keeps.
- **CHoCH (change of character).** A close beyond the Protected level. The structure changes direction and a
  new Protected level is set at the extreme since the old one.
- **Sweep vs break.** A wick beyond a level with a close back inside is a sweep; only a close beyond it is a break.
- **Fibonacci leg.** 100% = Protected level, 0% = the extreme since it; 61.8% is the golden ratio.
- **Bottom-out areas** (Downtrend only): recovery depth of the structure leg, measured up from its low: Stable 23.6–38.2%,
  Confirm 38.2–50% of the leg. ✓ = the last close is above the area. These are depth marks, not Fibonacci support: a ✓
  says how much of the leg has been recovered; the structure still changes only at the Protected level.
- **Liquidity zones.** Just beyond recent pivot highs / lows (pivot bars 3 / 5 / 8 by Style), 0.25 × ATR deep,
  merged when within 0.1 × ATR (×2, ×3), at most three per side. A zone is removed once price trades through it.
- **Closed bars.** Every reading uses closed bars; the forming bar never changes a reading.
- **Order blocks** (v5). The last opposite-colour candle between the origin of a BOS / CHoCH leg and the break bar,
  with the volume that traded inside it while the leg formed. Blocks in the lowest volume tercile (of the last 30) are
  hidden; a close through the block removes it. Test on S50 30m/1H: blocks held about as often as random zones of the
  same size; low-volume blocks held least. A block says where the move started, not that price turns there.
- **Leg volume profile** (v5). Volume at price from the Protected level to the last closed bar (24 rows); POC = the row
  with the most volume, value area = the rows holding 70% around it. It describes where the leg traded.
- **Smart POC levels** (v5). The POC of each completed swing leg, kept only when the leg's volume is at least the average
  of the last 20 legs; removed on a close through. Test on S50 1H 2023–26: first test held two sessions 49% vs 32% for
  random levels (p ≈ .005); legs with below-average volume were no better than random; no POC acted as a magnet.
  Volume is a filter for which structure to trust, never a turning-point forecast.
- **Leg age and size** (v0.4). The current leg runs from the Protected level to its extreme. Its bars, calendar time and height in
  ATR(14) are compared with the completed ATR-swing legs in the same 300-bar window as percentiles. A tall or old leg is a
  description of size; legs have no limit, and the structure still changes only at the Protected level.
- **Timeframe alignment** (v0.4). Each timeframe is read on its own; the alignment line only counts how many read like the
  highest one, and the nested sentence says whether the chart-timeframe leg runs with or against the next higher leg and
  where the close sits inside it. ATR_D = a distance in the 1D ATR(14), so timeframes can be compared.
- **Dashboard states** (v0.5 full mode). The state machine names what price has been doing on closed bars from three features: momentum over the
  Style's look-back in ATR (short and slow, the slow one smoothed), the Efficiency Ratio (net move / path) and the ATR percent rank over about one
  year. 待 WAIT: 乱 Volatile (ATR rank ≥ 90% with a rough path), 揉 Chop (rough path, no trend), 中 Neutral. 構 READY: 押 Pullback Up / Down (a
  counter-move into the pullback zone, 0.5–1.5 × ATR from the extreme of a held trend, Floor / Ceiling at 2 × ATR), 静 Compressed (ATR rank ≤ 10% while the trend rule is off).
  流 TREND: 破 Breakout Up / Breakdown (a clean close out of a compress box, held a few bars), 昇 Up / 降 Down (ER ≥ 0.30 and momentum rank ≥ 66%,
  with hysteresis), 横 Sideways Up / Down (momentum rank ≥ 33% with a path neither clean enough for Up / Down nor rough enough for Chop). Volatile and
  Breakout replace the state at once; every other change waits for the Style's hold (Chop ↔ Neutral at least 3 bars) and three bars in the group
  before the group changes. The HTF row repeats the slow momentum on the next higher
  timeframe's last completed bar. A state is a description of the recent path, not a signal, and it never changes the structure reading.
