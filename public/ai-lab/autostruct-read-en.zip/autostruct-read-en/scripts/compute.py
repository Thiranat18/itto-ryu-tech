#!/usr/bin/env python3
"""Rebuild the structure readings of "Auto Market Structure & Liquidity by [Itto-Ryu]" (v5.2) from OHLCV.
Python standard library only. Quick mode: structure, Protected level, Fibonacci leg, Bottom-out areas and
liquidity zones on every timeframe in data.json. The 12-state dashboard is not computed in this version.

The logic mirrors the Pine source line by line:
  - ATR(14) zigzag: a swing high/low is confirmed once price reverses `swing_k` x ATR(14) from the leg extreme.
  - Dow structure: BOS = close beyond the last swing in the structure direction; CHoCH = close beyond the
    Protected level. The Protected level is the extreme since the broken swing (BOS) or since the old
    Protected level (CHoCH).
  - Fibonacci leg: 100% = Protected level, 0% = the extreme since it.
  - Bottom-out (downtrend only): Stable = 23.6-38.2%, Confirm = 38.2-50% of the leg, measured from the low.
  - Liquidity zones: pivot highs/lows (left = right = pivot bars of the Style), 0.25 x ATR(14) deep, merged when
    within 0.1 x ATR, at most 3 per side; a wick through with a close back inside = sweep.
  - Volume layers (v5, only when the data has volume): order blocks = last opposite candle before each BOS / CHoCH
    leg with the volume traded inside it (lowest tercile vs the last 30 hidden, 4 per side, removed on a close through);
    leg volume profile from the Protected level to the last closed bar (24 rows, POC, 70% value area);
    Smart POC = POC of each completed swing leg whose volume >= the average of the last 20 legs (6 kept, removed
    on a close through half a row beyond).
Everything is evaluated on closed bars only, like the indicator.

Usage:
  python3 compute.py --data data.json --chart-tf 1D --out astr.json [--swing-k 2.0] [--style Auto] [--now ISO] [--closed 1D]
"""
import argparse, json, sys
from datetime import datetime, timezone

TF_SEC = {"1": 60, "5": 300, "15": 900, "30": 1800, "60": 3600, "1H": 3600, "120": 7200, "2H": 7200,
          "240": 14400, "4H": 14400, "D": 86400, "1D": 86400, "W": 604800, "1W": 604800, "M": 2592000, "1M": 2592000}
PIVOT_BY_STYLE = {"Scalp": 3, "Swing": 5, "Position": 8}


def tf_name(tf):
    return {"60": "1H", "240": "4H", "D": "1D", "W": "1W", "M": "1M"}.get(tf, tf)


def style_for(sec, style):
    if style != "Auto":
        return style
    return "Scalp" if sec <= 900 else "Swing" if sec < 86400 else "Position"


def atr_rma(h, l, c, n=14):
    tr = [h[0] - l[0]] + [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])) for i in range(1, len(c))]
    out = [None] * len(c)
    if len(c) >= n:
        out[n - 1] = sum(tr[:n]) / n
        for i in range(n, len(c)):
            out[i] = (out[i - 1] * (n - 1) + tr[i]) / n
    return out


def _profile(h, l, v, a, b, rows=24):
    """Volume at price over bars a..b, each bar's volume spread evenly over its range. POC + 70% value area."""
    lo, hi = min(l[a:b + 1]), max(h[a:b + 1])
    if hi <= lo:
        return None
    step = (hi - lo) / rows
    vol = [0.0] * rows
    tot = 0.0
    for k in range(a, b + 1):
        rg = max(h[k] - l[k], step * .01)
        vk = v[k] or 0.0
        j0 = max(0, min(rows - 1, int((l[k] - lo) // step)))
        j1 = max(0, min(rows - 1, int((h[k] - lo) // step)))
        for j in range(j0, j1 + 1):
            bt = lo + j * step
            ov = max(0.0, min(h[k], bt + step) - max(l[k], bt))
            vol[j] += vk * ov / rg
        tot += vk
    jp = max(range(rows), key=lambda j: vol[j])
    ju = jd = jp
    acc = vol[jp]
    while tot > 0 and acc < .7 * tot and (ju < rows - 1 or jd > 0):
        up = vol[ju + 1] if ju < rows - 1 else -1.0
        dn = vol[jd - 1] if jd > 0 else -1.0
        if up >= dn:
            ju += 1
            acc += up
        else:
            jd -= 1
            acc += dn
    return {"poc": lo + (jp + .5) * step, "half": step / 2, "vah": lo + (ju + 1) * step, "val": lo + jd * step,
            "total": tot, "poc_share": vol[jp] / tot if tot else 0.0, "lo": lo, "hi": hi}


def _vol_in(h, l, v, a, b, top, bot):
    s = 0.0
    for k in range(a, b + 1):
        rg = max(h[k] - l[k], 1e-9)
        s += (v[k] or 0.0) * max(0.0, min(h[k], top) - max(l[k], bot)) / rg
    return s


def pivot(series, i, k, hi):
    """Pine ta.pivothigh/low at bar i: the bar k back is a pivot (ties allowed on the left, strictly beyond on the right;
    matches TradingView, where the later of two equal highs is the pivot)."""
    j = i - k
    if j - k < 0:
        return None
    v = series[j]
    left = series[j - k:j]
    right = series[j + 1:i + 1]
    if hi:
        ok = all(v >= x for x in left) and all(v > x for x in right)
    else:
        ok = all(v <= x for x in left) and all(v < x for x in right)
    return v if ok else None


def extreme_since(series, i, start, hi):
    """ta.highest/lowest over bars start..i and the bar of the most recent extreme."""
    lo_b = max(0, start, i - 1999)
    best_b = i
    for b in range(i, lo_b - 1, -1):
        if (series[b] > series[best_b]) if hi else (series[b] < series[best_b]):
            best_b = b
    return series[best_b], best_b


def run(tf, cols, swing_k, style, now_ts, closed=False, trace=None):
    o, h, l, c = cols.get("o", cols["c"]), cols["h"], cols["l"], cols["c"]
    t = cols.get("t", list(range(len(c))))
    n = len(c)
    v = cols.get("v")
    has_v = bool(v) and any(x for x in v if x)
    sec = TF_SEC.get(tf, 86400)
    sty = style_for(sec, style)
    pv = PIVOT_BY_STYLE.get(sty, 8)
    last_closed = n - 1
    forming = False
    if not closed and "t" in cols and now_ts and t[-1] + sec > now_ts:
        last_closed, forming = n - 2, True
    atr = atr_rma(h, l, c, 14)

    zz_leg, zz_hi, zz_hib, zz_lo, zz_lob = 0, None, None, None, None
    sh1 = sh1b = sl1 = sl1b = None
    sh_broken = sl_broken = False
    st, prot, protb = 0, None, None
    swings, breaks, sweeps = [], [], []
    liq = {"hi": [], "lo": []}                       # [price, atr_at_creation, count, left_bar]
    obs, ob_hist, spoc, sp_hist = [], [], [], []       # volume layers (v5)

    for i in range(last_closed + 1):
        a = atr[i]
        len_sh = 1 if sh1b is None else max(1, min(i - sh1b + 1, 2000))
        len_sl = 1 if sl1b is None else max(1, min(i - sl1b + 1, 2000))
        len_pr = 1 if protb is None else max(1, min(i - protb + 1, 2000))
        ph = pivot(h, i, pv, True)
        pl = pivot(l, i, pv, False)
        if a is None:
            if trace is not None:
                trace.append((st, prot, protb, False, sl1, sl1b))
            continue
        sp_leg = None
        # ATR zigzag
        if zz_leg == 0:
            zz_leg, zz_hi, zz_hib, zz_lo, zz_lob = 1, h[i], i, l[i], i
        elif zz_leg == 1:
            if h[i] > zz_hi:
                zz_hi, zz_hib = h[i], i
            if l[i] <= zz_hi - swing_k * a:
                if has_v and sl1b is not None and zz_hib > sl1b:
                    sp_leg = (sl1b, zz_hib)
                sh1, sh1b, sh_broken = zz_hi, zz_hib, False
                swings.append({"bar": zz_hib, "price": zz_hi, "kind": "H"})
                zz_leg, zz_lo, zz_lob = -1, l[i], i
        else:
            if l[i] < zz_lo:
                zz_lo, zz_lob = l[i], i
            if h[i] >= zz_lo + swing_k * a:
                if has_v and sh1b is not None and zz_lob > sh1b:
                    sp_leg = (sh1b, zz_lob)
                sl1, sl1b, sl_broken = zz_lo, zz_lob, False
                swings.append({"bar": zz_lob, "price": zz_lo, "kind": "L"})
                zz_leg, zz_hi, zz_hib = 1, h[i], i
        # Smart POC: POC of the leg that just completed, kept when the leg's volume >= the 20-leg average
        if sp_leg:
            pr = _profile(h, l, v, sp_leg[0], sp_leg[1])
            if pr:
                hist = sp_hist[-20:]
                avg = sum(hist) / len(hist) if len(hist) >= 5 else None
                sp_hist.append(pr["total"])
                if avg and pr["total"] > 0 and pr["total"] >= avg:
                    spoc.append({"price": pr["poc"], "half": pr["half"], "volrel": pr["total"] / avg, "born": i,
                                 "side": 1 if c[i] > pr["poc"] else -1})
                    if len(spoc) > 6:
                        spoc.pop(0)
        spoc = [z for z in spoc if not ((z["side"] == 1 and c[i] < z["price"] - z["half"]) or (z["side"] == -1 and c[i] > z["price"] + z["half"]))]
        # Dow structure
        ev = None
        if st == 1 and prot is not None and c[i] < prot:
            ev = ("CHoCH", -1, prot, protb)
            st = -1
            prot, protb = extreme_since(h, i, i - len_pr + 1, True)
        elif st == -1 and prot is not None and c[i] > prot:
            ev = ("CHoCH", 1, prot, protb)
            st = 1
            prot, protb = extreme_since(l, i, i - len_pr + 1, False)
        elif st >= 0 and sh1 is not None and not sh_broken and c[i] > sh1:
            ev = ("BOS", 1, sh1, sh1b)
            sh_broken, st = True, 1
            prot, protb = extreme_since(l, i, i - len_sh + 1, False)
        elif st <= 0 and sl1 is not None and not sl_broken and c[i] < sl1:
            ev = ("BOS", -1, sl1, sl1b)
            sl_broken, st = True, -1
            prot, protb = extreme_since(h, i, i - len_sl + 1, True)
        if ev:
            breaks.append({"bar": i, "type": ev[0], "dir": ev[1], "level": ev[2], "from_bar": ev[3]})
            # order block: last opposite candle between the leg origin (new Protected level bar) and the break bar
            if has_v and protb is not None and i - protb >= 1:
                side = ev[1]
                kob = next((k for k in range(i - 1, protb - 1, -1) if ((c[k] < o[k]) if side == 1 else (c[k] > o[k]))), None)
                if kob is not None:
                    top, bot = h[kob], l[kob]
                    vol = _vol_in(h, l, v, protb, i, top, bot)
                    pct = (sum(1 for x in ob_hist if x < vol) / len(ob_hist)) if ob_hist else .5
                    rank = "low" if pct < 1 / 3 else "mid" if pct < 2 / 3 else "high"
                    ob_hist = (ob_hist + [vol])[-30:]
                    if rank != "low" and all(z["ob_bar"] != kob for z in obs):
                        obs.append({"side": side, "top": top, "bot": bot, "born": i, "ob_bar": kob, "vol": vol, "rank": rank, "touched": False})
                        same = [z for z in obs if z["side"] == side]
                        if len(same) > 4:
                            obs.remove(same[0])
        keep_ob = []
        for z in obs:
            if (z["side"] == 1 and c[i] < z["bot"]) or (z["side"] == -1 and c[i] > z["top"]):
                continue
            if not z["touched"] and ((z["side"] == 1 and l[i] <= z["top"]) or (z["side"] == -1 and h[i] >= z["bot"])):
                z["touched"] = True
            keep_ob.append(z)
        obs = keep_ob
        # liquidity: sweeps / taken first, then new pivots
        for side, sign in (("hi", 1), ("lo", -1)):
            keep = []
            for z in liq[side]:
                p = z[0]
                touched = (c[i] > p or h[i] > p) if sign == 1 else (c[i] < p or l[i] < p)
                if touched:
                    if (c[i] <= p) if sign == 1 else (c[i] >= p):
                        sweeps.append({"bar": i, "side": "above" if sign == 1 else "below", "price": p})
                    continue
                keep.append(z)
            liq[side] = keep
        for side, p in (("hi", ph), ("lo", pl)):
            if p is None:
                continue
            hit = next((z for z in liq[side] if abs(p - z[0]) <= 0.1 * a), None)
            if hit:
                hit[0] = max(hit[0], p) if side == "hi" else min(hit[0], p)
                hit[2] += 1
            else:
                liq[side].append([p, a, 1, i - pv])
                if len(liq[side]) > 3:
                    liq[side].pop(0)
        if trace is not None:                          # per-bar state for research scripts
            trace.append((st, prot, protb, bool(sweeps) and sweeps[-1]["bar"] == i and sweeps[-1]["side"] == "below", sl1, sl1b))

    i = last_closed
    def stamp(b):
        return t[b] if b is not None and "t" in cols else None
    out = {"tf": tf_name(tf), "style": sty, "pivot_bars": pv, "bars": n, "last_closed": i, "forming": forming,
           "close": c[i], "time": stamp(i), "last_price": c[-1], "last_time": t[-1] if "t" in cols else None, "atr14": atr[i], "structure": {1: "Uptrend", -1: "Downtrend"}.get(st, "None"),
           "protected": prot, "protected_time": stamp(protb), "protected_bar": protb,
           "swing_high": sh1, "swing_high_broken": sh_broken, "swing_high_time": stamp(sh1b),
           "swing_low": sl1, "swing_low_broken": sl_broken, "swing_low_time": stamp(sl1b)}
    last = breaks[-1] if breaks else None
    out["last_break"] = dict(last, time=stamp(last["bar"])) if last else None
    out["last_choch"] = next((dict(b, time=stamp(b["bar"])) for b in reversed(breaks) if b["type"] == "CHoCH"), None)
    # Fibonacci leg and Bottom-out on the last closed bar
    fib = None
    if st != 0 and prot is not None and protb is not None and protb < i:
        ext, extb = extreme_since(h if st == 1 else l, i, protb, st == 1)
        fh, fl = (ext, prot) if st == 1 else (prot, ext)
        if fh > fl:
            rng = fh - fl
            ret = (fh - c[i]) / rng * 100 if st == 1 else (c[i] - fl) / rng * 100
            lv = {f"{r}": (fh - r / 100 * rng) if st == 1 else (fl + r / 100 * rng) for r in (0, 23.6, 38.2, 50, 61.8, 78.6, 100)}
            fib = {"high": fh, "low": fl, "extreme": ext, "extreme_time": stamp(extb), "extreme_bar": extb,
                   "retrace_pct": ret, "levels": lv}
            if st == -1:
                s1, s2, c2 = fl + .236 * rng, fl + .382 * rng, fl + .5 * rng
                fib["bottom_out"] = {"stable": [s1, s2], "confirm": [s2, c2],
                                     "stable_ok": c[i] > s2, "confirm_ok": c[i] > c2}
    out["fib"] = fib
    out["liquidity_above"] = sorted([{"price": z[0], "top": z[0] + .25 * z[1], "count": z[2], "left_bar": z[3]} for z in liq["hi"]], key=lambda z: z["price"])
    out["liquidity_below"] = sorted([{"price": z[0], "bottom": z[0] - .25 * z[1], "count": z[2], "left_bar": z[3]} for z in liq["lo"]], key=lambda z: -z["price"])
    ls = sweeps[-1] if sweeps else None
    out["last_sweep"] = dict(ls, time=stamp(ls["bar"])) if ls else None
    # next state-change levels
    chg = []
    if st == 1:
        chg.append({"kind": "CHoCH", "dir": -1, "level": prot})
        if sh1 is not None and not sh_broken:
            chg.append({"kind": "BOS", "dir": 1, "level": sh1})
    elif st == -1:
        chg.append({"kind": "CHoCH", "dir": 1, "level": prot})
        if sl1 is not None and not sl_broken:
            chg.append({"kind": "BOS", "dir": -1, "level": sl1})
    else:
        if sh1 is not None and not sh_broken:
            chg.append({"kind": "BOS", "dir": 1, "level": sh1})
        if sl1 is not None and not sl_broken:
            chg.append({"kind": "BOS", "dir": -1, "level": sl1})
    out["change_levels"] = chg
    # volume layers on the last closed bar
    vol_layers = None
    if has_v:
        cand = [x for x in (sh1b, sl1b) if x is not None]
        anchor = protb if (st != 0 and protb is not None) else (max(cand) if cand else None)
        prof = _profile(h, l, v, anchor, i) if anchor is not None and i > anchor else None
        vol_layers = {"leg_profile": None if not prof else dict(prof, anchor_time=stamp(anchor), anchor_bar=anchor),
                      "smart_poc": [dict(z, time=stamp(z["born"])) for z in spoc],
                      "order_blocks": [dict(z, time=stamp(z["born"])) for z in obs]}
    out["volume"] = vol_layers
    # trend age: BOS in the current direction since the last change of direction
    turn = max((k for k, b in enumerate(breaks) if b["type"] == "CHoCH" or b["dir"] != st), default=-1)
    out["bos_count"] = sum(1 for b in breaks[turn + 1:] if b["type"] == "BOS" and b["dir"] == st) + (
        1 if turn >= 0 and breaks[turn]["type"] == "BOS" and breaks[turn]["dir"] == st else 0)
    # last swings labelled against the previous swing of the same kind (HH / LH, HL / LL)
    seq, prev = [], {"H": None, "L": None}
    for s_ in swings:
        p_ = prev[s_["kind"]]
        lab = s_["kind"] if p_ is None else ("HH" if s_["price"] > p_ else "LH") if s_["kind"] == "H" else ("HL" if s_["price"] > p_ else "LL")
        prev[s_["kind"]] = s_["price"]
        seq.append({"label": lab, "price": s_["price"], "time": stamp(s_["bar"])})
    out["swing_seq"] = seq[-4:]
    # where price sits in the current leg (Fibonacci position from the extreme)
    out["phase"] = None if not fib else ("near the extreme" if fib["retrace_pct"] < 23.6 else
                                         "pullback" if fib["retrace_pct"] < 61.8 else "deep pullback")
    ev = [dict(b, kind=b["type"], time=stamp(b["bar"]), bars_ago=i - b["bar"]) for b in breaks[-3:]]
    ev += [dict(s_, kind="Sweep", time=stamp(s_["bar"]), bars_ago=i - s_["bar"]) for s_ in sweeps[-2:]]
    out["recent_events"] = sorted(ev, key=lambda x: -x["bar"])
    # recent history for the structure map
    k0 = max(0, i - 119)
    out["map"] = {"start": k0, "o": o[k0:i + 1], "h": h[k0:i + 1], "l": l[k0:i + 1], "c": c[k0:i + 1],
                  "t": t[k0:i + 1] if "t" in cols else None,
                  "swings": [s for s in swings if s["bar"] >= k0],
                  "breaks": [b for b in breaks if b["bar"] >= k0],
                  "sweeps": [s for s in sweeps if s["bar"] >= k0]}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--chart-tf", default="1D")
    ap.add_argument("--swing-k", type=float, default=2.0)
    ap.add_argument("--style", default="Auto", choices=["Auto", "Scalp", "Swing", "Position"])
    ap.add_argument("--now", default="", help="ISO time; default = now (UTC). Bars whose period has not ended are treated as forming.")
    ap.add_argument("--closed", default="", help="TFs whose last bar is final although its period has not ended, e.g. 1D after the session close")
    ap.add_argument("--out", default="astr.json")
    a = ap.parse_args()
    d = json.load(open(a.data))
    now_ts = datetime.fromisoformat(a.now).timestamp() if a.now else datetime.now(timezone.utc).timestamp()
    closed = {tf_name(x.strip()) for x in a.closed.split(",") if x.strip()}
    # Session markets: once the 1H feed has had no new bar for 3+ hours (longer than a lunch break), the session is
    # over and today's daily bar is final although its 24h period has not ended. 24h markets never trigger this.
    h1 = next((cols for tf, cols in d["tfs"].items() if tf_name(tf) == "1H" and "t" in cols), None)
    session_over = bool(h1) and now_ts - (h1["t"][-1] + 3600) > 3 * 3600
    if session_over:
        closed.add("1D")
    tfs = {}
    for tf, cols in d["tfs"].items():
        if len(cols["c"]) < 60:
            sys.exit(f"{tf}: need at least 60 bars, got {len(cols['c'])}")
        tfs[tf_name(tf)] = run(tf, cols, a.swing_k, a.style, now_ts, tf_name(tf) in closed)
    chart = tf_name(a.chart_tf)
    if chart not in tfs:
        sys.exit(f"chart TF {chart} not in data ({list(tfs)})")
    last_t = max((r["last_time"] or 0) for r in tfs.values())
    asof = datetime.fromtimestamp(last_t, timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if last_t else d.get("asof", "")
    json.dump({"symbol": d.get("symbol", ""), "asof": asof, "asof_ts": last_t, "run_ts": now_ts, "session_over": session_over, "chart_tf": chart, "mode": "quick",
               "inputs": {"swing_k": a.swing_k, "style": a.style}, "tfs": tfs}, open(a.out, "w"))
    for k, r in tfs.items():
        print(f"{k}: {r['structure']:9s} protected {r['protected']}  close {r['close']}  "
              f"fib {None if not r['fib'] else round(r['fib']['retrace_pct'], 1)}%  liq {len(r['liquidity_above'])}/{len(r['liquidity_below'])}"
              + ("  (no volume)" if not r['volume'] else f"  OB {len(r['volume']['order_blocks'])}  smartPOC {len(r['volume']['smart_poc'])}  legPOC {None if not r['volume']['leg_profile'] else round(r['volume']['leg_profile']['poc'], 2)}"))
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
