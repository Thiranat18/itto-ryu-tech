#!/usr/bin/env python3
"""Rebuild the structure readings of "Auto Market Structure & Liquidity by [Itto-Ryu]" (v5.3) from OHLCV.
Python standard library only. Quick mode: structure, Protected level, Fibonacci leg, Bottom-out areas and
liquidity zones on every timeframe in data.json. Full mode (--mode full, v0.5) adds the indicator's 12-state dashboard:
features (momentum, Efficiency Ratio, ATR rank), the state machine with its holds, trend memory and pullback zone, the
HTF flag, the expected 10-bar range and the Levels / Preset rows; it needs about a year of bars per timeframe.
v0.4 adds three descriptive readings on top (no engine change): timeframe alignment with the chart TF nested in
the next higher TF's leg, the distance to each state-change level in ATR (this TF and the 1D ATR), and the age /
size of the current structure leg against the completed swing legs in the same window.

The logic mirrors the Pine source line by line:
  - ATR(14) zigzag: a swing high/low is confirmed once price reverses `swing_k` x ATR(14) from the leg extreme.
  - Dow structure: BOS = close beyond the last swing in the structure direction; CHoCH = close beyond the
    Protected level. The Protected level is the extreme since the broken swing (BOS) or since the old
    Protected level (CHoCH).
  - Fibonacci leg: 100% = Protected level, 0% = the extreme since it.
  - Bottom-out (downtrend only): recovery depth of the leg measured up from its low, Stable = 23.6-38.2%, Confirm = 38.2-50%
    (depth marks, not Fibonacci support).
  - Liquidity zones: pivot highs/lows (left = right = pivot bars of the Style), 0.25 x ATR(14) deep, merged when
    within 0.1 x ATR, at most 3 per side; a wick through with a close back inside = sweep.
  - Volume layers (v5, only when the data has volume): order blocks = last opposite candle before each BOS / CHoCH
    leg with the volume traded inside it (lowest tercile vs the last 30 hidden, 4 per side, removed on a close through);
    leg volume profile from the Protected level to the last closed bar (24 rows, POC, 70% value area);
    Smart POC = POC of each completed swing leg whose volume >= the average of the last 20 legs (6 kept, removed
    on a close through half a row beyond).
Everything is evaluated on closed bars only, like the indicator.

Usage:
  python3 compute.py --data data.json --chart-tf 1D --out astr.json [--swing-k 2.0] [--style Auto] [--now ISO] [--closed 1D]
"""
import argparse, bisect, json, math, sys
from datetime import datetime, timezone

TF_SEC = {"1": 60, "5": 300, "15": 900, "30": 1800, "60": 3600, "1H": 3600, "120": 7200, "2H": 7200,
          "240": 14400, "4H": 14400, "D": 86400, "1D": 86400, "W": 604800, "1W": 604800, "M": 2592000, "1M": 2592000}
PIVOT_BY_STYLE = {"Scalp": 3, "Swing": 5, "Position": 8}


def tf_name(tf):
    return {"60": "1H", "240": "4H", "D": "1D", "W": "1W", "M": "1M"}.get(tf, tf)


def style_for(sec, style):
    if style != "Auto":
        return style
    return "Scalp" if sec <= 900 else "Swing" if sec < 86400 else "Position"


def atr_rma(h, l, c, n=14):
    tr = [h[0] - l[0]] + [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])) for i in range(1, len(c))]
    out = [None] * len(c)
    if len(c) >= n:
        out[n - 1] = sum(tr[:n]) / n
        for i in range(n, len(c)):
            out[i] = (out[i - 1] * (n - 1) + tr[i]) / n
    return out


def _profile(h, l, v, a, b, rows=24):
    """Volume at price over bars a..b, each bar's volume spread evenly over its range. POC + 70% value area."""
    lo, hi = min(l[a:b + 1]), max(h[a:b + 1])
    if hi <= lo:
        return None
    step = (hi - lo) / rows
    vol = [0.0] * rows
    tot = 0.0
    for k in range(a, b + 1):
        rg = max(h[k] - l[k], step * .01)
        vk = v[k] or 0.0
        j0 = max(0, min(rows - 1, int((l[k] - lo) // step)))
        j1 = max(0, min(rows - 1, int((h[k] - lo) // step)))
        for j in range(j0, j1 + 1):
            bt = lo + j * step
            ov = max(0.0, min(h[k], bt + step) - max(l[k], bt))
            vol[j] += vk * ov / rg
        tot += vk
    jp = max(range(rows), key=lambda j: vol[j])
    ju = jd = jp
    acc = vol[jp]
    while tot > 0 and acc < .7 * tot and (ju < rows - 1 or jd > 0):
        up = vol[ju + 1] if ju < rows - 1 else -1.0
        dn = vol[jd - 1] if jd > 0 else -1.0
        if up >= dn:
            ju += 1
            acc += up
        else:
            jd -= 1
            acc += dn
    return {"poc": lo + (jp + .5) * step, "half": step / 2, "vah": lo + (ju + 1) * step, "val": lo + jd * step,
            "total": tot, "poc_share": vol[jp] / tot if tot else 0.0, "lo": lo, "hi": hi,
            "rows": [round(x / tot, 5) if tot else 0.0 for x in vol]}   # v0.4.1: share of the leg volume per price row, low to high


def _vol_in(h, l, v, a, b, top, bot):
    s = 0.0
    for k in range(a, b + 1):
        rg = max(h[k] - l[k], 1e-9)
        s += (v[k] or 0.0) * max(0.0, min(h[k], top) - max(l[k], bot)) / rg
    return s


def pivot(series, i, k, hi):
    """Pine ta.pivothigh/low at bar i: the bar k back is a pivot (ties allowed on the left, strictly beyond on the right;
    matches TradingView, where the later of two equal highs is the pivot)."""
    j = i - k
    if j - k < 0:
        return None
    v = series[j]
    left = series[j - k:j]
    right = series[j + 1:i + 1]
    if hi:
        ok = all(v >= x for x in left) and all(v > x for x in right)
    else:
        ok = all(v <= x for x in left) and all(v < x for x in right)
    return v if ok else None


def extreme_since(series, i, start, hi):
    """ta.highest/lowest over bars start..i and the bar of the most recent extreme."""
    lo_b = max(0, start, i - 1999)
    best_b = i
    for b in range(i, lo_b - 1, -1):
        if (series[b] > series[best_b]) if hi else (series[b] < series[best_b]):
            best_b = b
    return series[best_b], best_b


def run(tf, cols, swing_k, style, now_ts, closed=False, trace=None, full=None):
    o, h, l, c = cols.get("o", cols["c"]), cols["h"], cols["l"], cols["c"]
    t = cols.get("t", list(range(len(c))))
    n = len(c)
    v = cols.get("v")
    has_v = bool(v) and any(x for x in v if x)
    sec = TF_SEC.get(tf, 86400)
    sty = style_for(sec, style)
    pv = PIVOT_BY_STYLE.get(sty, 8)
    last_closed = n - 1
    forming = False
    if not closed and "t" in cols and now_ts and t[-1] + sec > now_ts:
        last_closed, forming = n - 2, True
    atr = atr_rma(h, l, c, 14)

    zz_leg, zz_hi, zz_hib, zz_lo, zz_lob = 0, None, None, None, None
    sh1 = sh1b = sl1 = sl1b = None
    sh_broken = sl_broken = False
    st, prot, protb = 0, None, None
    swings, breaks, sweeps = [], [], []
    liq = {"hi": [], "lo": []}                       # [price, atr_at_creation, count, left_bar]
    obs, ob_hist, spoc, sp_hist = [], [], [], []       # volume layers (v5)

    for i in range(last_closed + 1):
        a = atr[i]
        len_sh = 1 if sh1b is None else max(1, min(i - sh1b + 1, 2000))
        len_sl = 1 if sl1b is None else max(1, min(i - sl1b + 1, 2000))
        len_pr = 1 if protb is None else max(1, min(i - protb + 1, 2000))
        ph = pivot(h, i, pv, True)
        pl = pivot(l, i, pv, False)
        if a is None:
            if trace is not None:
                trace.append((st, prot, protb, False, sl1, sl1b))
            continue
        sp_leg = None
        # ATR zigzag
        if zz_leg == 0:
            zz_leg, zz_hi, zz_hib, zz_lo, zz_lob = 1, h[i], i, l[i], i
        elif zz_leg == 1:
            if h[i] > zz_hi:
                zz_hi, zz_hib = h[i], i
            if l[i] <= zz_hi - swing_k * a:
                if has_v and sl1b is not None and zz_hib > sl1b:
                    sp_leg = (sl1b, zz_hib)
                sh1, sh1b, sh_broken = zz_hi, zz_hib, False
                swings.append({"bar": zz_hib, "price": zz_hi, "kind": "H"})
                zz_leg, zz_lo, zz_lob = -1, l[i], i
        else:
            if l[i] < zz_lo:
                zz_lo, zz_lob = l[i], i
            if h[i] >= zz_lo + swing_k * a:
                if has_v and sh1b is not None and zz_lob > sh1b:
                    sp_leg = (sh1b, zz_lob)
                sl1, sl1b, sl_broken = zz_lo, zz_lob, False
                swings.append({"bar": zz_lob, "price": zz_lo, "kind": "L"})
                zz_leg, zz_hi, zz_hib = 1, h[i], i
        # Smart POC: POC of the leg that just completed, kept when the leg's volume >= the 20-leg average
        if sp_leg:
            pr = _profile(h, l, v, sp_leg[0], sp_leg[1])
            if pr:
                hist = sp_hist[-20:]
                avg = sum(hist) / len(hist) if len(hist) >= 5 else None
                sp_hist.append(pr["total"])
                if avg and pr["total"] > 0 and pr["total"] >= avg:
                    spoc.append({"price": pr["poc"], "half": pr["half"], "volrel": pr["total"] / avg, "born": i,
                                 "side": 1 if c[i] > pr["poc"] else -1})
                    if len(spoc) > 6:
                        spoc.pop(0)
        spoc = [z for z in spoc if not ((z["side"] == 1 and c[i] < z["price"] - z["half"]) or (z["side"] == -1 and c[i] > z["price"] + z["half"]))]
        # Dow structure
        ev = None
        if st == 1 and prot is not None and c[i] < prot:
            ev = ("CHoCH", -1, prot, protb)
            st = -1
            prot, protb = extreme_since(h, i, i - len_pr + 1, True)
        elif st == -1 and prot is not None and c[i] > prot:
            ev = ("CHoCH", 1, prot, protb)
            st = 1
            prot, protb = extreme_since(l, i, i - len_pr + 1, False)
        elif st >= 0 and sh1 is not None and not sh_broken and c[i] > sh1:
            ev = ("BOS", 1, sh1, sh1b)
            sh_broken, st = True, 1
            prot, protb = extreme_since(l, i, i - len_sh + 1, False)
        elif st <= 0 and sl1 is not None and not sl_broken and c[i] < sl1:
            ev = ("BOS", -1, sl1, sl1b)
            sl_broken, st = True, -1
            prot, protb = extreme_since(h, i, i - len_sl + 1, True)
        if ev:
            breaks.append({"bar": i, "type": ev[0], "dir": ev[1], "level": ev[2], "from_bar": ev[3]})
            # order block: last opposite candle between the leg origin (new Protected level bar) and the break bar
            if has_v and protb is not None and i - protb >= 1:
                side = ev[1]
                kob = next((k for k in range(i - 1, protb - 1, -1) if ((c[k] < o[k]) if side == 1 else (c[k] > o[k]))), None)
                if kob is not None:
                    top, bot = h[kob], l[kob]
                    vol = _vol_in(h, l, v, protb, i, top, bot)
                    pct = (sum(1 for x in ob_hist if x < vol) / len(ob_hist)) if ob_hist else .5
                    rank = "low" if pct < 1 / 3 else "mid" if pct < 2 / 3 else "high"
                    ob_hist = (ob_hist + [vol])[-30:]
                    if rank != "low" and all(z["ob_bar"] != kob for z in obs):
                        obs.append({"side": side, "top": top, "bot": bot, "born": i, "ob_bar": kob, "vol": vol, "rank": rank, "touched": False})
                        same = [z for z in obs if z["side"] == side]
                        if len(same) > 4:
                            obs.remove(same[0])
        keep_ob = []
        for z in obs:
            if (z["side"] == 1 and c[i] < z["bot"]) or (z["side"] == -1 and c[i] > z["top"]):
                continue
            if not z["touched"] and ((z["side"] == 1 and l[i] <= z["top"]) or (z["side"] == -1 and h[i] >= z["bot"])):
                z["touched"] = True
            keep_ob.append(z)
        obs = keep_ob
        # liquidity: sweeps / taken first, then new pivots
        for side, sign in (("hi", 1), ("lo", -1)):
            keep = []
            for z in liq[side]:
                p = z[0]
                touched = (c[i] > p or h[i] > p) if sign == 1 else (c[i] < p or l[i] < p)
                if touched:
                    if (c[i] <= p) if sign == 1 else (c[i] >= p):
                        sweeps.append({"bar": i, "side": "above" if sign == 1 else "below", "price": p})
                    continue
                keep.append(z)
            liq[side] = keep
        for side, p in (("hi", ph), ("lo", pl)):
            if p is None:
                continue
            hit = next((z for z in liq[side] if abs(p - z[0]) <= 0.1 * a), None)
            if hit:
                hit[0] = max(hit[0], p) if side == "hi" else min(hit[0], p)
                hit[2] += 1
            else:
                liq[side].append([p, a, 1, i - pv])
                if len(liq[side]) > 3:
                    liq[side].pop(0)
        if trace is not None:                          # per-bar state for research scripts
            trace.append((st, prot, protb, bool(sweeps) and sweeps[-1]["bar"] == i and sweeps[-1]["side"] == "below", sl1, sl1b))

    i = last_closed
    def stamp(b):
        return t[b] if b is not None and "t" in cols else None
    out = {"tf": tf_name(tf), "style": sty, "pivot_bars": pv, "bars": n, "last_closed": i, "forming": forming,
           "close": c[i], "time": stamp(i), "last_price": c[-1], "last_time": t[-1] if "t" in cols else None, "atr14": atr[i], "structure": {1: "Uptrend", -1: "Downtrend"}.get(st, "None"),
           "protected": prot, "protected_time": stamp(protb), "protected_bar": protb,
           "swing_high": sh1, "swing_high_broken": sh_broken, "swing_high_time": stamp(sh1b),
           "swing_low": sl1, "swing_low_broken": sl_broken, "swing_low_time": stamp(sl1b)}
    last = breaks[-1] if breaks else None
    out["last_break"] = dict(last, time=stamp(last["bar"])) if last else None
    out["last_choch"] = next((dict(b, time=stamp(b["bar"])) for b in reversed(breaks) if b["type"] == "CHoCH"), None)
    # Fibonacci leg and Bottom-out on the last closed bar
    fib = None
    if st != 0 and prot is not None and protb is not None and protb < i:
        ext, extb = extreme_since(h if st == 1 else l, i, protb, st == 1)
        fh, fl = (ext, prot) if st == 1 else (prot, ext)
        if fh > fl:
            rng = fh - fl
            ret = (fh - c[i]) / rng * 100 if st == 1 else (c[i] - fl) / rng * 100
            lv = {f"{r}": (fh - r / 100 * rng) if st == 1 else (fl + r / 100 * rng) for r in (0, 23.6, 38.2, 50, 61.8, 78.6, 100)}
            fib = {"high": fh, "low": fl, "extreme": ext, "extreme_time": stamp(extb), "extreme_bar": extb,
                   "retrace_pct": ret, "levels": lv}
            if st == -1:
                s1, s2, c2 = fl + .236 * rng, fl + .382 * rng, fl + .5 * rng
                fib["bottom_out"] = {"stable": [s1, s2], "confirm": [s2, c2],
                                     "stable_ok": c[i] > s2, "confirm_ok": c[i] > c2}
    out["fib"] = fib
    out["liquidity_above"] = sorted([{"price": z[0], "top": z[0] + .25 * z[1], "count": z[2], "left_bar": z[3]} for z in liq["hi"]], key=lambda z: z["price"])
    out["liquidity_below"] = sorted([{"price": z[0], "bottom": z[0] - .25 * z[1], "count": z[2], "left_bar": z[3]} for z in liq["lo"]], key=lambda z: -z["price"])
    ls = sweeps[-1] if sweeps else None
    out["last_sweep"] = dict(ls, time=stamp(ls["bar"])) if ls else None
    # next state-change levels
    chg = []
    if st == 1:
        chg.append({"kind": "CHoCH", "dir": -1, "level": prot})
        if sh1 is not None and not sh_broken:
            chg.append({"kind": "BOS", "dir": 1, "level": sh1})
    elif st == -1:
        chg.append({"kind": "CHoCH", "dir": 1, "level": prot})
        if sl1 is not None and not sl_broken:
            chg.append({"kind": "BOS", "dir": -1, "level": sl1})
    else:
        if sh1 is not None and not sh_broken:
            chg.append({"kind": "BOS", "dir": 1, "level": sh1})
        if sl1 is not None and not sl_broken:
            chg.append({"kind": "BOS", "dir": -1, "level": sl1})
    for z in chg:                                      # v0.4: distance from the last close in this TF's ATR(14)
        z["atr"] = (z["level"] - c[i]) / atr[i] if atr[i] and z["level"] is not None else None
    out["change_levels"] = chg
    near = min((z for z in chg if z["atr"] is not None), key=lambda z: abs(z["atr"]), default=None)
    out["nearest_change"] = None if not near else {"kind": near["kind"], "dir": near["dir"], "level": near["level"], "atr": near["atr"]}
    # v0.4: the current structure leg (Protected level -> extreme) against the completed swing legs in this window
    leg = None
    if fib and protb is not None and atr[i]:
        hist = []
        for k in range(1, len(swings)):
            a_, b_ = swings[k - 1], swings[k]
            ak = atr[b_["bar"]]
            if ak:
                hist.append((abs(b_["price"] - a_["price"]) / ak, b_["bar"] - a_["bar"]))
        height = fib["high"] - fib["low"]
        bars_ = i - protb
        leg = {"bars": bars_, "seconds": (t[i] - t[protb]) if "t" in cols else None, "height": height,
               "height_atr": height / atr[i], "hist_n": len(hist),
               "height_pct": (100.0 * sum(1 for x in hist if x[0] < height / atr[i]) / len(hist)) if len(hist) >= 8 else None,
               "bars_pct": (100.0 * sum(1 for x in hist if x[1] < bars_) / len(hist)) if len(hist) >= 8 else None,
               "hist_median_height_atr": sorted(x[0] for x in hist)[len(hist) // 2] if hist else None,
               "hist_median_bars": sorted(x[1] for x in hist)[len(hist) // 2] if hist else None}
    out["leg"] = leg
    # volume layers on the last closed bar
    vol_layers = None
    if has_v:
        cand = [x for x in (sh1b, sl1b) if x is not None]
        anchor = protb if (st != 0 and protb is not None) else (max(cand) if cand else None)
        prof = _profile(h, l, v, anchor, i) if anchor is not None and i > anchor else None
        vol_layers = {"leg_profile": None if not prof else dict(prof, anchor_time=stamp(anchor), anchor_bar=anchor),
                      "smart_poc": [dict(z, time=stamp(z["born"])) for z in spoc],
                      "order_blocks": [dict(z, time=stamp(z["born"])) for z in obs]}
    out["volume"] = vol_layers
    # trend age: BOS in the current direction since the last change of direction
    turn = max((k for k, b in enumerate(breaks) if b["type"] == "CHoCH" or b["dir"] != st), default=-1)
    out["bos_count"] = sum(1 for b in breaks[turn + 1:] if b["type"] == "BOS" and b["dir"] == st) + (
        1 if turn >= 0 and breaks[turn]["type"] == "BOS" and breaks[turn]["dir"] == st else 0)
    # last swings labelled against the previous swing of the same kind (HH / LH, HL / LL)
    seq, prev = [], {"H": None, "L": None}
    for s_ in swings:
        p_ = prev[s_["kind"]]
        lab = s_["kind"] if p_ is None else ("HH" if s_["price"] > p_ else "LH") if s_["kind"] == "H" else ("HL" if s_["price"] > p_ else "LL")
        prev[s_["kind"]] = s_["price"]
        seq.append({"label": lab, "price": s_["price"], "time": stamp(s_["bar"])})
    out["swing_seq"] = seq[-4:]
    # where price sits in the current leg (Fibonacci position from the extreme)
    out["phase"] = None if not fib else ("near the extreme" if fib["retrace_pct"] < 23.6 else
                                         "pullback" if fib["retrace_pct"] < 61.8 else "deep pullback")
    ev = [dict(b, kind=b["type"], time=stamp(b["bar"]), bars_ago=i - b["bar"]) for b in breaks[-3:]]
    ev += [dict(s_, kind="Sweep", time=stamp(s_["bar"]), bars_ago=i - s_["bar"]) for s_ in sweeps[-2:]]
    out["recent_events"] = sorted(ev, key=lambda x: -x["bar"])
    # recent history for the structure map
    k0 = max(0, i - 119)
    out["map"] = {"start": k0, "o": o[k0:i + 1], "h": h[k0:i + 1], "l": l[k0:i + 1], "c": c[k0:i + 1],
                  "t": t[k0:i + 1] if "t" in cols else None,
                  "swings": [s for s in swings if s["bar"] >= k0],
                  "breaks": [b for b in breaks if b["bar"] >= k0],
                  "sweeps": [s for s in sweeps if s["bar"] >= k0]}
    if full is not None:                               # v0.5 full mode: the 12-state dashboard
        all_cols = {tf_name(k): v_ for k, v_ in full["all_cols"].items()}
        rank, bpd = rank_window(tf, cols, all_cols.get("1D"), full["days"])
        dash = regime(tf, cols, sty, i, atr, rank, pv)
        dash["htf"] = htf_row(tf, cols, i, STYLE_PRESET[sty][1], all_cols)
        sd, hp, hd = dash["dir"], dash["htf"]["pct"], dash["htf"]["dir"]
        dash["htf"]["relation"] = ("n/a" if hp is None else "conflict" if (hp >= 33 and sd != 0 and hd is not None and hd == -sd)
                                   else "same" if (hp >= 33 and sd != 0) else "weak")
        dash.update(rank_bars=rank, bars_per_day=bpd, market=full["market"], days=full["days"], style_eff=sty,
                    style_auto=(style == "Auto"), period=TF_PERIOD.get(tf_name(tf), tf))
        out["dashboard"] = dash
    return out


# ─────────────────────────────── v0.5 full mode: the 12-state dashboard ───────────────────────────────
# Literal port of the REGIME block of autostruct_v5.pine (closed bars only). Indicator defaults that are not
# CLI options: ATR length 14, ER threshold 0.30 (off 0.25), Chop <-> Neutral hold 3, group change hold 3,
# feature smoothing EMA 3, Pullback method ATR, depth Mid.
STYLE_PRESET = {"Scalp": (3, 10, 8, 3, 10, 6, 2, 1), "Swing": (5, 20, 10, 5, 20, 10, 3, 2), "Position": (8, 30, 14, 8, 30, 15, 4, 3)}
ER_ON, ER_OFF, CN_HOLD, GR_HOLD, SMOOTH = 0.30, 0.25, 3, 3, 3
PB_ATR, PB_FIB = (0.5, 1.5, 2.0), (0.382, 0.618, 0.786)
MARKET_DAYS = {"Classic": 252, "Crypto": 365, "FX & Gold": 260}
STATE_NAME = {0: "— warming up", 1: "乱 Volatile", 2: "破 Breakout Up", 3: "破 Breakdown", 4: "押 Pullback Up", 5: "押 Pullback Down",
              6: "静 Compressed", 7: "揉 Chop", 8: "昇 Up", 9: "降 Down", 10: "横 Sideways Up", 11: "横 Sideways Down", 12: "中 Neutral"}
TF_PERIOD = {"1H": "60", "4H": "240", "1D": "1D", "1W": "1W", "1M": "1M"}


def state_group(s):
    return "—" if s == 0 else "WAIT" if s in (1, 7, 12) else "READY" if 4 <= s <= 6 else "TREND"


def state_dir(s):
    return 1 if s in (2, 4, 8, 10) else -1 if s in (3, 5, 9, 11) else 0


def _lt(a, b):          # Pine: a comparison with na is false
    return a is not None and b is not None and a < b


def _ge(a, b):
    return a is not None and b is not None and a >= b


def _sign(v):
    return None if v is None else (1 if v > 0 else -1 if v < 0 else 0)


def _ema(x, n):
    """ta.ema: starts with the SMA of the first n values, then alpha = 2 / (n + 1)."""
    out, a, prev = [None] * len(x), 2.0 / (n + 1), None
    for i, v in enumerate(x):
        if prev is None:
            w = x[i - n + 1:i + 1] if i >= n - 1 else []
            prev = sum(w) / n if w and all(y is not None for y in w) else None
        elif v is None:
            prev = None
        else:
            prev = a * v + (1 - a) * prev
        out[i] = prev
    return out


def _prank(x, i, n):
    """ta.percentrank: share (%) of the previous n values that are <= the current one; na until n bars exist."""
    if i < n or x[i] is None:
        return None
    return 100.0 * sum(1 for v in x[i - n:i] if v is not None and v <= x[i]) / n


def rank_window(tf, cols, day_cols, days):
    """≈ 1 year of bars: weekly 52 / mult, daily days / mult, intraday bars-per-day x days (bars per day = the largest number of
    chart bars inside one completed 1D bar of the same data, like Pine's timeframe.change("D") counter). Clamped to 50..5000."""
    sec = TF_SEC.get(tf, 86400)
    bpd = 0
    if sec >= 2592000:
        raw = round(12.0 / (sec / 2592000))
    elif sec >= 604800:
        raw = round(52.0 / (sec / 604800))
    elif sec >= 86400:
        raw = round(days / (sec / 86400))
    else:
        if day_cols and "t" in day_cols and "t" in cols:
            td = day_cols["t"]
            counts = [0] * len(td)
            for x in cols["t"]:
                k = bisect.bisect_right(td, x) - 1
                if k >= 0:
                    counts[k] += 1
            bpd = max(counts[:-1]) if len(counts) > 1 else 0
        raw = bpd * days if bpd > 0 else 50
    return max(50, min(raw, 5000)), bpd


def monthly_from_daily(dc):
    out = {"t": [], "o": [], "h": [], "l": [], "c": []}
    cur = None
    for k in range(len(dc["c"])):
        ym = datetime.fromtimestamp(dc["t"][k], timezone.utc).strftime("%Y-%m")
        if ym != cur:
            cur = ym
            out["t"].append(dc["t"][k]); out["o"].append(dc.get("o", dc["c"])[k]); out["h"].append(dc["h"][k]); out["l"].append(dc["l"][k]); out["c"].append(dc["c"][k])
        else:
            out["h"][-1] = max(out["h"][-1], dc["h"][k]); out["l"][-1] = min(out["l"][-1], dc["l"][k]); out["c"][-1] = dc["c"][k]
    return out


def htf_row(tf, cols, last_closed, nL, all_cols):
    """The HTF flag: direction and percent rank of the nL-bar move (in ATR) on the last completed higher-TF bar before the one that
    holds the chart bar ([1] + lookahead_on). 1H -> 4H, 4H -> 1D, 1D -> 1W, 1W -> 1M (monthly built from the 1D bars)."""
    sec = TF_SEC.get(tf, 86400)
    name = "1H" if sec <= 900 else "4H" if sec <= 3600 else "1D" if sec <= 14400 else "1W" if sec <= 86400 else "1M"
    hrank = 60 if name == "1M" else 104 if name == "1W" else 252
    src = all_cols.get(name)
    if src is None and name == "1M" and all_cols.get("1D") and "t" in all_cols["1D"]:
        src = monthly_from_daily(all_cols["1D"])
    row = {"tf": name, "rank": hrank, "dir": None, "pct": None, "bar_time": None}
    if not src or "t" not in src or "t" not in cols or TF_SEC.get(name, 10 ** 9) <= sec:
        return row
    hc, hh, hl, ht = src["c"], src["h"], src["l"], src["t"]
    hatr = atr_rma(hh, hl, hc, 14)
    m = [(hc[k] - hc[k - nL]) / hatr[k] if k >= nL and hatr[k] else None for k in range(len(hc))]
    k = bisect.bisect_right(ht, cols["t"][last_closed]) - 2
    if k < 0:
        return row
    row.update(dir=_sign(m[k]), pct=_prank([None if v is None else abs(v) for v in m], k, hrank), bar_time=ht[k])
    return row


def regime(tf, cols, sty, last_closed, atr, rank, pv):
    """The state machine on bars 0..last_closed. Returns the dashboard values of the last closed bar."""
    nS, nL, erLen, pvLen, donLen, brkLook, brkHold, minHold = STYLE_PRESET[sty]
    o, h, l, c = cols.get("o", cols["c"]), cols["h"], cols["l"], cols["c"]
    n = last_closed + 1
    mS = [(c[i] - c[i - nS]) / atr[i] if i >= nS and atr[i] else None for i in range(n)]
    mL = _ema([(c[i] - c[i - nL]) / atr[i] if i >= nL and atr[i] else None for i in range(n)], SMOOTH)
    er_raw = []
    for i in range(n):
        if i < erLen:
            er_raw.append(None)
            continue
        path = sum(abs(c[k] - c[k - 1]) for k in range(i - erLen + 1, i + 1))
        er_raw.append(abs(c[i] - c[i - erLen]) / path if path > 0 else 0.0)
    er = _ema(er_raw, SMOOTH)
    absL = [None if v is None else abs(v) for v in mL]
    pbA, pbB, pbF = PB_ATR
    fbR1, fbR2, fbRF = PB_FIB
    trendOn = squeezeOn = volOn = moveOn = lowEr = False
    state = stateBars = groupBars = 0
    trendDir, trendExt, trendExtBar, atrExt = 0, None, None, None
    ph1 = ph1b = ph0 = ph0b = pl1 = pl1b = pl0 = pl0b = None
    boxActive = boxLive = False
    boxTop = boxBot = boxLeft = boxFrozen = None
    brkUntil, brkDir = -1, 0
    zTop = zBot = zFloor = zTopAlt = zBotAlt = None
    flip = None
    hist, last = [], {}
    for i in range(n):
        a = atr[i]
        atrPct = _prank(atr, i, rank)
        mPct = _prank(absL, i, rank)
        dirL, dirS = _sign(mL[i]), _sign(mS[i])
        ph, pl = pivot(h, i, pvLen, True), pivot(l, i, pvLen, False)
        if a is None:
            hist.append(0)
            continue
        e_, mp, ap = er[i], mPct, atrPct
        # raw flags with hysteresis
        trendOn = (not (_lt(e_, ER_OFF) or _lt(mp, 60))) if trendOn else (_ge(e_, ER_ON) and _ge(mp, 66))
        squeezeOn = (not _lt(15, ap)) if squeezeOn else _ge(10, ap)
        volOn = (not _lt(ap, 85)) if volOn else _ge(ap, 90)
        moveOn = (not _lt(mp, 28)) if moveOn else _ge(mp, 33)
        lowEr = (not _ge(e_, ER_ON)) if lowEr else _lt(e_, ER_OFF)
        # pivots (located pvLen bars back)
        if ph is not None:
            ph0, ph0b, ph1, ph1b = ph1, ph1b, ph, i - pvLen
        if pl is not None:
            pl0, pl0b, pl1, pl1b = pl1, pl1b, pl, i - pvLen
        # compress box
        newBrk = 0
        if boxActive:
            if c[i] > boxTop:
                newBrk = 1
            elif c[i] < boxBot:
                newBrk = -1
            elif not squeezeOn:
                boxActive, boxLive, boxFrozen = False, True, i
            else:
                boxTop, boxBot = max(boxTop, h[i]), min(boxBot, l[i])
        elif boxLive:
            if c[i] > boxTop:
                newBrk = 1
            elif c[i] < boxBot:
                newBrk = -1
            elif i - boxFrozen > brkLook:
                boxLive = False
        if newBrk != 0:
            boxLen = (i if boxActive else boxFrozen) - boxLeft + 1
            boxActive = boxLive = False
            if dirS == newBrk and _ge(e_, ER_ON) and boxLen >= 3:
                brkDir, brkUntil = newBrk, i + brkHold - 1
        if not boxActive and not boxLive and squeezeOn and newBrk == 0:
            boxActive, boxTop, boxBot, boxLeft = True, h[i], l[i], i
        # pullback zone from the previous bar's trend memory
        zTop = zBot = zFloor = zTopAlt = zBotAlt = None
        if trendDir != 0 and trendExt is not None:
            H = trendExt
            atrZT, atrZB, atrFl = H - trendDir * pbA * atrExt, H - trendDir * pbB * atrExt, H - trendDir * pbF * atrExt
            L = None
            if trendDir == 1:
                L = pl1 if _lt(pl1b, trendExtBar) else pl0 if _lt(pl0b, trendExtBar) else None
                L = None if L is not None and L >= H else L
            else:
                L = ph1 if _lt(ph1b, trendExtBar) else ph0 if _lt(ph0b, trendExtBar) else None
                L = None if L is not None and L <= H else L
            fibZT = None if L is None else H - (H - L) * fbR1
            fibZB = None if L is None else H - (H - L) * fbR2
            zTop, zBot, zFloor, zTopAlt, zBotAlt = atrZT, atrZB, atrFl, fibZT, fibZB
        flip = pl1 if trendDir == 1 else ph1 if trendDir == -1 else None
        # candidate state (priority list)
        inPbUp = trendDir == 1 and (_lt(mS[i], 0) or state == 4) and zFloor is not None and c[i] >= zFloor and c[i] <= zTop
        inPbDn = trendDir == -1 and (_lt(0, mS[i]) or state == 5) and zFloor is not None and c[i] <= zFloor and c[i] >= zTop
        if ap is None or mp is None:
            cand = 0
        elif volOn and lowEr:
            cand = 1
        elif i <= brkUntil:
            cand = 2 if brkDir == 1 else 3
        elif inPbUp:
            cand = 4
        elif inPbDn:
            cand = 5
        elif squeezeOn and not trendOn:
            cand = 6
        elif not trendOn and lowEr:
            cand = 7
        elif trendOn:
            cand = 8 if _ge(dirL, 0) else 9
        elif moveOn and not lowEr:
            sideDir = trendDir if trendDir != 0 else dirL
            cand = 10 if _ge(sideDir, 0) else 11
        else:
            cand = 12
        prev = state
        needHold = max(minHold, CN_HOLD) if (state == 7 and cand == 12) or (state == 12 and cand == 7) else minHold
        grpChange = state_group(cand) != state_group(state)
        if cand != state and (cand <= 3 or (stateBars >= needHold and (not grpChange or groupBars >= GR_HOLD))):
            groupBars = 1 if grpChange else groupBars + 1
            state, stateBars = cand, 1
        else:
            stateBars += 1
            groupBars += 1
        # trend memory
        sd = state_dir(state)
        if state in (2, 3, 8, 9) and trendDir != sd:
            trendDir, trendExt, trendExtBar, atrExt = sd, (h[i] if sd == 1 else l[i]), i, a
        if trendDir == 1 and h[i] > trendExt:
            trendExt, trendExtBar, atrExt = h[i], i, a
        if trendDir == -1 and l[i] < trendExt:
            trendExt, trendExtBar, atrExt = l[i], i, a
        crossFlip = _lt(c[i], flip) if trendDir == 1 else _lt(flip, c[i]) if trendDir == -1 else False
        crossFloor = _lt(c[i], zFloor) if trendDir == 1 else _lt(zFloor, c[i]) if trendDir == -1 else False
        if crossFlip or crossFloor or state == 1:
            trendDir, trendExt, trendExtBar, atrExt = 0, None, None, None
        hist.append(state)
        if i == n - 1:
            swHi = max(h[i - donLen:i]) if i >= donLen else None
            swLo = min(l[i - donLen:i]) if i >= donLen else None
            last = {"state": state, "name": STATE_NAME[state], "group": state_group(state), "dir": state_dir(state), "state_bars": stateBars,
                    "group_bars": groupBars, "prev_state": prev, "changed": state != prev,
                    "reason": f"mL {mL[i]:+.1f} ATR (rank {_pine_int(mp)}%) · ER {er[i]:.2f} · Vol rank {_pine_int(ap)}%" if mL[i] is not None and er[i] is not None else "warming up",
                    "move": {"mS": mS[i], "mL": mL[i], "er": er[i], "atr_pct": ap, "m_pct": mp,
                             "flags": {"trend_on": trendOn, "squeeze_on": squeezeOn, "vol_on": volOn, "move_on": moveOn, "low_er": lowEr}},
                    "trend_memory": {"dir": trendDir, "extreme": trendExt, "extreme_bar": trendExtBar, "atr_at_extreme": atrExt},
                    "zone": {"top": zTop, "bot": zBot, "floor": zFloor, "alt_top": zTopAlt, "alt_bot": zBotAlt, "method": "ATR", "depth": "Mid"},
                    "compress": {"active": boxActive, "live": boxLive, "top": boxTop if (boxActive or boxLive) else None,
                                 "bot": boxBot if (boxActive or boxLive) else None, "left_bar": boxLeft if (boxActive or boxLive) else None},
                    "swing_hi": swHi, "swing_lo": swLo, "pivots": {"ph1": ph1, "pl1": pl1}}
    last["history"] = hist[-120:]
    last["preset"] = {"nS": nS, "nL": nL, "er_len": erLen, "pivot_bars": pvLen, "swing_lookback": donLen, "breakout_window": brkLook,
                      "breakout_hold": brkHold, "min_hold": minHold}
    return last


def _pine_int(v):
    return "NaN" if v is None else str(int(math.floor(v + 0.5)))



TF_ORDER = ["1H", "4H", "1D", "1W"]


def alignment(tfs, chart):
    """v0.4: which timeframes point the same way as the highest one, and the chart TF inside the next higher TF's leg.
    Descriptive only; the structure of each TF is unchanged by this."""
    order = [t for t in TF_ORDER if t in tfs] + [t for t in tfs if t not in TF_ORDER]
    dirs = {t: tfs[t]["structure"] for t in order}
    top = order[-1]
    agree = [t for t in order if dirs[t] == dirs[top] and dirs[t] != "None"]
    disagree = [t for t in order if t not in agree]
    nested = None
    if chart in order:
        hi = next((t for t in order[order.index(chart) + 1:]), None)
        if hi:
            H, C = tfs[hi], tfs[chart]
            rel = ("with" if H["structure"] == C["structure"] and C["structure"] != "None"
                   else "against" if {H["structure"], C["structure"]} == {"Uptrend", "Downtrend"} else "none")
            pos = None
            if H["fib"]:
                f = H["fib"]
                pos = (C["close"] - f["low"]) / (f["high"] - f["low"]) * 100 if f["high"] > f["low"] else None
            nested = {"chart_tf": chart, "higher_tf": hi, "relation": rel, "higher_structure": H["structure"],
                      "higher_retrace_pct": None if not H["fib"] else H["fib"]["retrace_pct"], "higher_phase": H["phase"],
                      "close_in_higher_leg_pct": pos}
    return {"order": order, "top": top, "dirs": dirs, "agree": agree, "disagree": disagree, "nested": nested}


def week_closed(all_cols, h1, now_ts, session_over):
    """The latest 1W bar is final before its 7-day period ends once the week's trading is over: the weekend has started
    (day 5+ from the bar's start), or the session is over after a 1H bar on the fifth trading day. A holiday on that day
    waits for the weekend. Markets with daily bars on all seven weekdays (crypto) close the week by its period only."""
    w = next((cols for tf, cols in all_cols.items() if tf_name(tf) == "1W" and "t" in cols), None)
    dly = next((cols for tf, cols in all_cols.items() if tf_name(tf) == "1D" and "t" in cols), None)
    if not w or not dly or not h1:
        return False
    if len({datetime.fromtimestamp(x, timezone.utc).weekday() for x in dly["t"]}) >= 7:
        return False
    t0 = w["t"][-1]
    if now_ts >= t0 + 7 * 86400:
        return False                                  # period over: already closed by the normal rule
    day_now = (now_ts - t0) // 86400
    day_last = (h1["t"][-1] - t0) // 86400
    return day_now >= 5 or (session_over and day_last >= 4)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--chart-tf", default="1D")
    ap.add_argument("--swing-k", type=float, default=2.0)
    ap.add_argument("--style", default="Auto", choices=["Auto", "Scalp", "Swing", "Position"])
    ap.add_argument("--now", default="", help="ISO time; default = now (UTC). Bars whose period has not ended are treated as forming.")
    ap.add_argument("--closed", default="", help="TFs whose last bar is final although its period has not ended, e.g. 1D after the session close")
    ap.add_argument("--mode", default="quick", choices=["quick", "full"], help="full = also rebuild the 12-state dashboard (needs ~1 year of bars per TF)")
    ap.add_argument("--market", default="Classic", choices=list(MARKET_DAYS), help="full mode: trading days per year for the rank window")
    ap.add_argument("--out", default="astr.json")
    a = ap.parse_args()
    d = json.load(open(a.data))
    now_ts = datetime.fromisoformat(a.now).timestamp() if a.now else datetime.now(timezone.utc).timestamp()
    closed = {tf_name(x.strip()) for x in a.closed.split(",") if x.strip()}
    # Session markets: once the 1H feed has had no new bar for 3+ hours (longer than a lunch break), the session is
    # over and today's daily bar is final although its 24h period has not ended. 24h markets never trigger this.
    h1 = next((cols for tf, cols in d["tfs"].items() if tf_name(tf) == "1H" and "t" in cols), None)
    session_over = bool(h1) and now_ts - (h1["t"][-1] + 3600) > 3 * 3600
    if session_over:
        closed.add("1D")
    week_over = week_closed(d["tfs"], h1, now_ts, session_over)
    if week_over:
        closed.add("1W")
    tfs = {}
    for tf, cols in d["tfs"].items():
        if len(cols["c"]) < 60:
            sys.exit(f"{tf}: need at least 60 bars, got {len(cols['c'])}")
        full = {"all_cols": d["tfs"], "days": MARKET_DAYS[a.market], "market": a.market} if a.mode == "full" else None
        tfs[tf_name(tf)] = run(tf, cols, a.swing_k, a.style, now_ts, tf_name(tf) in closed, full=full)
    chart = tf_name(a.chart_tf)
    if chart not in tfs:
        sys.exit(f"chart TF {chart} not in data ({list(tfs)})")
    last_t = max((r["last_time"] or 0) for r in tfs.values())
    asof = datetime.fromtimestamp(last_t, timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if last_t else d.get("asof", "")
    # v0.4: distances in the 1D ATR(14) as a common unit, and the alignment of the timeframes
    atr_ref = (tfs.get("1D") or {}).get("atr14")
    for r in tfs.values():
        for z in r["change_levels"]:
            z["atr_d"] = (z["level"] - r["close"]) / atr_ref if atr_ref and z["level"] is not None else None
        if r.get("nearest_change"):
            r["nearest_change"]["atr_d"] = (r["nearest_change"]["level"] - r["close"]) / atr_ref if atr_ref else None
    json.dump({"symbol": d.get("symbol", ""), "asof": asof, "asof_ts": last_t, "run_ts": now_ts, "session_over": session_over, "week_over": week_over, "chart_tf": chart, "mode": a.mode,
               "inputs": dict({"swing_k": a.swing_k, "style": a.style}, **({"market": a.market} if a.mode == "full" else {})), "atr_d_ref": atr_ref, "alignment": alignment(tfs, chart), "tfs": tfs}, open(a.out, "w"))
    for k, r in tfs.items():
        if r.get("dashboard"):
            dd = r["dashboard"]
            print(f"{k}: {dd['group']} {dd['name']} ({dd['state_bars']} bars) · {dd['reason']} · HTF {dd['htf']['tf']} {dd['htf']['relation']} · rank {dd['rank_bars']}")
        print(f"{k}: {r['structure']:9s} protected {r['protected']}  close {r['close']}  "
              f"fib {None if not r['fib'] else round(r['fib']['retrace_pct'], 1)}%  liq {len(r['liquidity_above'])}/{len(r['liquidity_below'])}"
              + ("  (no volume)" if not r['volume'] else f"  OB {len(r['volume']['order_blocks'])}  smartPOC {len(r['volume']['smart_poc'])}  legPOC {None if not r['volume']['leg_profile'] else round(r['volume']['leg_profile']['poc'], 2)}"))
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
