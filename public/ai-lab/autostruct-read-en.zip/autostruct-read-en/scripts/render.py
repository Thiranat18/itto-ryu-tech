#!/usr/bin/env python3
"""astr.json (+ optional chart read) -> one HTML page + a plain-text report. Python standard library only.

Usage:
  python3 render.py --astr astr.json [--chart-table raw.json] --generated YYYY-MM-DD --out-html X.html --out-txt X.txt
raw.json (optional) = the Auto Structure dashboard rows read from the chart: {"rows": ["Structure | Bearish ... protected 32.75", ...]}
"""
import argparse, html, json, math, re
from datetime import datetime, timezone

DISC = ("This report describes market structure by principle only. It is not investment advice or a recommendation "
        "to buy or sell. You make your own decisions and bear your own risk. Print to PDF from your browser's Print menu.")
DISC_TXT = "DISCLAIMER: " + DISC.split(" Print to PDF")[0]
TF_ORDER = ["1H", "4H", "1D", "1W"]

CSS = """
:root{--bg:#f6f5f2;--card:#fff;--ink:#1d1d1f;--mute:#6b6b70;--line:#e4e2dc;--up:#0f7a5c;--upbg:#e3f3ec;--dn:#c0501a;--dnbg:#fbeadf;
--mid:#8a6d1f;--midbg:#fbf3dc;--accent:#b4362f;--prot:#8e44ad;--liq:#8e44ad;--gold:#c9a227;--fib:#9e9e9e;--bos:#56b4e9}
@media (prefers-color-scheme:dark){:root{--bg:#151517;--card:#1f1f22;--ink:#ececee;--mute:#a1a1a8;--line:#323236;--upbg:#173025;--dnbg:#3a2418;--midbg:#352d17;--up:#5fd39a;--dn:#ff9a62;--mid:#e6c35c;--accent:#ff8a7e;--prot:#c38ee0;--liq:#c38ee0}}
*{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font-family:'Inter',system-ui,sans-serif;font-size:15px;line-height:1.55}
.wrap{max-width:900px;margin:0 auto;padding:24px 16px 40px}
.brand{color:var(--accent);font-weight:700;letter-spacing:.12em;font-size:12px} h1{margin:2px 0 0;font-size:28px} .meta{color:var(--mute);font-size:13px}
.seal{float:right;font-family:'Noto Serif JP',serif;font-size:30px;color:var(--accent);border:2px solid var(--accent);border-radius:6px;padding:6px 8px;width:52px;text-align:center;line-height:1.05;margin-left:12px}
.badge{display:inline-block;vertical-align:middle;margin-left:10px;font-size:12px;font-weight:700;letter-spacing:.08em;padding:3px 10px;border-radius:999px;background:var(--midbg);color:var(--mid);border:1.5px solid var(--mid)}
.setup{background:var(--midbg);border:2px solid var(--mid);border-radius:12px;padding:12px 16px;margin-top:14px;font-size:14px} .setup code{background:var(--card);padding:1px 6px;border-radius:4px;font-size:13px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-top:14px} .card h2{font-size:16px;margin:0 0 10px}
.verdict{border-left:5px solid var(--accent)} .verdict p{margin:4px 0}
.note{font-size:12px;color:var(--mute);font-weight:400} .warn{background:var(--midbg);color:var(--mid);border-radius:8px;padding:8px 10px;font-size:13px;margin-top:8px}
table{width:100%;border-collapse:separate;border-spacing:4px} th{text-align:left;font-size:13px;color:var(--mute);font-weight:600}
td{font-size:14px;padding:7px 8px;border-radius:8px;background:var(--bg)} .up{background:var(--upbg);color:var(--up);font-weight:600} .dn{background:var(--dnbg);color:var(--dn);font-weight:600} .nt{background:var(--midbg);color:var(--mid);font-weight:600}
.lwrap{overflow-x:auto} svg.map{width:100%;min-width:640px;height:auto;display:block}
.legend span{display:inline-block;margin:6px 14px 0 0;font-size:12px;color:var(--mute)} .sw{display:inline-block;width:16px;height:0;border-top:2px dashed;vertical-align:middle;margin-right:5px} .bx{display:inline-block;width:14px;height:10px;vertical-align:middle;margin-right:5px;border-radius:2px}
.lv li{margin:4px 0} .tag{font-size:11px;background:var(--line);border-radius:4px;padding:1px 6px;margin-right:6px;color:var(--mute)}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px} .two ul{margin:4px 0;padding-left:18px} .sa{background:var(--upbg)} .sb{background:var(--midbg)}
.snap{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px} .chip{border-radius:10px;padding:10px 12px} .chip b{display:block;font-size:12px;opacity:.8} .chip span{font-size:17px;font-weight:700}
.tl{list-style:none;padding:0;margin:0} .tl li{padding:6px 0;border-bottom:1px solid var(--line);font-size:14px} .tl .new{font-size:11px;font-weight:700;background:var(--accent);color:#fff;border-radius:4px;padding:1px 6px;margin-left:6px}
.tfh{font-weight:700;margin:12px 0 2px} .tfh:first-of-type{margin-top:0}
table.dash{margin:4px 0 8px} table.dash th{width:170px;color:var(--mute);font-weight:600;text-align:left;vertical-align:top} svg.strip{display:block;height:36px;margin:2px 0 4px}
.disc{font-size:12px;color:var(--mute);margin-top:18px;border-top:1px solid var(--line);padding-top:10px}
@media (max-width:620px){.two{grid-template-columns:1fr}}
@media print{@page{size:A4;margin:12mm} body{background:#fff} .card{break-inside:avoid}}
"""


def e(s):
    return html.escape(str(s), quote=False)


def fp(x):
    if x is None:
        return "—"
    a = abs(x)
    d = 2 if a >= 1 else 4 if a >= 0.01 else 6
    return f"{x:,.{d}f}"


def fd(ts, tf):
    if ts is None:
        return "—"
    if tf in ("1H", "4H"):
        return datetime.fromtimestamp(ts, timezone.utc).strftime("%d %b %Y %H:%M UTC")
    # D/W bars are labelled by trading date: markets whose session opens the evening before in UTC
    # (gold, FX: 21:00-22:00 UTC) start on the previous calendar day, so shift half a day before taking the date.
    return datetime.fromtimestamp(ts + 43200, timezone.utc).strftime("%d %b %Y")


def word(st):
    return {"Uptrend": "Uptrend", "Downtrend": "Downtrend"}.get(st, "No structure yet")


def cls(st):
    return "up" if st == "Uptrend" else "dn" if st == "Downtrend" else "nt"


def leg_text(r):
    f = r["fib"]
    if not f:
        return "No leg yet."
    if r["structure"] == "Uptrend":
        return (f"Leg from the Protected Low {fp(r['protected'])} to the high {fp(f['high'])}; "
                f"price has retraced {f['retrace_pct']:.1f}% of it.")
    return (f"Leg from the Protected High {fp(r['protected'])} to the low {fp(f['low'])}; "
            f"price has recovered {f['retrace_pct']:.1f}% of it.")


def bo_text(r):
    f = r["fib"]
    if not f or "bottom_out" not in f:
        return None
    b = f["bottom_out"]
    s = f"Stable {fp(b['stable'][0])}–{fp(b['stable'][1])} {'✓' if b['stable_ok'] else '(no close above yet)'}"
    c = f"Confirm {fp(b['confirm'][0])}–{fp(b['confirm'][1])} {'✓' if b['confirm_ok'] else '(no close above yet)'}"
    return f"Bottom-out areas: {s}; {c}."


def bo_inside(r):
    """Which Bottom-out area the last close sits in (Downtrend legs only), else None."""
    f = r["fib"]
    if not f or "bottom_out" not in f:
        return None
    b, c = f["bottom_out"], r["close"]
    for name, (lo, hi) in (("Stable", b["stable"]), ("Confirm", b["confirm"])):
        if min(lo, hi) <= c <= max(lo, hi):
            return name
    return None


def bo_pos(r):
    """Where the last close sits against the Bottom-out areas: below / Stable / Confirm / above."""
    name = bo_inside(r)
    if name:
        return name
    return "above" if r["close"] > max(r["fib"]["bottom_out"]["confirm"]) else "below"


def bo_head(r, t):
    pos = bo_pos(r)
    return {"below": f"{t} · below the Stable area", "above": f"{t} · above the Confirm area (Confirm ✓)"}.get(
        pos, f"{t} · inside the {pos} area")


def bo_zone_lines(r, t):
    pos = bo_pos(r)
    f = r["fib"]
    b = f["bottom_out"]
    st_lo, st_hi = sorted(b["stable"])
    cf_lo, cf_hi = sorted(b["confirm"])
    leg = f"of the down leg from {fp(f['low'])}"
    tail = f"The structure stays Downtrend until a close above the Protected level {fp(r['protected'])}."
    if pos == "below":
        return [f"{t}: the last close {fp(r['close'])} is below the Bottom-out Stable area {fp(st_lo)}–{fp(st_hi)}; "
                f"price has recovered {f['retrace_pct']:.1f}% {leg} (Stable starts at 23.6%).",
                f"A close above {fp(st_hi)} = Bottom-out Stable ✓; the Confirm area is {fp(cf_lo)}–{fp(cf_hi)}.", tail]
    if pos == "above":
        return [f"{t}: the last close {fp(r['close'])} is above the Bottom-out Confirm area {fp(cf_lo)}–{fp(cf_hi)} "
                f"({f['retrace_pct']:.1f}% {leg}): Bottom-out Confirm ✓.",
                f"A close back below {fp(cf_lo)} returns to the Stable area.", tail]
    lo, hi = (st_lo, st_hi) if pos == "Stable" else (cf_lo, cf_hi)
    out = [f"{t}: the last close {fp(r['close'])} is inside the Bottom-out {pos} area {fp(lo)}–{fp(hi)} "
           f"({'23.6–38.2%' if pos == 'Stable' else '38.2–50%'} {leg})."]
    if pos == "Stable":
        out.append(f"A close above {fp(hi)} = Bottom-out Stable ✓; the Confirm area is {fp(cf_lo)}–{fp(cf_hi)}.")
    else:
        out.append(f"Bottom-out Stable ✓ is {'in place' if b['stable_ok'] else 'not in place'}; a close above {fp(hi)} = Bottom-out Confirm ✓.")
    out.append(f"A close back below {fp(lo)} leaves the area. " + tail)
    return out


def live_text(r, tf):
    """Where the forming bar sits now. Not a reading: readings change only on a close."""
    if not r.get("forming"):
        return None
    p = r["last_price"]
    where = []
    if r["protected"] is not None and ((r["structure"] == "Downtrend" and p > r["protected"]) or (r["structure"] == "Uptrend" and p < r["protected"])):
        where.append(f"beyond the Protected level {fp(r['protected'])}")
    zone = bo_inside(dict(r, close=p))
    if zone:
        where.append(f"inside the Bottom-out {zone} area")
    tail = f", {' and '.join(where)}" if where else ""
    return (f"Live {tf} bar (still forming): {fp(p)}{tail}. Not a reading until the bar closes.")


def atr_d(r, level):
    """Distance from the last close to a level, in ATR(14) of that TF."""
    if level is None or not r["atr14"]:
        return ""
    return f"{(level - r['close']) / r['atr14']:+.1f} ATR"


def data_mode(m):
    """Plain words for TradingView's update_mode (depends on the user's plan and exchange data)."""
    if not m:
        return None
    if m == "streaming":
        return "real-time"
    if m.startswith("delayed"):
        sec = re.search(r"(\d+)$", m)
        return f"delayed {int(sec.group(1)) // 60} min (your TradingView data plan)" if sec else "delayed (your TradingView data plan)"
    if m in ("endofday", "end_of_day"):
        return "end of day only"
    return m


def swing_note(r, tf):
    """Flag when the latest swings already point the other way while the structure has not changed."""
    seq = r["swing_seq"]
    lh = next((x["label"] for x in reversed(seq) if x["label"] in ("HH", "LH")), None)
    ll = next((x["label"] for x in reversed(seq) if x["label"] in ("HL", "LL")), None)
    if r["structure"] == "Downtrend" and lh == "HH" and ll == "HL":
        return (f"{tf}: the latest swings are rising (HH, HL) while the structure is still Downtrend; "
                f"it changes only on a close above the Protected level {fp(r['protected'])}.")
    if r["structure"] == "Uptrend" and lh == "LH" and ll == "LL":
        return (f"{tf}: the latest swings are falling (LH, LL) while the structure is still Uptrend; "
                f"it changes only on a close below the Protected level {fp(r['protected'])}.")
    return None


def near_prot(r):
    """Last close within 1 ATR of the Protected level."""
    return r["protected"] is not None and r["atr14"] and abs(r["protected"] - r["close"]) <= r["atr14"]


# ---------- v0.4 readings (descriptive only) ----------
def dur(sec):
    """Calendar length of a leg, e.g. 6h, 2d 6h, 3w 2d."""
    if sec is None:
        return ""
    sec = int(sec)
    if sec < 86400:
        return f"{sec // 3600}h"
    if sec < 7 * 86400:
        d, h = divmod(sec, 86400)
        return f"{d}d" + (f" {h // 3600}h" if h >= 3600 else "")
    w, d = divmod(sec, 7 * 86400)
    return f"{w}w" + (f" {d // 86400}d" if d >= 86400 else "")


def pct_words(pct, n, more, less):
    """'taller than 92% of the last 50 swing legs', with plain words at the ends of the scale."""
    if pct >= 100:
        return f"{more} all {n} completed swing legs"
    if pct <= 0:
        return f"{less} all {n} completed swing legs"
    return f"{more} {pct:.0f}% of the last {n} completed swing legs"


def leg_age(r):
    g = r.get("leg")
    if not g:
        return "—"
    return f"{g['bars']} bars" + (f", {dur(g['seconds'])}" if g.get("seconds") else "")


def leg_size(r):
    g = r.get("leg")
    if not g:
        return "—"
    s = f"{g['height_atr']:.1f} ATR"
    if g.get("height_pct") is not None:
        s += ", " + pct_words(g["height_pct"], g["hist_n"], "taller than", "shorter than")
    elif g.get("hist_n") is not None:
        s += f", only {g['hist_n']} completed swing legs in the window, no percentile"
    return s


def leg_sentence(r, tf):
    """One Summary sentence on the age and size of the chart-TF leg."""
    g = r.get("leg")
    if not g or r["structure"] == "None":
        return None
    kind = "up" if r["structure"] == "Uptrend" else "down"
    s = f"The {tf} {kind} leg from the Protected level is {g['bars']} bars" + (f" ({dur(g['seconds'])})" if g.get("seconds") else "") + f" old and {g['height_atr']:.1f} ATR tall"
    if g.get("height_pct") is not None and g.get("bars_pct") is not None:
        hp, bp, n = g["height_pct"], g["bars_pct"], g["hist_n"]
        if 0 < hp < 100 and 0 < bp < 100:
            s += f": taller than {hp:.0f}% and longer than {bp:.0f}% of the last {n} completed swing legs in this window"
        else:
            s += (f": {pct_words(hp, n, 'taller than', 'shorter than')} and "
                  f"{pct_words(bp, n, 'longer than', 'shorter-lived than')} in this window")
    return s + ". A description of size, not a limit."


def align_line(A, snap_text):
    """Alignment count, only when the snapshot line does not already say it (the 'Mixed' case)."""
    al = A.get("alignment")
    if not al or not snap_text.startswith("Mixed"):
        return None
    top = al["top"]
    if al["dirs"][top] == "None":
        return f"Alignment: {top} has no structure reading yet."
    return f"Alignment: {len(al['agree'])} of {len(al['order'])} timeframes read like {top} ({word(al['dirs'][top])})."


def nested_text(A):
    """The higher-TF line of the Summary, merged with the nested reading (v0.4)."""
    nd = (A.get("alignment") or {}).get("nested")
    if not nd:
        return None
    c, h = nd["chart_tf"], nd["higher_tf"]
    hs, H, C = word(nd["higher_structure"]), A["tfs"][nd["higher_tf"]], A["tfs"][nd["chart_tf"]]
    rel = (f"same direction as {c}" if nd["relation"] == "with" else f"opposite to {c}" if nd["relation"] == "against" else f"no match with {c}")
    s = f"{h} structure is {hs} ({rel})"
    if nd["relation"] == "none" or nd["higher_retrace_pct"] is None or not H["fib"]:
        return s + "."
    verb = "given back" if nd["higher_structure"] == "Uptrend" else "recovered"
    s += f"; as of the {h} close its leg has {verb} {nd['higher_retrace_pct']:.1f}% ({nd['higher_phase']})"
    p = nd.get("close_in_higher_leg_pct")
    if p is not None:
        f = H["fib"]
        where = (f"below the bottom of that leg ({fp(f['low'])})" if p < 0 else f"above the top of that leg ({fp(f['high'])})" if p > 100
                 else f"{p:.0f}% of the way up that leg ({fp(f['low'])}–{fp(f['high'])})")
        s += f", and the {c} close {fp(C['close'])} sits {where}"
    return s + "."


def snapshot(A, tfs):
    """One line for all TFs, plus how they line up."""
    sts = {t: A["tfs"][t]["structure"] for t in tfs}
    if len(set(sts.values())) == 1:
        return sts, f"All timeframes agree: {word(next(iter(sts.values())))}."
    top = tfs[-1]
    rest = [t for t in tfs[:-1] if sts[t] != sts[top]]
    if len(rest) == len(tfs) - 1 and len({sts[t] for t in rest}) == 1:
        return sts, (f"{', '.join(rest)} {word(sts[rest[0]])} inside a {top} {word(sts[top])}: the smaller timeframes "
                     f"are moving against the larger one.")
    return sts, "Mixed: " + ", ".join(f"{t} {word(v)}" for t, v in sts.items()) + "."


def since_text(r):
    ch = r["last_choch"]
    want = {"Uptrend": 1, "Downtrend": -1}.get(r["structure"])
    return fd(ch["time"], r["tf"]) if ch and ch["dir"] == want else "—"


def dist2(r, c):
    """Distance in this TF's ATR and in the 1D ATR (v0.4), e.g. '+0.4 ATR · +0.1 ATR_D'."""
    s = atr_d(r, c["level"])
    if c.get("atr_d") is not None and r["tf"] != "1D":
        s += f" · {c['atr_d']:+.1f} ATR_D"
    return s


def tf_levels(r, t):
    out = []
    nc = r.get("nearest_change")
    if nc and len(r["change_levels"]) > 1:
        out.append(f"Nearest change: {nc['kind']} {'up' if nc['dir'] == 1 else 'down'} at {fp(nc['level'])}, {abs(nc['atr']):.1f} ATR away"
                   + (f" ({abs(nc['atr_d']):.1f} ATR_D)" if nc.get("atr_d") is not None and r["tf"] != "1D" else "") + ".")
    for c in r["change_levels"]:
        word_ = "above" if c["dir"] == 1 else "below"
        if c["kind"] == "CHoCH":
            out.append(f"Close {word_} {fp(c['level'])} ({dist2(r, c)}) = CHoCH, structure turns {'Uptrend' if c['dir'] == 1 else 'Downtrend'}.")
        else:
            cont = (c["dir"] == 1) == (r["structure"] == "Uptrend")
            out.append(f"Close {word_} {fp(c['level'])} ({dist2(r, c)}) = BOS, {'Uptrend' if c['dir'] == 1 else 'Downtrend'} "
                       f"{'continues' if cont and r['structure'] != 'None' else 'starts'}.")
    if r["structure"] in ("Uptrend", "Downtrend") and not any(c["kind"] == "BOS" for c in r["change_levels"]):
        out.append("No unbroken swing in the trend direction yet: the next BOS level forms after a new swing.")
    up = r["liquidity_above"][0] if r["liquidity_above"] else None
    dn = r["liquidity_below"][0] if r["liquidity_below"] else None
    liq = [f"above {fp(up['price'])} ({atr_d(r, up['price'])})" if up else "", f"below {fp(dn['price'])} ({atr_d(r, dn['price'])})" if dn else ""]
    liq = [x for x in liq if x]
    if liq:
        out.append("Nearest liquidity " + ", ".join(liq) + ".")
    return out


def events(A, tfs, k=8):
    ev = []
    for t in tfs:
        for x in A["tfs"][t]["recent_events"]:
            if x["kind"] == "Sweep":
                txt = f"Sweep {x['side']} {fp(x['price'])}"
            else:
                txt = f"{x['kind']} {'up' if x['dir'] == 1 else 'down'} through {fp(x['level'])}"
            ev.append((x["time"] or 0, t, txt, x["bars_ago"] <= 2))
    ev.sort(key=lambda z: -z[0])
    return ev[:k]


def last_event(r, tf):
    b = r["last_break"]
    if not b:
        return "no break yet"
    d = "up" if b["dir"] == 1 else "down"
    return f"{b['type']} {d} through {fp(b['level'])} on {fd(b['time'], tf)}"


def spread_labels(svg, x, gap=12):
    """Push right-margin labels apart so none overlap (keeps their order top to bottom)."""
    pat = re.compile(rf"(<text x='{x}' y=')([\d.\-]+)(')")
    ys = [float(m.group(2)) for m in pat.finditer(svg)]
    order = sorted(range(len(ys)), key=lambda i: ys[i])
    new, last = ys[:], None
    for i in order:
        if last is not None and new[i] < last + gap:
            new[i] = last + gap
        last = new[i]
    it = iter(new)
    return pat.sub(lambda m: f"{m.group(1)}{next(it):.1f}{m.group(3)}", svg)


def map_svg(r, tf):
    m = r["map"]
    n = len(m["c"])
    if n < 5:
        return ""
    W, H, L, R, T, B = 860, 380, 8, 150, 14, 26
    pw = W - L - R
    hi, lo = max(m["h"]), min(m["l"])
    for v in (r["protected"],):
        if v is not None:
            hi, lo = max(hi, v), min(lo, v)
    for z in r["liquidity_above"]:
        if z["top"] <= hi + (hi - lo) * .15:
            hi = max(hi, z["top"])
    for z in r["liquidity_below"]:
        if z["bottom"] >= lo - (hi - lo) * .15:
            lo = min(lo, z["bottom"])
    pad = (hi - lo) * .04 or 1
    hi, lo = hi + pad, lo - pad
    s0 = m["start"]
    slots = n + 10                  # room on the right, like the indicator's bar_index + 8 drawings
    x = lambda b: L + (b - s0 + .5) * pw / slots
    y = lambda p: T + (hi - p) * (H - T - B) / (hi - lo)
    cw = max(1.5, pw / slots * .62)
    g = [f"<svg class='map' viewBox='0 0 {W} {H}' role='img' aria-label='Structure map: last {n} closed bars'>"]
    for k in range(5):
        p = lo + (hi - lo) * k / 4
        g.append(f"<line x1='{L}' x2='{L + pw}' y1='{y(p):.1f}' y2='{y(p):.1f}' stroke='var(--line)'/>"
                 f"<text x='{L + pw + 6}' y='{y(p) + 4:.1f}' font-size='11' fill='var(--mute)'>{fp(p)}</text>")
    xr = L + pw
    for z in r["liquidity_above"]:
        if lo <= z["price"] <= hi:
            x0 = x(max(z["left_bar"], s0))
            g.append(f"<rect x='{x0:.1f}' y='{y(min(z['top'], hi)):.1f}' width='{xr - x0:.1f}' height='{max(2, y(z['price']) - y(min(z['top'], hi))):.1f}' fill='var(--liq)' opacity='.18'/>"
                     f"<text x='{xr + 6}' y='{y(z['price']) - 2:.1f}' font-size='11' fill='var(--liq)'>Liquidity{' ×' + str(z['count']) if z['count'] > 1 else ''}</text>")
    for z in r["liquidity_below"]:
        if lo <= z["price"] <= hi:
            x0 = x(max(z["left_bar"], s0))
            g.append(f"<rect x='{x0:.1f}' y='{y(z['price']):.1f}' width='{xr - x0:.1f}' height='{max(2, y(max(z['bottom'], lo)) - y(z['price'])):.1f}' fill='var(--liq)' opacity='.18'/>"
                     f"<text x='{xr + 6}' y='{y(z['price']) + 11:.1f}' font-size='11' fill='var(--liq)'>Liquidity{' ×' + str(z['count']) if z['count'] > 1 else ''}</text>")
    f = r["fib"]
    if f:
        fx = x(max(r["protected_bar"], s0))
        if "bottom_out" in f:
            bx = x(max(f["extreme_bar"], s0))
            for (a, b_), col, lab in ((f["bottom_out"]["stable"], "#56b4e9", "Bottom-out Stable"), (f["bottom_out"]["confirm"], "#009e73", "Bottom-out Confirm")):
                ok = f["bottom_out"]["stable_ok" if "Stable" in lab else "confirm_ok"]
                g.append(f"<rect x='{bx:.1f}' y='{y(b_):.1f}' width='{xr - bx:.1f}' height='{y(a) - y(b_):.1f}' fill='{col}' opacity='.16' stroke='{col}' stroke-opacity='.5'/>"
                         f"<text x='{xr + 6}' y='{(y(a) + y(b_)) / 2 + 4:.1f}' font-size='11' fill='{col}'>{lab}{' ✓' if ok else ''}</text>")
        for k, v in f["levels"].items():
            if k in ("0", "100"):
                continue
            gold = k == "61.8"
            g.append(f"<line x1='{fx:.1f}' x2='{xr}' y1='{y(v):.1f}' y2='{y(v):.1f}' stroke='{'var(--gold)' if gold else 'var(--fib)'}' stroke-width='{1.6 if gold else 1}' {'' if gold else "stroke-dasharray='1 3'"}/>")
            if gold:
                g.append(f"<text x='{xr + 6}' y='{y(v) + 4:.1f}' font-size='11' fill='var(--gold)'>Fib 61.8%</text>")
    V = r.get("volume") or {}
    for z in V.get("order_blocks", []):
        if z["bot"] <= hi and z["top"] >= lo:
            x0 = x(max(z["ob_bar"], s0))
            col = "#7fb3d5" if z["side"] == 1 else "#e6a29c"
            g.append(f"<rect x='{x0:.1f}' y='{y(min(z['top'], hi)):.1f}' width='{xr - x0:.1f}' height='{max(2, y(max(z['bot'], lo)) - y(min(z['top'], hi))):.1f}' fill='{col}' opacity='.28' stroke='{col}' stroke-opacity='.6'/>"
                     f"<text x='{xr + 6}' y='{(y(min(z['top'], hi)) + y(max(z['bot'], lo))) / 2 + 4:.1f}' font-size='11' fill='{col}'>{'Demand' if z['side'] == 1 else 'Supply'} · vol {z['rank']}</text>")
    for z in V.get("smart_poc", []):
        if lo <= z["price"] <= hi:
            x0 = x(max(z["born"], s0))
            g.append(f"<line x1='{x0:.1f}' x2='{xr}' y1='{y(z['price']):.1f}' y2='{y(z['price']):.1f}' stroke='#e67e22' stroke-width='1.4'/>"
                     f"<text x='{xr + 6}' y='{y(z['price']) + 4:.1f}' font-size='11' fill='#e67e22'>POC {fp(z['price'])} · vol ×{z['volrel']:.1f}</text>")
    lp = V.get("leg_profile")
    if lp and lo <= lp["poc"] <= hi:
        x0 = x(max(lp["anchor_bar"], s0))
        g.append(f"<line x1='{x0:.1f}' x2='{xr}' y1='{y(lp['poc']):.1f}' y2='{y(lp['poc']):.1f}' stroke='#e67e22' stroke-width='1.8' stroke-dasharray='2 3'/>"
                 f"<text x='{xr + 6}' y='{y(lp['poc']) + 4:.1f}' font-size='11' fill='#e67e22' font-weight='600'>Leg POC {fp(lp['poc'])}</text>")
    for i in range(n):
        o_, h_, l_, c_ = m["o"][i], m["h"][i], m["l"][i], m["c"][i]
        col = "var(--up)" if c_ >= o_ else "var(--dn)"
        xc = x(s0 + i)
        g.append(f"<line x1='{xc:.1f}' x2='{xc:.1f}' y1='{y(h_):.1f}' y2='{y(l_):.1f}' stroke='{col}' stroke-width='1'/>"
                 f"<rect x='{xc - cw / 2:.1f}' y='{y(max(o_, c_)):.1f}' width='{cw:.1f}' height='{max(1, y(min(o_, c_)) - y(max(o_, c_))):.1f}' fill='{col}'/>")
    for b in m["breaks"]:
        x0, x1 = x(max(b["from_bar"], s0)), x(b["bar"])
        col = "var(--up)" if b["dir"] == 1 else "var(--dn)"
        yy = y(b["level"])
        g.append(f"<line x1='{x0:.1f}' x2='{x1:.1f}' y1='{yy:.1f}' y2='{yy:.1f}' stroke='{col}' stroke-dasharray='4 3' stroke-width='1.3'/>"
                 f"<text x='{(x0 + x1) / 2:.1f}' y='{yy + (-5 if b['dir'] == 1 else 13):.1f}' font-size='11' text-anchor='middle' fill='{col}' font-weight='600'>{b['type']}</text>")
    if r["protected"] is not None:
        yy = y(r["protected"])
        g.append(f"<line x1='{x(max(r['protected_bar'], s0)):.1f}' x2='{xr}' y1='{yy:.1f}' y2='{yy:.1f}' stroke='var(--prot)' stroke-dasharray='6 4' stroke-width='1.8'/>"
                 f"<text x='{xr + 6}' y='{yy + 4:.1f}' font-size='11' fill='var(--prot)' font-weight='600'>Protected {fp(r['protected'])}</text>")
    for s in m["sweeps"]:
        yy = y(m["h"][s["bar"] - s0]) - 6 if s["side"] == "above" else y(m["l"][s["bar"] - s0]) + 12
        g.append(f"<text x='{x(s['bar']):.1f}' y='{yy:.1f}' font-size='11' text-anchor='middle' fill='var(--liq)'>◆</text>")
    if m["t"]:
        for k in (0, n // 2, n - 1):
            anc = "start" if k == 0 else "middle"
            g.append(f"<text x='{x(s0 + k) - (4 if k == 0 else 0):.1f}' y='{H - 8}' font-size='11' text-anchor='{anc}' fill='var(--mute)'>{fd(m['t'][k], tf).split(' UTC')[0]}</text>")
    g.append("</svg>")
    return spread_labels("".join(g), xr + 6)


def bo_svg(r, tf):
    """Candles of the current down leg with the Bottom-out areas, for the Bottom-out zone section."""
    m, f = r["map"], r["fib"]
    b = f["bottom_out"]
    s0, n = m["start"], len(m["c"])
    a0 = max(s0, r["protected_bar"] - 3, s0 + n - 90)
    ks = range(a0 - s0, n)
    if len(ks) < 3:
        return ""
    W, H, L, R, T, B = 860, 340, 8, 190, 18, 26
    pw = W - L - R
    hi = max(r["protected"], max(m["h"][k] for k in ks))
    lo = min(f["low"], min(m["l"][k] for k in ks))
    pad = (hi - lo) * .05 or 1
    hi, lo = hi + pad, lo - pad
    slots = len(ks) + max(8, len(ks) // 5)      # empty room on the right for the close tag
    x = lambda k: L + (k - ks[0] + .5) * pw / slots
    y = lambda p: T + (hi - p) * (H - T - B) / (hi - lo)
    cw = max(2, pw / slots * .62)
    xr = L + pw
    st_lo, st_hi = sorted(b["stable"])
    cf_lo, cf_hi = sorted(b["confirm"])
    inside = bo_inside(r)
    u = re.sub(r"\W", "", tf)
    g = [f"<svg class='map' viewBox='0 0 {W} {H}' role='img' aria-label='{tf} Bottom-out areas on the current leg'>",
         f"<defs><linearGradient id='gS{u}' x1='0' x2='1'><stop offset='0' stop-color='#56b4e9' stop-opacity='.04'/><stop offset='1' stop-color='#56b4e9' stop-opacity='.30'/></linearGradient>"
         f"<linearGradient id='gC{u}' x1='0' x2='1'><stop offset='0' stop-color='#009e73' stop-opacity='.04'/><stop offset='1' stop-color='#009e73' stop-opacity='.30'/></linearGradient>"
         f"<filter id='glow{u}'><feGaussianBlur stdDeviation='2.5'/></filter></defs>"]
    bx = x(max(f["extreme_bar"], a0) - s0)
    for (zl, zh), grad, col, lab, ok in ((( st_lo, st_hi), f"gS{u}", "#56b4e9", "Stable", b["stable_ok"]),
                                         ((cf_lo, cf_hi), f"gC{u}", "#009e73", "Confirm", b["confirm_ok"])):
        live = inside == lab
        g.append(f"<rect x='{bx:.1f}' y='{y(zh):.1f}' width='{xr - bx:.1f}' height='{y(zl) - y(zh):.1f}' fill='url(#{grad})' "
                 f"stroke='{col}' stroke-opacity='{.9 if live else .35}' stroke-width='{1.6 if live else 1}' rx='3'/>"
                 f"<text x='{xr + 10}' y='{(y(zl) + y(zh)) / 2 - 2:.1f}' font-size='12' font-weight='700' fill='{col}'>{'◀ ' if live else ''}Bottom-out {lab}{' ✓' if ok else ''}</text>"
                 f"<text x='{xr + 10}' y='{(y(zl) + y(zh)) / 2 + 12:.1f}' font-size='11' fill='var(--mute)'>{fp(zl)}–{fp(zh)} · {'23.6–38.2%' if lab == 'Stable' else '38.2–50%'}</text>")
    for v in (st_lo, st_hi, cf_hi):
        g.append(f"<line x1='{bx:.1f}' x2='{xr}' y1='{y(v):.1f}' y2='{y(v):.1f}' stroke='var(--fib)' stroke-dasharray='1 3'/>")
    yl = y(f["low"])
    g.append(f"<line x1='{bx:.1f}' x2='{xr}' y1='{yl:.1f}' y2='{yl:.1f}' stroke='var(--dn)' stroke-opacity='.6'/>"
             f"<text x='{xr + 10}' y='{yl + 4:.1f}' font-size='11' fill='var(--dn)'>Leg low {fp(f['low'])}</text>")
    yp = y(r["protected"])
    g.append(f"<line x1='{x(max(r['protected_bar'], a0) - s0):.1f}' x2='{xr}' y1='{yp:.1f}' y2='{yp:.1f}' stroke='var(--prot)' stroke-dasharray='6 4' stroke-width='1.8'/>"
             f"<text x='{xr + 10}' y='{yp + 4:.1f}' font-size='11' font-weight='600' fill='var(--prot)'>Protected {fp(r['protected'])}</text>")
    for k in ks:
        o_, h_, l_, c_ = m["o"][k], m["h"][k], m["l"][k], m["c"][k]
        col = "var(--up)" if c_ >= o_ else "var(--dn)"
        xc = x(k)
        g.append(f"<line x1='{xc:.1f}' x2='{xc:.1f}' y1='{y(h_):.1f}' y2='{y(l_):.1f}' stroke='{col}'/>"
                 f"<rect x='{xc - cw / 2:.1f}' y='{y(max(o_, c_)):.1f}' width='{cw:.1f}' height='{max(1, y(min(o_, c_)) - y(max(o_, c_))):.1f}' fill='{col}' rx='.6'/>")
    xc, yc = x(ks[-1]), y(r["close"])
    tag = f"Close {fp(r['close'])}"
    tw = 6.6 * len(tag) + 16                      # pill width follows the label length
    g.append(             f"<circle cx='{xc:.1f}' cy='{yc:.1f}' r='6' fill='var(--gold)' opacity='.6' filter='url(#glow{u})'/>"
             f"<circle cx='{xc:.1f}' cy='{yc:.1f}' r='3.2' fill='var(--gold)'/>"
             f"<rect x='{xc + 10:.1f}' y='{yc - 10:.1f}' width='{tw:.0f}' height='20' rx='10' fill='var(--gold)'/>"
             f"<text x='{xc + 10 + tw / 2:.1f}' y='{yc + 4:.1f}' font-size='11' font-weight='700' text-anchor='middle' fill='#1a1a1a'>{tag}</text>")
    for k in (ks[0], ks[-1]):
        g.append(f"<text x='{x(k):.1f}' y='{H - 8}' font-size='11' text-anchor='{'start' if k == ks[0] else 'end'}' fill='var(--mute)'>{fd(m['t'][k], tf).split(' UTC')[0]}</text>")
    g.append("</svg>")
    return "".join(g)


def vol_svg(r, tf):
    """Candles of the current leg with the leg volume profile (rows, POC, value area), the live order blocks and Smart POC levels."""
    V, m = r.get("volume"), r["map"]
    if not V:
        return ""
    lp, sp, ob = V.get("leg_profile"), V.get("smart_poc") or [], V.get("order_blocks") or []
    s0, n = m["start"], len(m["c"])
    a0 = max(s0, s0 + n - 120, min(s0 + n - 40, (lp["anchor_bar"] - 2) if lp else s0))   # the leg, and at least 40 bars of context
    ks = range(a0 - s0, n)
    if len(ks) < 3:
        return ""
    W, H, L, R, T, B = 860, 360, 8, 238, 18, 26
    pw = W - L - R
    hi, lo = max(m["h"][k] for k in ks), min(m["l"][k] for k in ks)
    if lp:
        hi, lo = max(hi, lp["hi"]), min(lo, lp["lo"])
    span = (hi - lo) or 1
    near = lambda p: lo - span * .15 <= p <= hi + span * .15
    obs = [z for z in ob if near(z["top"]) and near(z["bot"])]
    sps = [z for z in sp if near(z["price"])]
    for z in obs:
        hi, lo = max(hi, z["top"]), min(lo, z["bot"])
    for z in sps:
        hi, lo = max(hi, z["price"]), min(lo, z["price"])
    pad = (hi - lo) * .05 or 1
    hi, lo = hi + pad, lo - pad
    slots = len(ks) + max(8, len(ks) // 5)
    x = lambda k: L + (k - ks[0] + .5) * pw / slots
    y = lambda p: T + (hi - p) * (H - T - B) / (hi - lo)
    cw = max(2, pw / slots * .62)
    xr = L + pw
    u = re.sub(r"\W", "", tf)
    g = [f"<svg class='map' viewBox='0 0 {W} {H}' role='img' aria-label='{tf} volume layers on the current leg'>",
         f"<defs><filter id='vglow{u}'><feGaussianBlur stdDeviation='2.5'/></filter></defs>"]
    # leg volume profile: one row per price step, drawn from the right edge; darker rows = 70% value area; gold row = POC
    if lp and lp.get("rows"):
        rows = lp["rows"]
        step = (lp["hi"] - lp["lo"]) / len(rows)
        mx = max(rows) or 1
        jp = rows.index(max(rows))
        for j, sh in enumerate(rows):
            b0, b1 = lp["lo"] + j * step, lp["lo"] + (j + 1) * step
            inva = b0 >= lp["val"] - 1e-9 and b1 <= lp["vah"] + 1e-9
            w = pw * .30 * sh / mx
            col, op = ("var(--gold)", .85) if j == jp else ("var(--ink)", .30 if inva else .11)
            g.append(f"<rect x='{xr - w:.1f}' y='{y(b1):.1f}' width='{w:.1f}' height='{max(1, y(b0) - y(b1) - .8):.1f}' fill='{col}' fill-opacity='{op}'/>")
        yp = y(lp["poc"])
        g.append(f"<line x1='{x(ks[0]):.1f}' x2='{xr}' y1='{yp:.1f}' y2='{yp:.1f}' stroke='var(--gold)' stroke-width='1.6' stroke-dasharray='6 4'/>"
                 f"<text x='{xr + 6}' y='{yp + 4:.1f}' font-size='11' font-weight='700' fill='var(--gold)'>POC {fp(lp['poc'])} · {lp['poc_share'] * 100:.0f}% of leg volume</text>")
        for v_, lab in ((lp["vah"], "Value area high"), (lp["val"], "Value area low")):
            g.append(f"<line x1='{xr - pw * .30:.1f}' x2='{xr}' y1='{y(v_):.1f}' y2='{y(v_):.1f}' stroke='var(--mute)' stroke-dasharray='2 3'/>"
                     f"<text x='{xr + 6}' y='{y(v_) + 4:.1f}' font-size='11' fill='var(--mute)'>{lab} {fp(v_)}</text>")
    # order blocks: the last opposite candle before a break, kept while price stays on its side
    for z in obs:
        col = "var(--up)" if z["side"] == 1 else "var(--dn)"
        xb = x(max(z["ob_bar"], a0) - s0)
        g.append(f"<rect x='{xb:.1f}' y='{y(z['top']):.1f}' width='{xr - xb:.1f}' height='{max(1, y(z['bot']) - y(z['top'])):.1f}' fill='{col}' fill-opacity='.13' "
                 f"stroke='{col}' stroke-opacity='.7' stroke-width='1' stroke-dasharray='{'3 3' if z['touched'] else 'none'}' rx='2'/>"
                 f"<text x='{xr + 6}' y='{(y(z['top']) + y(z['bot'])) / 2 + 4:.1f}' font-size='11' fill='{col}'>{'Demand' if z['side'] == 1 else 'Supply'} OB {fp(z['bot'])}–{fp(z['top'])} · vol {z['rank']}{' · tested' if z['touched'] else ''}</text>")
    # Smart POC levels: POC of an earlier leg whose volume reached the 20-leg average
    for z in sps:
        yz = y(z["price"])
        g.append(f"<line x1='{x(max(z['born'], a0) - s0):.1f}' x2='{xr}' y1='{yz:.1f}' y2='{yz:.1f}' stroke='var(--accent)' stroke-width='1.4' stroke-dasharray='8 3 2 3'/>"
                 f"<text x='{xr + 6}' y='{yz + 4:.1f}' font-size='11' font-weight='600' fill='var(--accent)'>Smart POC {fp(z['price'])} · vol ×{z['volrel']:.1f}</text>")
    for k in ks:
        o_, h_, l_, c_ = m["o"][k], m["h"][k], m["l"][k], m["c"][k]
        col = "var(--up)" if c_ >= o_ else "var(--dn)"
        xc = x(k)
        g.append(f"<line x1='{xc:.1f}' x2='{xc:.1f}' y1='{y(h_):.1f}' y2='{y(l_):.1f}' stroke='{col}'/>"
                 f"<rect x='{xc - cw / 2:.1f}' y='{y(max(o_, c_)):.1f}' width='{cw:.1f}' height='{max(1, y(min(o_, c_)) - y(max(o_, c_))):.1f}' fill='{col}' rx='.6'/>")
    if lp:
        xa = x(max(lp["anchor_bar"], a0) - s0)
        g.append(f"<line x1='{xa:.1f}' x2='{xa:.1f}' y1='{T}' y2='{H - B}' stroke='var(--mute)' stroke-dasharray='2 4'/>"
                 f"<text x='{xa + 4:.1f}' y='{H - B - 4}' font-size='10' fill='var(--mute)'>leg start{' (earlier than shown)' if lp['anchor_bar'] < a0 else ''}</text>")
    xc, yc = x(ks[-1]), y(r["close"])
    tag = f"Close {fp(r['close'])}"
    tw = 6.6 * len(tag) + 16
    g.append(f"<circle cx='{xc:.1f}' cy='{yc:.1f}' r='6' fill='var(--gold)' opacity='.6' filter='url(#vglow{u})'/>"
             f"<circle cx='{xc:.1f}' cy='{yc:.1f}' r='3.2' fill='var(--gold)'/>"
             f"<rect x='{xc + 10:.1f}' y='{yc - 10:.1f}' width='{tw:.0f}' height='20' rx='10' fill='var(--gold)'/>"
             f"<text x='{xc + 10 + tw / 2:.1f}' y='{yc + 4:.1f}' font-size='11' font-weight='700' text-anchor='middle' fill='#1a1a1a'>{tag}</text>")
    for k in (ks[0], ks[-1]):
        g.append(f"<text x='{x(k):.1f}' y='{H - 8}' font-size='11' text-anchor='{'start' if k == ks[0] else 'end'}' fill='var(--mute)'>{fd(m['t'][k], tf).split(' UTC')[0]}</text>")
    g.append("</svg>")
    return spread_labels("".join(g), xr + 6)


VOL_HOW = ("How to read the chart: the grey rows on the right are the leg volume profile, the share of the current leg's volume traded at each price "
           "(24 rows from the leg's low to its high); darker rows are the 70% value area and the gold row is the POC, the price that traded the most. "
           "Shaded boxes are the live order blocks (the last opposite candle before a BOS / CHoCH, mid or high volume only; a dashed edge means price has "
           "already tested it). Dash-dot lines are Smart POC levels: the POC of an earlier leg whose volume reached the 20-leg average, kept until a close "
           "passes through it.")


VOL_NOTE = ("Volume layers describe where the current leg traded, not where price turns. In testing, the first test of a Smart POC "
            "held more often than random levels; order blocks held about as often as random zones, low-volume ones least; "
            "no POC acted as a magnet. Reference levels only.")


def vol_lines(r, t):
    """Plain-language lines for the volume layers of one TF; [] when the data has no volume."""
    V = r.get("volume")
    if not V:
        return []
    out = []
    lp = V.get("leg_profile")
    if lp:
        c = r["close"]
        pos = "above the value area" if c > lp["vah"] else "below the value area" if c < lp["val"] else "inside the value area"
        out.append(f"{t} leg profile from {fd(lp['anchor_time'], t)}: POC {fp(lp['poc'])} holds {lp['poc_share'] * 100:.0f}% of the leg's volume; "
                   f"value area {fp(lp['val'])}–{fp(lp['vah'])}; the last close {fp(c)} is {pos}.")
    sp = V.get("smart_poc", [])
    if sp:
        out.append(f"{t} Smart POC levels (legs with at least the 20-leg average volume): " +
                   ", ".join(f"{fp(z['price'])} (vol ×{z['volrel']:.1f}, {'price above' if z['side'] == 1 else 'price below'}, since {fd(z['time'], t)})" for z in sorted(sp, key=lambda z: -z['price'])) + ".")
    else:
        out.append(f"{t} Smart POC levels: none live (every recent leg had below-average volume, or price has closed through them).")
    ob = V.get("order_blocks", [])
    if ob:
        out.append(f"{t} order blocks (mid / high volume only): " +
                   ", ".join(f"{'Demand' if z['side'] == 1 else 'Supply'} {fp(z['bot'])}–{fp(z['top'])} (vol {z['rank']}{', tested' if z['touched'] else ''})" for z in sorted(ob, key=lambda z: -z['top'])) + ".")
    else:
        out.append(f"{t} order blocks: none live.")
    return out


# ---------- v0.5 full mode: the 12-state dashboard ----------
GROUP_KANJI = {"WAIT": "待 WAIT", "READY": "構 READY", "TREND": "流 TREND", "—": "—"}
STATE_NAMES = ["乱 Volatile", "破 Breakout Up", "破 Breakdown", "押 Pullback Up", "押 Pullback Down", "静 Compressed", "揉 Chop", "昇 Up", "降 Down",
               "横 Sideways Up", "横 Sideways Down", "中 Neutral"]
DASH_HOW = ("How to read the dashboard: the state names what price has been doing on closed bars of that timeframe, grouped as "
            "待 WAIT (乱 Volatile = volatility rank ≥ 90% with a rough path · 揉 Chop = rough path, no trend · 中 Neutral = none of the others), "
            "構 READY (押 Pullback Up / Down = a counter-move into the pullback zone of a held trend · 静 Compressed = volatility rank ≤ 10% while the trend rule is off) and "
            "流 TREND (破 Breakout Up / Breakdown = a clean close out of a compress box, held a few bars · 昇 Up / 降 Down = Efficiency Ratio ≥ 0.30 and "
            "momentum rank ≥ 66% · 横 Sideways Up / Down = momentum rank ≥ 33% with a path that is neither clean enough for Up / Down nor rough enough for Chop). Volatile and Breakout replace the state at once; "
            "any other change waits for the hold (Scalp 1 / Swing 2 / Position 3 bars, Chop ↔ Neutral 3, and 3 bars in the group before the group changes). "
            "Reason = the slow momentum (mL, the move over the Style's momentum look-back) in ATR with its one-year rank, the Efficiency Ratio and the ATR rank. HTF = the same momentum on the next higher timeframe's "
            "last completed bar: ✓ same direction, ⚠ opposite, grey = weak or no trend here. Levels = the pullback Floor / Ceiling while a trend is held, "
            "otherwise the swing high / low of the look-back. These describe state; none of them is a trade level.")
DASH_NOTE = ("Full mode runs the structure engine on a longer window (about a year of bars per timeframe) than quick mode, so swing-leg percentiles and the "
             "30-block / 20-leg volume histories can differ from a quick-mode run of the same day; the structure, Protected level and events are the same rules.")


def dash_state(d):
    return f"{GROUP_KANJI.get(d['group'], '—')} · {d['name']}"


def dash_htf(d, t):
    h = d["htf"]
    hD = " Up" if (h["dir"] or 0) > 0 else " Down" if (h["dir"] or 0) < 0 else " flat"
    cD = " Up" if d["dir"] > 0 else " Down" if d["dir"] < 0 else " no trend"
    if h["relation"] == "n/a":
        return f"{h['tf']} n/a — not enough history"
    if h["relation"] == "conflict":
        return f"⚠ {h['tf']}{hD} vs {t}{cD}"
    if h["relation"] == "same":
        return f"✓ {h['tf']}{hD} = {t}{cD}"
    return f"{h['tf']}{hD if (h['pct'] or 0) >= 33 else ' flat'} · {t}{cD}"


def dash_rows(r, t):
    """(key, value) rows of the dashboard for one timeframe, in the indicator's order."""
    d = r["dashboard"]
    rows = [("State", dash_state(d)), ("State age", f"{d['state_bars']} bars in this state · {d['group_bars']} bars in this group"), ("Reason", d["reason"])]
    rows.append(("HTF", dash_htf(d, t)))
    m = d["move"]
    if m["mL"] is not None and m["er"] is not None:
        rows.append(("Move (last closed bar)", f"mL {m['mL']:+.1f} ATR · ER {m['er']:.2f} · Vol rank {int(math.floor(m['atr_pct'] + .5))}%"))
    hh = next((x["label"] for x in reversed(r["swing_seq"]) if x["label"] in ("HH", "LH")), None)
    ll = next((x["label"] for x in reversed(r["swing_seq"]) if x["label"] in ("HL", "LL")), None)
    hs = f"{hh} · {ll}" if hh and ll else "—"
    rows.append(("Structure", f"{word(r['structure'])} ({hs})" + (f" · protected {fp(r['protected'])}" if r["protected"] is not None else "")))
    tm = d["trend_memory"]
    if tm["dir"] != 0:
        rows.append(("Levels", f"{'Floor' if tm['dir'] == 1 else 'Ceiling'} {fp(d['zone']['floor']) if d['zone']['floor'] is not None else '—'} · Protected {fp(r['protected'])}"))
    else:
        rows.append(("Levels", f"Swing H {fp(d['swing_hi'])} · L {fp(d['swing_lo'])}"))
    mk = f"{d['market']} (" + (f"{d['bars_per_day']} bars/day × " if d["bars_per_day"] else "") + f"{d['days']} d)"
    sk = f"{d['style_eff']} (auto · {d['period']})" if d["style_auto"] else d["style_eff"]
    rows.append(("Preset", f"{mk} · {sk} · rank window {d['rank_bars']} bars"))
    return rows


def dash_strip(r):
    """The last closed states as a strip, one cell per bar (same window as the structure map)."""
    d = r["dashboard"]
    hist = d["history"]
    n = len(hist)
    if not n:
        return ""
    W, H = 860, 22
    cw = W / n
    cells = []
    for k, s in enumerate(hist):
        g, sd = ("—" if s == 0 else "WAIT" if s in (1, 7, 12) else "READY" if 4 <= s <= 6 else "TREND"), (1 if s in (2, 4, 8, 10) else -1 if s in (3, 5, 9, 11) else 0)
        col = "var(--line)" if g == "—" else "#E69F00" if g == "WAIT" else "#0072B2" if g == "READY" else ("var(--up)" if sd >= 0 else "var(--dn)")
        cells.append(f"<rect x='{k * cw:.1f}' y='0' width='{cw + .3:.1f}' height='{H}' fill='{col}' opacity='{.9 if g == 'TREND' else .75}'><title>{e(STATE_NAMES[s - 1] if s else 'warming up')}</title></rect>")
    return (f"<svg class='strip' viewBox='0 0 {W} {H + 14}' width='100%' preserveAspectRatio='none' xmlns='http://www.w3.org/2000/svg'>" + "".join(cells) +
            f"<text x='0' y='{H + 11}' font-size='9' fill='var(--mute)'>{n} closed bars → last</text></svg>")


def dash_summary(r, t):
    d = r["dashboard"]
    return f"Dashboard: {t} reads {dash_state(d)}, {d['state_bars']} bars in this state ({d['reason']}); HTF {dash_htf(d, t)}."



def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--astr", required=True)
    ap.add_argument("--chart-table", default="")
    ap.add_argument("--update-mode", default="", help="TradingView update_mode of the symbol, e.g. streaming, delayed_streaming_900, endofday")
    ap.add_argument("--generated", default=datetime.now().strftime("%Y-%m-%d"))
    ap.add_argument("--out-html", required=True)
    ap.add_argument("--out-txt", required=True)
    a = ap.parse_args()
    A = json.load(open(a.astr))
    sym, ctf = A["symbol"], A["chart_tf"]
    tfs = [t for t in TF_ORDER if t in A["tfs"]] + [t for t in A["tfs"] if t not in TF_ORDER]
    R = A["tfs"][ctf]
    st = R["structure"]

    # optional parity with the dashboard read from the chart
    parity = None
    if a.chart_table:
        rows = json.load(open(a.chart_table)).get("rows", [])
        srow = next((x for x in rows if x.startswith("Structure")), "")
        m = re.search(r"protected\s+([\d.,]+)", srow)
        chart_dir = "Uptrend" if "Bullish" in srow else "Downtrend" if "Bearish" in srow else "None"
        chart_prot = float(m.group(1).replace(",", "")) if m else None
        same = chart_dir == st and (chart_prot is None or R["protected"] is None or abs(chart_prot - R["protected"]) <= 1e-6 + abs(R["protected"]) * 1e-4)
        chart_state = next((nm for nm in STATE_NAMES if any(nm in x for x in rows)), None)      # v0.5: the state cell, when the rows carry one
        if chart_state and R.get("dashboard"):
            same = same and chart_state == R["dashboard"]["name"]
        parity = (same, chart_dir, chart_prot, chart_state)

    # ---------- wording ----------
    since = R["last_choch"]
    summary = f"{ctf} structure: {word(st)}"
    if since:
        summary += f" since the CHoCH on {fd(since['time'], ctf)}"
    summary += f"; last event {last_event(R, ctf)}."
    lines = [summary, leg_text(R)]
    bo = bo_text(R)
    if bo:
        lines.append(bo)
    htf = next((t for t in tfs if t in TF_ORDER and ctf in TF_ORDER and TF_ORDER.index(t) > TF_ORDER.index(ctf)), None)
    if htf:
        hs = A["tfs"][htf]["structure"]
        rel = f"same direction as {ctf}" if hs == st and st != "None" else f"opposite to {ctf}" if {hs, st} == {"Uptrend", "Downtrend"} else f"no match with {ctf}"
        lines.append(nested_text(A) or f"{htf} structure is {word(hs)} ({rel}).")
    legs = leg_sentence(R, ctf)
    if legs:
        lines.append(legs)
    full = A.get("mode") == "full" and all(A["tfs"][t].get("dashboard") for t in tfs)
    if full:
        lines.append(dash_summary(R, ctf))

    f = R["fib"]

    side_a, side_b = [], []          # supports current structure / would change it
    if st != "None":
        side_a.append(f"{last_event(R, ctf)}.")
        if f:
            if st == "Downtrend" and f["retrace_pct"] < 38.2:
                side_a.append(f"Price has recovered only {f['retrace_pct']:.1f}% of the down leg.")
            if st == "Uptrend" and f["retrace_pct"] < 38.2:
                side_a.append(f"Price has given back only {f['retrace_pct']:.1f}% of the up leg.")
        side_b.append(f"The Protected level {fp(R['protected'])}: a close beyond it is a CHoCH.")
    if f and "bottom_out" in f:
        b = f["bottom_out"]
        (side_b if b["stable_ok"] else side_a).append("Bottom-out Stable ✓ is in place." if b["stable_ok"] else "No close above the Bottom-out Stable area yet.")
        if b["confirm_ok"]:
            side_b.append("Bottom-out Confirm ✓ is in place.")
    if htf:
        hs = A["tfs"][htf]["structure"]
        if hs == st and st != "None":
            side_a.append(f"{htf} structure points the same way.")
        elif {hs, st} == {"Uptrend", "Downtrend"}:
            side_b.append(f"{htf} structure points the other way ({word(hs)}).")
    ls = R["last_sweep"]
    if ls and R["last_closed"] - ls["bar"] <= 10:
        side_b.append(f"A liquidity sweep {ls['side']} {fp(ls['price'])} on {fd(ls['time'], ctf)}: a wick through, close back inside.")

    if ls and R["last_closed"] - ls["bar"] <= 10:
        learn = ("Sweep vs break. A wick beyond a swing that closes back inside is a sweep; structure only changes on a close beyond "
                 "the level. That is why every reading here uses closed bars.")
    elif f and "bottom_out" in f:
        learn = ("Bottom-out areas mark the recovery depth of the down leg, measured up from its low: Stable 23.6–38.2%, Confirm 38.2–50% of the leg. "
                 "They are depth marks, not Fibonacci support: a ✓ only says a close has moved above the area; the structure itself still changes only at the Protected level.")
    else:
        learn = ("The Protected level is the swing that started the latest BOS move. While closes stay on its side, the structure holds; "
                 "a close beyond it is a CHoCH, a change of character.")

    LR = max(A["tfs"].values(), key=lambda r: r["last_time"] or 0)       # most recent bar of any TF
    dm = data_mode(a.update_mode)
    fresh = (f"last price {fp(LR['last_price'])} at {fd(LR['last_time'], '1H')} ({LR['tf']} bar)"
             + (f" · data {dm}" if dm else "")
             + (" · session closed, latest 1D bar counted as closed" if A.get("session_over") else ""))
    stale = None
    age_d = (A.get("run_ts", 0) - A.get("asof_ts", 0)) / 86400 if A.get("asof_ts") else 0
    if age_d > 4:
        stale = f"The newest bar in this data is {age_d:.0f} days old ({A['asof']}). Fetch fresh bars and run again before reading this report."
    sw_notes = [x for x in (swing_note(A["tfs"][t], t) for t in tfs) if x]
    sw_chart = swing_note(R, ctf)
    if sw_chart:
        lines.append(sw_chart)
    live = live_text(R, ctf)
    if live:
        lines.insert(1, live)

    # ---------- HTML ----------
    has_vol = any(A["tfs"][t].get("volume") for t in tfs)
    layers = "structure, Protected level, Fibonacci leg, Bottom-out areas, liquidity zones" + (", order blocks, leg volume profile and Smart POC levels" if has_vol else "")
    mode_name = "FULL MODE" if full else "QUICK MODE"
    mode_line = ((f"FULL MODE: {layers} on every timeframe, plus the indicator's 12-state dashboard (state, Reason, HTF, Move, Levels, Preset) "
                  "rebuilt from about a year of bars per timeframe.") if full else
                 (f"QUICK MODE: {layers} on every timeframe. The 12-state dashboard is not rebuilt in this mode (add `full` for it)."))
    mode_line += "" if has_vol else " The data has no volume, so the volume layers (order blocks, leg profile, Smart POC) are skipped."
    body = [f"<div class='seal'>構<br>造</div><div class='brand'>ITTO-RYU · AUTO STRUCTURE READ</div>",
            f"<h1>{e(sym)} <span class='badge'>{mode_name}</span></h1>",
            f"<div class='meta'>Chart TF {ctf} · <b>{e(fresh)}</b> · data as of {e(A['asof'])} · generated {e(a.generated)} · readings use closed bars only</div>",
            f"<div class='setup'><b>{mode_line}</b><div class='sm'>Settings used: Swing size {A['inputs']['swing_k']} × ATR(14) · Style {A['inputs']['style']} "
            f"(pivot bars by TF: {', '.join(f'{t} {A['tfs'][t]['pivot_bars']}' for t in tfs)}). Do these match your Auto Structure inputs? "
            f"If not, run again, e.g. <code>autostruct-read-en {e(sym)} {ctf} swing 2.5</code>.</div></div>"]
    if stale:
        body.append(f"<div class='warn'>⚠ {e(stale)}</div>")
    if parity:
        ok, cd, cp, cs = parity
        body.append(f"<div class='{'card' if ok else 'warn'}'>{'✓' if ok else '⚠'} Chart parity: the Auto Structure dashboard on your chart reads "
                    f"{e(word(cd))}, protected {fp(cp)}{(' · state ' + e(cs)) if cs else ''}; the skill computed {e(word(st))}, protected {fp(R['protected'])}"
                    f"{(' · state ' + e(R['dashboard']['name'])) if cs and R.get('dashboard') else ''}.</div>")
    sts, align = snapshot(A, tfs)
    body.append("<div class='card'><h2>Structure snapshot</h2><div class='snap'>" +
                "".join(f"<div class='chip {cls(v)}'><b>{t}{' · chart' if t == ctf else ''}</b><span>{word(v)}</span>"
                        f"<div class='note'>Protected {atr_d(A['tfs'][t], A['tfs'][t]['protected']) or '—'}{' · close to a CHoCH' if near_prot(A['tfs'][t]) else ''}</div></div>" for t, v in sts.items()) +
                f"</div><p style='margin:10px 0 0'>{e(align)}</p>" + (f"<p class='note'>{e(align_line(A, align))}</p>" if align_line(A, align) else "") + "</div>")
    body.append("<div class='card verdict'><h2>Summary · " + ctf + "</h2>" + "".join(f"<p>{e(x)}</p>" for x in lines) + "</div>")
    if full:
        body.append("<div class='card'><h2>Dashboard · 12 states · full mode</h2>" +
                    "".join(f"<div class='tfh'>{t}{' · chart' if t == ctf else ''} · {e(dash_state(A['tfs'][t]['dashboard']))}</div><div class='lwrap'>{dash_strip(A['tfs'][t])}</div>"
                            "<table class='dash'>" + "".join(f"<tr><th>{e(k)}</th><td>{e(v)}</td></tr>" for k, v in dash_rows(A['tfs'][t], t)) + "</table>" for t in tfs) +
                    "<div class='legend'><span><i class='bx' style='background:var(--up)'></i>TREND up</span><span><i class='bx' style='background:var(--dn)'></i>TREND down</span>"
                    "<span><i class='bx' style='background:#0072B2'></i>READY</span><span><i class='bx' style='background:#E69F00'></i>WAIT</span></div>"
                    f"<div class='note'>{e(DASH_HOW)}</div><div class='note'>{e(DASH_NOTE)}</div></div>")
    body.append(f"<div class='card'><h2>Structure map · {ctf} · last {len(R['map']['c'])} closed bars</h2><div class='lwrap'>{map_svg(R, ctf)}</div>"
                "<div class='legend'><span><i class='sw' style='border-color:var(--up)'></i>BOS / CHoCH up</span><span><i class='sw' style='border-color:var(--dn)'></i>BOS / CHoCH down</span>"
                "<span><i class='sw' style='border-color:var(--prot)'></i>Protected level</span><span><i class='sw' style='border-color:var(--gold);border-top-style:solid'></i>Fib 61.8%</span>"
                "<span><i class='bx' style='background:#56b4e9;opacity:.4'></i>Bottom-out Stable</span><span><i class='bx' style='background:#009e73;opacity:.4'></i>Bottom-out Confirm</span>"
                "<span><i class='bx' style='background:var(--liq);opacity:.35'></i>Liquidity zone · ◆ sweep</span>"
                + ("<span><i class='bx' style='background:#7fb3d5;opacity:.5'></i>Demand block</span><span><i class='bx' style='background:#e6a29c;opacity:.5'></i>Supply block</span>"
                   "<span><i class='sw' style='border-color:#e67e22;border-top-style:solid'></i>Smart POC · dotted = leg POC</span>" if R.get('volume') else "") + "</div></div>")
    trs = []
    for t in tfs:
        r = A["tfs"][t]
        ff = r["fib"]
        leg = "—" if not ff else f"{ff['retrace_pct']:.1f}% · {r['phase']}"
        sq = " · ".join(x["label"] for x in r["swing_seq"]) or "—"
        trs.append(f"<tr><td><b>{t}</b>{' <span class=note>(chart)</span>' if t == ctf else ''}</td><td class='{cls(r['structure'])}'>{word(r['structure'])}</td>"
                   f"<td>{e(since_text(r))}</td><td>{r['bos_count'] if r['structure'] != 'None' else '—'}</td><td>{sq}</td><td>{leg}</td>"
                   f"<td class='note'>{e(leg_age(r))}</td><td class='note'>{e(leg_size(r))}</td>"
                   f"<td>{fp(r['protected'])}<div class='note'>{atr_d(r, r['protected'])}</div></td><td class='note'>{e(fd(r['time'], t))}</td></tr>")
    body.append("<div class='card'><h2>Structure by timeframe</h2><div class='lwrap'><table><tr><th>TF</th><th>Structure</th><th>Since CHoCH</th><th>BOS since</th>"
                "<th>Last swings</th><th>Leg position</th><th>Leg age</th><th>Leg size</th><th>Protected</th><th>Last closed bar</th></tr>" + "".join(trs) +
                "</table></div><div class='note'>BOS since = breaks in the trend direction since the structure turned (trend age). Last swings = the latest "
                "four ATR swings, each against the previous one of its kind (HH/LH, HL/LL). Leg position = how much of the leg from the Protected "
                "level to the latest extreme has moved back: near the extreme &lt;23.6%, pullback 23.6–61.8%, deep pullback ≥61.8%. "
                "Leg age / size = the leg from the Protected level to its extreme: bars and calendar time, height in ATR(14), and the share of the "
                "completed ATR-swing legs in the same window that were smaller or shorter (a description of size, not a limit). "
                "ATR = distance from the last close in ATR(14) of that timeframe; ATR_D = the same distance in the 1D ATR(14), so timeframes can be compared.</div>" +
                ("<ul class='lv'>" + "".join(f"<li>{e(x)}</li>" for x in sw_notes) + "</ul>" if sw_notes else "") + "</div>")
    ev = events(A, tfs)
    if ev:
        body.append("<div class='card'><h2>Recent events · all timeframes</h2><ul class='tl'>" +
                    "".join(f"<li><b>{t}</b> · {e(fd(tt, t))} · {e(x)}{'<span class=new>NEW</span>' if nw else ''}</li>" for tt, t, x, nw in ev) +
                    "</ul><div class='note'>NEW = within the last two closed bars of that timeframe. Sweep = a wick through a liquidity zone with a close back inside.</div></div>")
    body.append("<div class='card'><h2>What changes the structure</h2>" +
                "".join(f"<div class='tfh'>{t} · {word(A['tfs'][t]['structure'])}</div><ul class='lv'>" + "".join(f"<li>{e(x)}</li>" for x in tf_levels(A["tfs"][t], t)) + "</ul>" for t in tfs) +
                "<div class='note'>These describe how each structure reading would change on a close. They are not trade levels.</div></div>")
    bo_tfs = [t for t in tfs if A["tfs"][t]["structure"] == "Downtrend" and A["tfs"][t]["fib"] and "bottom_out" in A["tfs"][t]["fib"]]
    if bo_tfs:
        body.append("<div class='card'><h2>Position in the down leg · Bottom-out</h2>" +
                    "".join(f"<p><b>{e(bo_head(A['tfs'][t], t))}</b></p><div class='lwrap'>{bo_svg(A['tfs'][t], t)}</div><ul class='lv'>" + "".join(f"<li>{e(x)}</li>" for x in bo_zone_lines(A["tfs"][t], t)) + "</ul>" for t in bo_tfs) +
                    "<div class='note'>Shown for every timeframe in a Downtrend. It describes where price is on the leg, not a trade level.</div></div>")
    if has_vol:
        body.append("<div class='card'><h2>Volume layers · order blocks, leg profile, Smart POC</h2>" +
                    "".join(f"<div class='tfh'>{t}</div><div class='lwrap'>{vol_svg(A['tfs'][t], t)}</div><ul class='lv'>" + "".join(f"<li>{e(x)}</li>" for x in vol_lines(A['tfs'][t], t)) + "</ul>" for t in tfs if A['tfs'][t].get('volume')) +
                    f"<div class='note'>{e(VOL_HOW)}</div><div class='note'>{e(VOL_NOTE)}</div></div>")
    body.append("<div class='card'><h2>Both sides</h2><div class='two'><div class='card sa'><b>What supports the current structure</b><ul>" +
                "".join(f"<li>{e(x)}</li>" for x in side_a) + "</ul></div><div class='card sb'><b>What to watch for a change</b><ul>" +
                "".join(f"<li>{e(x)}</li>" for x in side_b) + "</ul></div></div></div>")
    body.append(f"<div class='card'><h2>Learning note</h2><p><span class='tag'>Structure</span>{e(learn)}</p></div>")
    body.append(f"<div class='disc'>{DISC}</div>")
    page = (f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>{e(sym)} Auto Structure Read</title><style>{CSS}</style></head><body><div class='wrap'>{''.join(body)}</div></body></html>")
    open(a.out_html, "w", encoding="utf-8").write(page)

    # ---------- text ----------
    txt = [f"AUTO STRUCTURE READ · {sym} · chart TF {ctf} · {fresh} · data as of {A['asof']} · {mode_name}",
           *( [f"WARNING: {stale}"] if stale else [] ),
           f"Settings used: Swing size {A['inputs']['swing_k']} x ATR(14), Style {A['inputs']['style']}. Do these match your Auto Structure inputs?", ""]
    if not has_vol:
        txt.insert(1, "NOTE: the data has no volume, so the volume layers (order blocks, leg profile, Smart POC) are skipped.")
    if parity:
        txt += [f"{'OK' if parity[0] else 'CHECK'} chart parity: chart {word(parity[1])} / protected {fp(parity[2])}{(' / state ' + parity[3]) if parity[3] else ''}; "
                f"computed {word(st)} / protected {fp(R['protected'])}{(' / state ' + R['dashboard']['name']) if parity[3] and R.get('dashboard') else ''}", ""]
    txt += ["STRUCTURE SNAPSHOT", "  ".join(f"{t} {word(v)} (Protected {atr_d(A['tfs'][t], A['tfs'][t]['protected']) or '—'}{', close to a CHoCH' if near_prot(A['tfs'][t]) else ''})" for t, v in sts.items()), align]
    if align_line(A, align):
        txt.append(align_line(A, align))
    txt.append("")
    txt += [f"SUMMARY · {ctf}"] + [f"- {x}" for x in lines] + ["", "STRUCTURE BY TIMEFRAME"]
    for t in tfs:
        r = A["tfs"][t]
        ff = r["fib"]
        leg = "—" if not ff else f"{ff['retrace_pct']:.1f}% ({r['phase']})"
        sq = "·".join(x["label"] for x in r["swing_seq"]) or "—"
        txt.append(f"- {t}: {word(r['structure'])} since {since_text(r)} · BOS since {r['bos_count'] if r['structure'] != 'None' else '—'} · swings {sq} · "
                   f"leg {leg} · leg age {leg_age(r)} · leg size {leg_size(r)} · protected {fp(r['protected'])} ({atr_d(r, r['protected'])}) · last closed bar {fd(r['time'], t)}")
    txt += [f"- {x}" for x in sw_notes if x != sw_chart]
    if full:
        txt += ["", "DASHBOARD · 12 STATES (full mode)"]
        for t in tfs:
            txt.append(f"{t}{' (chart)' if t == ctf else ''}:")
            txt += [f"- {k}: {v}" for k, v in dash_rows(A["tfs"][t], t)]
        txt += [DASH_HOW, DASH_NOTE]
    if ev:
        txt += ["", "RECENT EVENTS (all timeframes)"] + [f"- {t} · {fd(tt, t)} · {x}{'  [NEW]' if nw else ''}" for tt, t, x, nw in ev]
    txt += ["", "WHAT CHANGES THE STRUCTURE (describes state, not trade levels)",
            "ATR = distance from the last close in that timeframe's ATR(14); ATR_D = the same distance in the 1D ATR(14), so timeframes can be compared."]
    for t in tfs:
        txt += [f"{t} · {word(A['tfs'][t]['structure'])}:"] + [f"- {x}" for x in tf_levels(A["tfs"][t], t)]
    if bo_tfs:
        txt += ["", "POSITION IN THE DOWN LEG · BOTTOM-OUT"] + [x for t in bo_tfs for x in [f"{bo_head(A['tfs'][t], t)}:"] + [f"- {y}" for y in bo_zone_lines(A["tfs"][t], t)]]
    if has_vol:
        txt += ["", "VOLUME LAYERS (order blocks, leg profile, Smart POC · reference levels, not turning points)"] + [f"- {x}" for t in tfs if A['tfs'][t].get('volume') for x in vol_lines(A['tfs'][t], t)] + [VOL_NOTE]
    txt += ["", "WHAT SUPPORTS THE CURRENT STRUCTURE"] + [f"- {x}" for x in side_a]
    txt += ["", "WHAT TO WATCH FOR A CHANGE"] + [f"- {x}" for x in side_b]
    txt += ["", "LEARNING NOTE", learn, "", "-" * 60, DISC_TXT]
    open(a.out_txt, "w", encoding="utf-8").write("\n".join(txt) + "\n")
    print(f"wrote {a.out_html} and {a.out_txt}")


if __name__ == "__main__":
    main()
