#!/usr/bin/env python3
"""Check a report for advice language before it is shown. Python standard library only.

Usage: python3 lint_report.py report.html [report.txt ...]
Exit code 1 if a banned term appears outside the disclaimer block.
The disclaimer is marked with class="disc" (either quote style) in HTML and starts with "DISCLAIMER" in text.
"""
import re, sys

BANNED_EN = [r"\bbuy\b", r"\bsell\b", r"\bentry\b", r"\bstop[- ]?loss\b", r"\bSL\b", r"\bTP\b", r"\btake[- ]?profit\b",
             r"\btarget\b", r"\bshould\b", r"\brecommend", r"\bgo long\b", r"\bgo short\b", r"\bbullish\b", r"\bbearish\b", r"\blong\b", r"\bshort\b", r"\bbias\b", r"\bforecast\b", r"\bwill (rise|fall|go)\b"]
BANNED_TH = []  # English-only edition


def strip_disclaimer(text):
    text = re.sub(r"<(style|script)\b.*?</\1>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<div class=['\"]disc['\"]>.*?</div>", " ", text, flags=re.S)
    text = re.sub(r"(?ms)^(DISCLAIMER|ข้อจำกัดความรับผิดชอบ).*\Z", " ", text)
    text = re.sub(r"<[^>]+>", " ", text)          # tags and attributes
    return text


def main():
    bad = 0
    for path in sys.argv[1:]:
        t = strip_disclaimer(open(path, encoding="utf-8").read())
        hits = [p for p in BANNED_EN if re.search(p, t, flags=re.I)] + [w for w in BANNED_TH if w in t]
        if hits:
            bad += 1
            print(f"FAIL {path}: {hits}")
        else:
            print(f"PASS {path}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
