#!/usr/bin/env python3
"""End-to-end self test with synthetic data (no market data is shipped with this skill)."""
import json, math, os, random, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(HERE, "..", "scripts")
SEC = {"1H": 3600, "4H": 14400, "1D": 86400, "1W": 604800}


def series(n, start, drift, seed, tf, now):
    random.seed(seed)
    h, l, c, t, p = [], [], [], [], start
    t0 = int(now) - (n - 1) * SEC[tf] - SEC[tf] // 2          # last bar still forming
    for i in range(n):
        p *= 1 + drift + 0.01 * math.sin(i / 7) + random.uniform(-0.006, 0.006)
        rng = p * random.uniform(0.003, 0.012)
        h.append(round(p + rng / 2, 4)); l.append(round(p - rng / 2, 4)); c.append(round(p, 4)); t.append(t0 + i * SEC[tf])
    return {"bars": {"t": t, "h": h, "l": l, "c": c}, "symbol": "TEST:SYNTH"}


def run(*args):
    r = subprocess.run([sys.executable, "-I", *args], capture_output=True, text=True)
    print((r.stdout.strip() + " " + r.stderr.strip()).strip())
    if r.returncode:
        sys.exit(f"FAILED: {' '.join(args)}")


def main():
    d = tempfile.mkdtemp()
    j = lambda f: os.path.join(d, f)
    now = time.time()
    for tf, n, drift, seed in (("1W", 120, 0.004, 1), ("1D", 340, -0.002, 2), ("4H", 120, 0.0, 3), ("1H", 120, 0.001, 4)):
        json.dump(series(n, 100, drift, seed, tf, now), open(j(f"{tf}.json"), "w"))
    raw = {"rows": ["ICHIMOKU ITTO · One Glance, One Cut", "Score | 25%", "Zone | Ranging", "Kumo | Thick",
                    "TF | Score | Aligned", "1H | 50% | Up", "4H | 0% | Mixed", "D | -50% | Down", "W | 100% | Up", "Trend | MIXED"],
           "plots": {"Kijun (Blade)": "1.000"}, "chart_tf": "1D", "symbol": "TEST:SYNTH", "asof": "synthetic", "input_level": 2,
           "source": "selftest"}
    json.dump(raw, open(j("raw.json"), "w"))
    run(os.path.join(S, "ohlcv_to_data.py"), "1W=" + j("1W.json"), "1D=" + j("1D.json"), "4H=" + j("4H.json"), "1H=" + j("1H.json"), "--out", j("data.json"))
    run(os.path.join(S, "compute.py"), "--data", j("data.json"), "--chart-tf", "1D", "--mode", "full", "--out", j("ichi.json"))
    I = json.load(open(j("ichi.json")))
    assert I["tfs"]["1D"]["forming_last_bar"] is True, "last bar should be forming"
    assert I["tfs"]["1D"]["itto"]["kumo_class"] in ("Thin", "Normal", "Thick"), "kumo class needs 340 bars"
    run(os.path.join(S, "parse_tables.py"), j("raw.json"), "--out", j("dashboard.json"))
    for lang in ("en",):
        run(os.path.join(S, "render.py"), "--ichi", j("ichi.json"), "--lang", lang, "--generated", "selftest",
            "--out-html", j(f"r1_{lang}.html"), "--out-txt", j(f"r1_{lang}.txt"))
    run(os.path.join(S, "render.py"), "--ichi", j("ichi.json"), "--dashboard", j("dashboard.json"), "--no-jp", "--out-html", j("r2.html"), "--out-txt", j("r2.txt"))
    run(os.path.join(S, "render.py"), "--dashboard", j("dashboard.json"), "--out-html", j("r0.html"), "--out-txt", j("r0.txt"))
    run(os.path.join(S, "lint_report.py"), *[j(f) for f in ("r1_en.html", "r1_en.txt", "r2.html", "r2.txt", "r0.html")])
    print(f"OK — outputs in {d} (r2 parity lines are expected to show ⚠ because the test dashboard is fake)")


if __name__ == "__main__":
    main()
