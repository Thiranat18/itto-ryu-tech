# Glossary

| English | Japanese |
|---|---|
| Ichimoku Kinkō Hyō | 一目均衡表 |
| Tenkan-sen (conversion line) | 転換線 |
| Kijun-sen (base line) | 基準線 |
| Senkou Span A / B (leading spans) | 先行スパンA / B |
| Kumo (cloud) | 雲 |
| Future Kumo | 先行雲 |
| Kumo twist | 雲のねじれ |
| Chikou Span (lagging span) | 遅行スパン |
| Sanyaku (three roles) | 三役 |
| Sanyaku Kōten (all three strong) | 三役好転 |
| Sanyaku Gyakuten (all three weak) | 三役逆転 |
| Equilibrium | 均衡 |
| At a glance | 一目瞭然 |
| Report section names used with Japanese accents: Summary 総括 · State 状態 · Levels 水準 · Reading 読み · Change points 変化点 · Weak side 陰 · Strong side 陽 · Learning 学び | |
