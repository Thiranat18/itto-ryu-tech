# Principles used by ichimoku-itto-read

Two kinds of statements appear in reports:

- **Classic**: general Ichimoku Kinkō Hyō (一目均衡表) knowledge with standard settings 9/26/52.
- **Itto**: Itto-ryu's own reading, written and versioned by the indicator author below.

The skill may only explain what is written here. Anything not covered is shown as a value without
interpretation.

## Classic

| Component | Built from | Principle |
|---|---|---|
| Tenkan-sen 転換線 | midpoint of the last 9 highs/lows | Short-term momentum / short-term balance. |
| Kijun-sen 基準線 | midpoint of the last 26 highs/lows | Medium-term equilibrium. Price far from Kijun is stretched; a return toward it is common, with no timing implied. A flat Kijun marks an equilibrium that is not moving. |
| Senkou Span A 先行スパンA | (Tenkan + Kijun) / 2, plotted 26 bars ahead | Faster edge of the Kumo. |
| Senkou Span B 先行スパンB | midpoint of the last 52 highs/lows, plotted 26 bars ahead | Slower edge of the Kumo. |
| Kumo 雲 | area between Span A and Span B | Medium-term equilibrium zone. Price above: structure on the strong side, Kumo below acts as support. Price below: weak side, Kumo above acts as resistance. Inside: undecided. Thickness shows how much price has to travel through. |
| Future Kumo 先行雲 | Span A/B as plotted 26 bars ahead | Where equilibrium will sit if nothing changes. A colour change (Kumo twist 雲のねじれ) is a shift of future balance, not price confirmation. |
| Chikou Span 遅行スパン | today's close plotted 26 bars back | Confirms whether price is beating or losing to price 26 bars ago. |
| Sanyaku 三役 | price vs Kumo, Tenkan vs Kijun, Chikou vs past price | All three strong = Sanyaku Kōten 好転; all three weak = Sanyaku Gyakuten 逆転. Describes agreement, not duration. |

Computation notes (match TradingView's built-in Ichimoku):
- Plot offset = displacement − 1 = 25 bars for the Classic preset (the 26-period convention counts the current bar).
- "Current Kumo" under the latest bar = Span A/B computed 25 bars earlier.
- "Future Kumo" = Span A/B computed on the latest bar (these are the values the chart plots as Senkou A/B on the latest bar).
- Chikou compares the latest close with the high/low of the bar 25 bars back (the bar it is plotted against).

## Itto (mirrors the Ichimoku Itto source, Pine v6, MPL-2.0)

Defaults: preset Classic 9/26/52/26, Kijun slope lookback 5, Strong threshold 4 (80%), Chop score band 1 (20%),
magnets after 8 flat bars, keep last 6. Cloud offset = displacement − 1 (same as TradingView's built-in Ichimoku).

| Dashboard field | Rule |
|---|---|
| Score | Five checks, each +1 / −1 / 0: (1) close vs current Kumo, (2) Tenkan vs Kijun, (3) Chikou: close vs the high/low of the bar it is plotted against, (4) future Kumo colour (Span A vs Span B), (5) Kijun vs Kijun 5 bars ago. Sum −5…+5, shown as −100%…+100% (each point = 20%). Chart-TF row uses the live bar. |
| Zone | **Chop** when price is inside the current Kumo or \|score\| ≤ 1 (≤ 20%), otherwise **Trending**. Chop overrides the Trend label and blocks Strong marks. |
| Kumo | Thickness \|Span A − Span B\| of the current cloud, percent-ranked against the previous 252 bars: **Thin** < 20, **Thick** > 80, else **Normal**. |
| TF rows (1H, 4H, D, W) | Score and Aligned of the latest **closed** bar of each timeframe, the same on any chart TF. |
| Aligned | **Up** when checks 1–3 are all +1 (Sanyaku Kōten 三役好転), **Down** when all −1 (Sanyaku Gyakuten 三役逆転), else None. |
| Trend | Chop → CHOP ZONE · NO ACTION; else ≥ +4 STRONG UP, ≥ +3 UP, > 0 SIDEWAYS UP, ≤ −4 STRONG DOWN, ≤ −3 DOWN, < 0 SIDEWAYS DOWN, 0 SIDEWAYS. |
| Strong Up / Strong Down marks | On a confirmed bar outside Chop where the score crosses up through +4 (down through −4). |
| 3/3 Aligned Up / Down labels | On the first confirmed bar where Aligned becomes Up / Down. |
| Equilibrium Magnets | A level is marked when Kijun (or Span B) stays at the same value for 8 bars in a row; the last 6 are kept. Span B magnets are drawn at the projected position. |
| Kijun (Blade) | Classic Kijun-sen, coloured by score; grey in Chop. |

Itto reading principles (author): add Itto-ryu reading rules here, one per line, each with a short
name so reports can tag them `[Itto: name]`.
