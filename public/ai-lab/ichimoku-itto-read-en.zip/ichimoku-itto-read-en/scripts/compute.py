#!/usr/bin/env python3
"""Ichimoku Itto engine: classic Ichimoku + the Ichimoku Itto dashboard, computed from OHLC.
Python standard library only. Mirrors "Ichimoku Itto by [Itto-Ryu]" (Pine v6, MPL-2.0):
Ken-Tai core kt_ichimoku / kt_score / kt_sanyaku / kt_kumoThickPct / kt_mtf, the dashboard
table, Strong / Aligned events and Equilibrium Magnets.

Input (pick one):
  --data data.json   {"symbol": "...", "asof": "...",
                      "tfs": {"1D": {"t": [...], "h": [...], "l": [...], "c": [...]}, ...}}
                     (t = bar open time, unix seconds, optional but needed to tell a forming bar)
  --csv 1D=daily.csv ...   (TradingView export: time, high, low, close columns)
Options:
  --chart-tf 1D       timeframe whose live bar feeds the Score / Zone / Kumo / Trend rows (default 1D)
  --preset Classic    Classic | 5-Day Week | Crypto   (same as the indicator input)
  --slope 5 --cut 4 --band 1   indicator inputs: Kijun slope lookback, Strong threshold, Chop score band
  --flat 8 --keep 6   Equilibrium Magnets: flat bars, keep last
  --now <unix>        clock used to decide whether the last bar of each TF is closed (default: now)
  --mode quick|full   recorded in the report; full needs enough chart-TF bars for Kumo Thin/Normal/Thick
Output: ichi.json (or --out). Bars oldest -> newest.
"""
import argparse, csv, json, sys, time
from datetime import datetime, timezone

PRESETS = {"Classic": (9, 26, 52, 26), "5-Day Week": (7, 22, 44, 22), "Crypto": (20, 60, 120, 30)}
TF_SEC = {"1": 60, "5": 300, "15": 900, "30": 1800, "1H": 3600, "60": 3600, "2H": 7200, "120": 7200,
          "4H": 14400, "240": 14400, "1D": 86400, "D": 86400, "1W": 604800, "W": 604800, "1M": 2592000, "M": 2592000}
TF_NORM = {"D": "1D", "W": "1W", "M": "1M", "240": "4H", "60": "1H", "120": "2H"}


def norm_tf(tf):
    tf = str(tf).upper()
    return TF_NORM.get(tf, tf)


def donchian(h, l, i, n):
    if i < n - 1:
        return None
    return (max(h[i - n + 1:i + 1]) + min(l[i - n + 1:i + 1])) / 2


def sgn(a, b):
    if a is None or b is None:
        return 0
    return 1 if a > b else -1 if a < b else 0


def percentrank(vals, i, n):
    """Pine ta.percentrank: % of the previous n values that are <= the current value."""
    if i < n or vals[i] is None or any(v is None for v in vals[i - n:i]):
        return None
    cur = vals[i]
    return 100.0 * sum(1 for v in vals[i - n:i] if v <= cur) / n


def series(h, l, c, preset, slope):
    tL, kL, bL, disp = preset
    n = len(c)
    off = disp - 1                                   # TradingView built-in offset
    ten = [donchian(h, l, i, tL) for i in range(n)]
    kij = [donchian(h, l, i, kL) for i in range(n)]
    ssa = [None if ten[i] is None or kij[i] is None else (ten[i] + kij[i]) / 2 for i in range(n)]
    ssb = [donchian(h, l, i, bL) for i in range(n)]
    S = []
    for i in range(n):
        kA = ssa[i - off] if i >= off else None
        kB = ssb[i - off] if i >= off else None
        warm = (kA is not None and kB is not None and i >= slope and kij[i - slope] is not None and i >= off)
        top = max(kA, kB) if warm else None
        bot = min(kA, kB) if warm else None
        c1 = (1 if c[i] > top else -1 if c[i] < bot else 0) if warm else 0
        c2 = sgn(ten[i], kij[i])
        c3 = (1 if c[i] > h[i - off] else -1 if c[i] < l[i - off] else 0) if i >= off else 0
        c4 = sgn(ssa[i], ssb[i])
        c5 = sgn(kij[i], kij[i - slope]) if i >= slope else 0
        score = c1 + c2 + c3 + c4 + c5 if warm else None
        san = 0 if score is None else (1 if c1 == c2 == c3 == 1 else -1 if c1 == c2 == c3 == -1 else 0)
        inK = warm and bot <= c[i] <= top
        S.append(dict(ten=ten[i], kij=kij[i], ssa=ssa[i], ssb=ssb[i], kA=kA, kB=kB, top=top, bot=bot,
                      c=[c1, c2, c3, c4, c5], score=score, san=san, inKumo=inK,
                      thick=abs(kA - kB) if warm else None))
    return S


def trend_text(s, chop, cut):
    if chop:
        return "CHOP ZONE · NO ACTION"
    if s >= cut: return "STRONG UP"
    if s >= 3: return "UP"
    if s > 0: return "SIDEWAYS UP"
    if s <= -cut: return "STRONG DOWN"
    if s <= -3: return "DOWN"
    if s < 0: return "SIDEWAYS DOWN"
    return "SIDEWAYS"


def pct_txt(v):
    return "—" if v is None else ("+" if v > 0 else "") + f"{v * 20:.0f}%"


def analyse(x, preset, slope, cut, band, flat, keep, now, tf, idle=False):
    h, l, c = x["h"], x["l"], x["c"]
    t = x.get("t")
    n = len(c)
    tL, kL, bL, disp = preset
    off = disp - 1
    if n < bL + off + slope:
        raise ValueError(f"need >= {bL + off + slope} bars, got {n}")
    S = series(h, l, c, preset, slope)
    i = n - 1
    # forming bar? (bar open + TF length still in the future)
    forming = False
    if t and len(t) == n and tf in TF_SEC:
        forming = t[i] + TF_SEC[tf] > now
        # market idle (no new bar on the smallest TF for a full period): session over, so the last
        # bar is closed for intraday/daily TFs, and for weekly once most of the week has passed
        if forming and idle and (TF_SEC[tf] <= 86400 or now - t[i] >= 4.5 * 86400):
            forming = False
    j = i - 1 if forming else i                      # latest closed bar
    s = S[i]
    noCut = [S[k]["score"] is None or S[k]["inKumo"] or abs(S[k]["score"]) <= band for k in range(n)]
    thick_vals = [S[k]["thick"] for k in range(n)]
    pr = percentrank(thick_vals, i, 252)
    kumo_cls = None if pr is None else "Thin" if pr < 20 else "Thick" if pr > 80 else "Normal"
    # events on confirmed bars only
    last_cl = j
    ev = {"strong_up": None, "strong_down": None, "aligned_up": None, "aligned_down": None}
    for k in range(last_cl, 0, -1):
        sc, sp = S[k]["score"], S[k - 1]["score"]
        if sc is not None and sp is not None and not noCut[k]:
            if ev["strong_up"] is None and sc >= cut and sp < cut:
                ev["strong_up"] = k
            if ev["strong_down"] is None and sc <= -cut and sp > -cut:
                ev["strong_down"] = k
        if ev["aligned_up"] is None and S[k]["san"] == 1 and S[k - 1]["san"] != 1:
            ev["aligned_up"] = k
        if ev["aligned_down"] is None and S[k]["san"] == -1 and S[k - 1]["san"] != -1:
            ev["aligned_down"] = k
        if all(v is not None for v in ev.values()):
            break
    def evd(k):
        if k is None:
            return None
        d = {"bars_ago": i - k, "close": c[k]}
        if t and len(t) == n:
            d["date"] = datetime.fromtimestamp(t[k], timezone.utc).strftime("%Y-%m-%d %H:%M")
        return d
    # Equilibrium Magnets (Kijun / Span B flat for `flat` confirmed bars), shared list, keep last `keep`
    mags = []
    kf = bf = 0
    for k in range(1, last_cl + 1):
        kf = kf + 1 if (S[k]["kij"] is not None and S[k]["kij"] == S[k - 1]["kij"]) else 1
        bf = bf + 1 if (S[k]["ssb"] is not None and S[k]["ssb"] == S[k - 1]["ssb"]) else 1
        if kf == flat and S[k]["kij"] is not None:
            mags.append({"type": "Kijun", "level": S[k]["kij"], "bars_ago": i - k})
        if bf == flat and S[k]["ssb"] is not None:
            mags.append({"type": "Span B", "level": S[k]["ssb"], "bars_ago": i - k})
        mags = mags[-keep:]
    close = c[i]
    pos = "above" if close > s["top"] else "below" if close < s["bot"] else "inside"
    r = i - off
    chik = "above" if close > h[r] else "below" if close < l[r] else "touching"
    tk = "TK>KJ" if s["ten"] > s["kij"] else "TK<KJ" if s["ten"] < s["kij"] else "TK=KJ"
    cross = None
    for k in range(i, max(kL, i - 300), -1):
        a_, b_ = sgn(S[k]["ten"], S[k]["kij"]), sgn(S[k - 1]["ten"], S[k - 1]["kij"])
        if a_ != 0 and a_ != b_:
            cross = [i - k, "bull" if a_ > 0 else "bear"]
            break
    kflat_now = 1
    for k in range(i - 1, 0, -1):
        if S[k]["kij"] == s["kij"]:
            kflat_now += 1
        else:
            break
    twists = sum(1 for k in range(max(1, i - 25), i + 1)
                 if sgn(S[k]["ssa"], S[k]["ssb"]) != 0 and sgn(S[k]["ssa"], S[k]["ssb"]) != sgn(S[k - 1]["ssa"], S[k - 1]["ssb"]))
    edge = s["bot"] if pos == "below" else s["top"] if pos == "above" else None
    sc_closed = S[j]["score"]
    return {
        "bars": n, "forming_last_bar": forming, "close": close,
        "tenkan": s["ten"], "kijun": s["kij"], "tenkan_prev": S[i - 1]["ten"], "kijun_prev": S[i - 1]["kij"],
        "kumo_top": s["top"], "kumo_bot": s["bot"], "kumo_color": "green" if s["kA"] > s["kB"] else "red",
        "kumo_thick_pct": abs(s["kA"] - s["kB"]) / close * 100,
        "fut_a": s["ssa"], "fut_b": s["ssb"], "fut_color": "green" if s["ssa"] > s["ssb"] else "red", "future_twists": twists,
        "pos": pos, "tk": tk, "last_cross": cross, "kijun_flat_bars": kflat_now,
        "chikou": chik, "chikou_ref_hi": h[r], "chikou_ref_lo": l[r], "chikou_ref_close": c[r],
        "sanyaku": "Koten" if s["san"] == 1 else "Gyakuten" if s["san"] == -1 else "none",
        "dist_kijun_pct": (close - s["kij"]) / s["kij"] * 100,
        "dist_kumo_pct": None if edge is None else (close - edge) / close * 100,
        "itto": {
            "score_live": s["score"], "score_live_pct": pct_txt(s["score"]),
            "components_live": dict(zip(["kumo", "tk", "chikou", "future_kumo", "kijun_slope"], s["c"])),
            "zone_live": "Chop" if noCut[i] else "Trending",
            "trend_live": None if s["score"] is None else trend_text(s["score"], noCut[i], cut),
            "kumo_rank": pr, "kumo_class": kumo_cls,
            "score_closed": sc_closed, "score_closed_pct": pct_txt(sc_closed),
            "aligned_closed": {1: "Up", -1: "Down"}.get(S[j]["san"], "None") if sc_closed is not None else "—",
            "events": {k: evd(v) for k, v in ev.items()},
            "magnets": mags,
        },
    }


def rnd(o):
    if isinstance(o, dict):
        return {k: rnd(v) for k, v in o.items()}
    if isinstance(o, list):
        return [rnd(v) for v in o]
    if isinstance(o, float):
        return round(o, 4)
    return o


def read_csv(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        sys.exit(f"empty csv: {path}")
    keys = {k.lower().strip(): k for k in rows[0].keys()}
    for need in ("high", "low", "close"):
        if need not in keys:
            sys.exit(f"{path}: missing column '{need}' (found {list(rows[0].keys())})")
    out = {k[0]: [float(r[keys[k]]) for r in rows] for k in ("high", "low", "close")}
    if "time" in keys:
        try:
            out["t"] = [int(float(r[keys["time"]])) for r in rows]
        except ValueError:
            pass
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data")
    ap.add_argument("--csv", action="append", default=[], help="TF=path.csv")
    ap.add_argument("--symbol", default="")
    ap.add_argument("--asof", default="")
    ap.add_argument("--chart-tf", default="1D")
    ap.add_argument("--preset", default="Classic", choices=list(PRESETS))
    ap.add_argument("--slope", type=int, default=5)
    ap.add_argument("--cut", type=int, default=4)
    ap.add_argument("--band", type=int, default=1)
    ap.add_argument("--flat", type=int, default=8)
    ap.add_argument("--keep", type=int, default=6)
    ap.add_argument("--now", type=float, default=None)
    ap.add_argument("--mode", default="quick", choices=["quick", "full"])
    ap.add_argument("--out", default="ichi.json")
    a = ap.parse_args()
    now = a.now or time.time()
    if a.data:
        d = json.load(open(a.data))
        symbol, asof, tfs = d.get("symbol", a.symbol), d.get("asof", a.asof), d["tfs"]
    elif a.csv:
        symbol, asof, tfs = a.symbol, a.asof, {}
        for item in a.csv:
            tf, path = item.split("=", 1)
            tfs[tf] = read_csv(path)
    else:
        sys.exit("give --data or --csv")
    preset = PRESETS[a.preset]
    out = {"symbol": symbol, "asof": asof, "params": list(preset), "preset": a.preset, "chart_tf": norm_tf(a.chart_tf), "mode": a.mode,
           "inputs": {"slope": a.slope, "cut": a.cut, "band": a.band, "flat": a.flat, "keep": a.keep}, "tfs": {}}
    idle = False
    timed = [(TF_SEC[norm_tf(tf)], x["t"]) for tf, x in tfs.items() if x.get("t") and norm_tf(tf) in TF_SEC]
    if timed:
        sec, tt = min(timed)
        idle = tt[-1] + 2 * sec <= now
    out["market_idle"] = idle
    for tf, x in tfs.items():
        tfn = norm_tf(tf)
        if not (len(x["h"]) == len(x["l"]) == len(x["c"])):
            sys.exit(f"{tf}: h/l/c lengths differ")
        try:
            out["tfs"][tfn] = analyse(x, preset, a.slope, a.cut, a.band, a.flat, a.keep, now, tfn, idle)
        except ValueError as e:
            print(f"skip {tf}: {e}", file=sys.stderr)
    ct = out["chart_tf"]
    if ct in out["tfs"] and out["tfs"][ct]["itto"]["kumo_class"] is None:
        print(f"note: {ct} has {out['tfs'][ct]['bars']} bars; Kumo Thin/Thick needs >= {252 + preset[2] + preset[3]} bars", file=sys.stderr)
    json.dump(rnd(out), open(a.out, "w"), indent=1, ensure_ascii=False)
    print(f"wrote {a.out}: {', '.join(out['tfs'])} (chart TF {ct}, preset {a.preset})")


if __name__ == "__main__":
    main()
