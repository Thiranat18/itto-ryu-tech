#!/usr/bin/env python3
"""Turn the Ichimoku Itto dashboard into dashboard.json. Python standard library only.

Input: a JSON file holding what the TradingView tools returned, e.g.
  {"rows": ["ICHIMOKU ITTO · One Glance, One Cut", "Score | -100%", ..., "TF | Score | Aligned", "1H | -100% | Down", ...],
   "plots": {"Kijun (Blade)": "4,187.660", "Senkou A": "4,137.899", ...},      # optional (data window values)
   "chart_tf": "1D", "symbol": "OANDA:XAUUSD", "asof": "2026-10-23 close",
   "source": "how the values were read", "input_level": 2}     # input_level 0 = values read from an image
Rows are copied exactly as the tool printed them. Every row is kept, so new fields in a later
indicator version still show up in the report.
Output: dashboard.json (or --out).
"""
import argparse, json, re


def num(v):
    if isinstance(v, (int, float)):
        return v
    s = str(v).replace(",", "").replace("−", "-").strip()
    try:
        return float(s)
    except ValueError:
        return v


def parse(rows):
    title, kv, header, table, extra = None, [], None, [], []
    for raw in rows:
        parts = [p.strip() for p in str(raw).split("|")]
        parts = [p for p in parts if p != ""] or [""]
        if len(parts) == 1:
            if title is None:
                title = parts[0]
            else:
                extra.append(parts[0])
        elif len(parts) == 2:
            kv.append(parts)
        else:
            if header is None:
                header = parts
            else:
                table.append(parts)
    return title, kv, header, table, extra


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw")
    ap.add_argument("--out", default="dashboard.json")
    a = ap.parse_args()
    r = json.load(open(a.raw))
    title, kv, header, table, extra = parse(r.get("rows", []))
    out = {
        "symbol": r.get("symbol", ""),
        "asof": r.get("asof", ""),
        "source": r.get("source", ""),
        "input_level": r.get("input_level", 2),
        "chart_tf": r.get("chart_tf", ""),
        "title": title or "",
        "fields": kv,                      # [[label, value], ...] in dashboard order
        "tf_header": header or [],
        "tf_rows": table,
        "notes": extra,
        "plots": {k: num(v) for k, v in (r.get("plots") or {}).items()},
    }
    json.dump(out, open(a.out, "w"), indent=1, ensure_ascii=False)
    print(f"wrote {a.out}: {len(kv)} fields, {len(table)} TF rows, {len(out['plots'])} plots")


if __name__ == "__main__":
    main()
