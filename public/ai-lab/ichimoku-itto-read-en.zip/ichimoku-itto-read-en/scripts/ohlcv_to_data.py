#!/usr/bin/env python3
"""Build data.json from TradingView OHLCV tool results. Python standard library only.

Each input is a file holding one get_ohlcv result exactly as the tool returned it, e.g.
  {"bars": {"t": [...], "o": [...], "h": [...], "l": [...], "c": [...], "v": [...]}, "symbol": "...", ...}
or rows: {"bars": [{"t":..,"h":..,"l":..,"c":..}, ...]}. A bare {"t","h","l","c"} object also works.

Usage:
  python3 ohlcv_to_data.py --symbol OANDA:XAUUSD 1D=d.json 4H=h4.json 1H=h1.json 1W=w.json --out data.json
"""
import argparse, json, sys
from datetime import datetime, timezone


def load(path):
    r = json.load(open(path))
    b = r.get("bars", r) if isinstance(r, dict) else r
    if isinstance(b, list):
        cols = {k: [row[k] for row in b] for k in ("t", "h", "l", "c") if k in b[0]}
    else:
        cols = {k: b[k] for k in ("t", "h", "l", "c") if k in b}
    for k in ("h", "l", "c"):
        if k not in cols:
            sys.exit(f"{path}: missing '{k}'")
    n = len(cols["c"])
    if any(len(v) != n for v in cols.values()):
        sys.exit(f"{path}: columns have different lengths")
    if "t" in cols and any(cols["t"][i] >= cols["t"][i + 1] for i in range(n - 1)):
        order = sorted(range(n), key=lambda i: cols["t"][i])          # make oldest -> newest
        cols = {k: [v[i] for i in order] for k, v in cols.items()}
    sym = r.get("symbol", "") if isinstance(r, dict) else ""
    return cols, sym


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+", help="TF=path.json")
    ap.add_argument("--symbol", default="")
    ap.add_argument("--asof", default="")
    ap.add_argument("--out", default="data.json")
    a = ap.parse_args()
    tfs, sym, last_t = {}, a.symbol, None
    for item in a.inputs:
        tf, path = item.split("=", 1)
        cols, s = load(path)
        tfs[tf] = cols
        sym = sym or s
        if "t" in cols:
            last_t = max(last_t or 0, cols["t"][-1])
        print(f"{tf}: {len(cols['c'])} bars, last close {cols['c'][-1]}")
    asof = a.asof or (datetime.fromtimestamp(last_t, timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if last_t else "")
    json.dump({"symbol": sym, "asof": asof, "tfs": tfs}, open(a.out, "w"))
    print(f"wrote {a.out} ({sym}, asof {asof})")


if __name__ == "__main__":
    main()
