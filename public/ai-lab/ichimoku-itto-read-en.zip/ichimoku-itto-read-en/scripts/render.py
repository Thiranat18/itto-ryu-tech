#!/usr/bin/env python3
"""Render the Ichimoku Itto Read report (HTML + plain text). Python standard library only.

  python3 render.py --ichi ichi.json --dashboard dashboard.json --lang en --jp \
                    --out-html report.html --out-txt report.txt --generated 2026-10-25

Either input may be missing:
  dashboard only  -> input level 0 (from an image) or a dashboard-only read
  ichi only       -> input level 1 (OHLCV / CSV, no dashboard)
  both            -> input level 2
The report describes state by principle only. It never contains trade instructions.
"""
import argparse, html, json, math, re

TF_ORDER = {"1M": 0, "M": 0, "1W": 1, "W": 1, "1D": 2, "D": 2, "240": 3, "4H": 3, "120": 4, "2H": 4,
            "60": 5, "1H": 5, "30": 6, "15": 7, "5": 8, "1": 9}
TF_NORM = {"D": "1D", "W": "1W", "M": "1M", "240": "4H", "60": "1H", "120": "2H"}

JP = {"summary": "総括", "dashboard": "一目瞭然", "strip": "状態", "ladder": "水準", "reading": "読み",
      "levels": "変化点", "weak": "陰", "strong": "陽", "learn": "学び", "kumo": "雲", "tk": "転換線・基準線",
      "chikou": "遅行スパン", "future": "先行雲", "sanyaku": "三役", "Gyakuten": "逆転", "Koten": "好転",
      "twist": "雲のねじれ", "flat": "横ばいの基準線", "equilibrium": "均衡", "full": "一目均衡表"}

T = {
 "en": {
  "font": "Inter", "brand": "ICHIMOKU ITTO READ",
  "meta": "Data through {asof} · Generated {gen} · Input level {lvl}: {lvl_txt} · Ichimoku {p}",
  "lvl": {0: "dashboard read from an image", 1: "price data (OHLCV) — Ichimoku Itto dashboard computed by the skill", 2: "Ichimoku Itto dashboard read from the chart + price data", "D": "Ichimoku Itto dashboard only (no price data)"},
  "summary": "Summary", "dashboard": "Ichimoku Itto Dashboard", "dash_note": "(read directly from the indicator)",
  "dash_img": "Values were read from an image. Please confirm the numbers against your chart.",
  "dash_none": "The Ichimoku Itto dashboard was not read for this report. Add Ichimoku Itto to the chart, or share a screenshot of its dashboard, to include it.",
  "plots": "Chart plot values ({tf})", "parity_ok": "✔ Parity check: {items} computed from price data match the chart (largest difference {d}).",
  "parity_bad": "⚠ Parity check: {items} differ from the chart by up to {d}. Check the symbol, timeframe and indicator settings.",
  "source": "Source", "strip": "State strip", "strip_note": "(classic components)",
  "h_kumo": "Price vs Kumo", "h_tk": "Tenkan / Kijun", "h_chik": "Chikou", "h_fut": "Future Kumo", "h_san": "Sanyaku",
  "below": "Below Kumo", "above": "Above Kumo", "inside": "Inside Kumo", "TK<KJ": "Tenkan < Kijun", "TK>KJ": "Tenkan > Kijun", "TK=KJ": "Tenkan = Kijun",
  "c_below": "Below past price", "c_above": "Above past price", "c_touching": "Touching past price",
  "red": "Red", "green": "Green", "Gyakuten": "Gyakuten", "Koten": "Kōten", "none": "Incomplete",
  "strip_foot": "Colours describe state by principle only. They do not forecast direction.",
  "ladder": "Level ladder", "lg_kij": "Kijun", "lg_ten": "Tenkan", "lg_kumo": "Current Kumo (coloured by state)", "lg_close": "Close",
  "reading": "Component reading", "classic": "Classic",
  "p_kumo": "The Kumo is the medium-term equilibrium zone. Price below it puts the structure on the weak side and the Kumo above acts as resistance; price above it puts the structure on the strong side and the Kumo below acts as support.",
  "p_tk": "Tenkan-sen ({t} bars) measures short-term momentum; Kijun-sen ({k} bars) measures medium-term equilibrium. Their order shows whether short-term momentum is ahead of or behind equilibrium.",
  "p_chik": "Chikou Span is today's close plotted {d} bars back. It confirms whether price is beating or losing to where it was {d} bars ago.",
  "p_kij": "Kijun-sen acts as an equilibrium line. When price stretches far from it, a pull back toward it is common, but the principle gives no timing or direction.",
  "o_kumo": "Price vs current Kumo: {g}. Future Kumo: {f}.{thin}",
  "o_thin": " Thinnest current Kumo: {tf} ({v}% of price).",
  "o_tk": "{g}. On {tf} the Kijun moved {a} → {b}.",
  "o_chik": "Chikou vs the price range {d} bars ago: {g}.",
  "o_kij": "Distance from Kijun: {g}.",
  "levels": "State-change levels", "levels_note": "(a close beyond these levels would change each component's state; they describe state, not trade levels)",
  "h_mom": "Short-term momentum", "h_eq": "Medium equilibrium", "h_kumo2": "Kumo",
  "cl_above": "close above {v}", "cl_below": "close below {v}", "exit": "exit above {a} / below {b}",
  "sides_dom": ["What supports the current state", "What to watch for a change of state"],
  "sides_mix": ["Components leaning weak", "Components leaning strong"],
  "s_chik": "Chikou {s} on {tfs}", "s_san": "Sanyaku {s} on {tfs}", "s_fut": "Future Kumo {c} on {tfs}", "s_tk": "{s} on {tfs}", "s_pos": "{s} on {tfs}",
  "s_dash": "Dashboard {k}: {v}",
  "w_near": "{tf} is closest to its Kijun ({v}%), so it is the first timeframe whose state can change",
  "w_far": "Price is {v}% from the {tf} Kijun, a wide gap from equilibrium",
  "w_thin": "Thin current Kumo on {tf}",
  "w_color": "Current Kumo {a} but future Kumo {b} on {tf}",
  "w_flat": "{tf} Kijun has been flat for {n} bars at {v}",
  "nothing": "Nothing stands out on this side.",
  "learn": "Learning note",
  "n_twist": ("Kumo twist", "The future Kumo changes colour when Senkou A crosses Senkou B. It says the future equilibrium has shifted sides, but it is not price confirmation. Read it together with price versus the current Kumo and the Chikou."),
  "n_sanyaku": ("Sanyaku", "Sanyaku means three conditions agree: price vs Kumo, Tenkan vs Kijun, and Chikou vs past price. Kōten is all three on the strong side, Gyakuten all three on the weak side. It describes agreement, not how long it will last."),
  "n_flat": ("Flat Kijun", "A flat Kijun means the 26-bar midpoint has not changed. Flat stretches often act as a level that price returns to, because the equilibrium itself is not moving."),
  "n_eq": ("Equilibrium", "Ichimoku is a chart of balance. Kijun and the Kumo mark where balance sits; distance from them shows how stretched price is, not what happens next."),
  "disc": "This report describes the state of Ichimoku by principle only. It is not investment advice or a recommendation to buy or sell. You make your own decisions and bear your own risk. Print to PDF from your browser's Print menu.",
  "disc_txt": "DISCLAIMER: This report describes the state of Ichimoku by principle only. It is not investment advice or a recommendation to buy or sell. You make your own decisions and bear your own risk.",
  "sum_dash": "The Ichimoku Itto dashboard shows {f}.",
  "sum_all": "All {n} timeframes are in Sanyaku {s}: {desc}.",
  "sum_mix": "Sanyaku is mixed across timeframes: {g}.",
  "desc_G": "price below the Kumo, Tenkan below Kijun, and Chikou below past price",
  "desc_K": "price above the Kumo, Tenkan above Kijun, and Chikou above past price",
  "sum_dist": "The close of {p} is {d}% from the {tf} Kijun.",
  "tf_dash_note": "Timeframe rows as shown on the dashboard",
  "dash_comp_note": "(computed by the skill from price data with the Ichimoku Itto rules)",
  "dpar_ok": "✔ Dashboard parity: all {n} values computed from price data match the chart dashboard.",
  "dpar_bad": "⚠ Dashboard parity: {items} differ from the chart dashboard (chart / computed).",
  "breakdown": "Score breakdown ({tf}, live bar)", "b_kumo": "Price vs Kumo", "b_tk": "Tenkan vs Kijun", "b_chik": "Chikou",
  "b_fut": "Future Kumo", "b_slope": "Kijun slope ({n} bars)",
  "events": "Last marks on {tf} (closed bars)", "ev_strong_up": "Strong Up", "ev_strong_down": "Strong Down",
  "ev_aligned_up": "3/3 Aligned Up", "ev_aligned_down": "3/3 Aligned Down", "ago": "{n} bars ago", "none_ev": "none in range",
  "magnets": "Equilibrium Magnets ({tf}, last {k})", "mag_none": "No magnet in range.",
  "p_itto": "Itto Score adds five checks, each +1 / −1 / 0: price vs current Kumo, Tenkan vs Kijun, Chikou vs the price it is plotted against, future Kumo colour, and Kijun slope over {slope} bars. −5…+5 is shown as −100%…+100%. Zone is Chop when price is inside the Kumo or |score| ≤ {band} (≤ {bandp}%); no Strong marks print there. Strong marks print when the score crosses ±{cut} ({cutp}%) outside Chop. Kumo Thin/Thick = cloud thickness in the bottom/top 20% of the last 252 bars.",
  "o_itto": "{tf} live score {sc} ({parts}); zone {zone}; trend {trend}.",
  "itto": "Itto",
  "setup_t": "Settings used", "setup": "Preset {preset} ({p}) · Mode {mode} · Chart TF {ct} · Data through {asof}",
  "tip_ok": "✔ {preset} is the preset the Timeframe & Preset Guide uses for {mkt} on {ct}.",
  "tip_cut": "Guide tip: for {mkt} on {ct} the Timeframe & Preset Guide uses {rec}. If your Ichimoku Itto uses {rec} too, run <code>ichimoku-itto-read-en {sym} {ct}{arg}</code>. The skill keeps the preset you asked for, so the numbers match your chart.",
  "mkt5": "a 5-day market", "mkt7": "a 7-day market", "mkt_any": "any market",
  "setup_q": "Does this match your Ichimoku Itto? If your chart uses another preset, add it to the command: <code>ichimoku-itto-read-en {sym} 5-day</code> or <code>ichimoku-itto-read-en {sym} crypto</code>. To keep a setting every time, put it in your Claude project instructions or config.yaml.",
  "mode_full": "<b>FULL MODE</b>: every dashboard field, including Kumo Thin/Normal/Thick and marks from the last ~340 bars. For the lighter default, add <code>quick</code> or leave the mode out.",
  "mode_quick": "<b>QUICK MODE</b> (default): lighter and faster. Kumo Thin/Normal/Thick is left out and marks only look back 90 bars. <b>Want everything?</b> Run <code>ichimoku-itto-read-en {sym} full</code>.",
  "kumo_quick": "— (full mode)",
  "sum_ct": "On {ct}: Score {sc}, Zone {zone}, Trend {trend}.",
  "sum_all2": "All {n} timeframes agree: Sanyaku {s} ({desc}).",
  "sum_mix2": "Timeframes disagree: {g}.",
  "mx_G": "{tfs} weak on all three checks (Gyakuten)", "mx_K": "{tfs} strong on all three checks (Kōten)",
  "mx_in": "{tfs} with price inside the Kumo", "mx_ab": "{tfs} above the Kumo but not all three checks agree",
  "mx_be": "{tfs} below the Kumo but not all three checks agree",
 },
}

CSS = """
:root{--bg:#f6f5f2;--card:#fff;--ink:#1d1d1f;--mute:#6b6b70;--line:#e4e2dc;--neg:#b4362f;--negbg:#fbe9e7;--pos:#1f8a55;--posbg:#e6f4ec;--mid:#8a6d1f;--midbg:#fbf3dc;--accent:#b4362f;--kij:#3a6fd8;--ten:#d0761b}
@media (prefers-color-scheme:dark){:root{--bg:#151517;--card:#1f1f22;--ink:#ececee;--mute:#a1a1a8;--line:#323236;--negbg:#3a1f1d;--posbg:#173025;--midbg:#352d17;--neg:#ff8a7e;--pos:#5fd39a;--mid:#e6c35c;--accent:#ff8a7e}}
*{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font-family:var(--font),system-ui,sans-serif;font-size:15px;line-height:1.55}
.wrap{max-width:880px;margin:0 auto;padding:24px 16px 40px}
.brand{color:var(--accent);font-weight:700;letter-spacing:.12em;font-size:12px} h1{margin:2px 0 0;font-size:28px} .meta{color:var(--mute);font-size:13px}
.seal{float:right;font-family:'Noto Serif JP',serif;font-size:30px;color:var(--accent);border:2px solid var(--accent);border-radius:6px;padding:6px 8px;width:52px;text-align:center;line-height:1.05;margin-left:12px}
.jp{font-family:'Noto Serif JP',serif;color:var(--accent);font-weight:500;font-size:.85em;margin-left:4px} .jpk{font-family:'Noto Serif JP',serif}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-top:14px}
.card h2{font-size:16px;margin:0 0 10px} .verdict{border-left:5px solid var(--accent)} .note{font-size:12px;color:var(--mute);font-weight:400}
.setup{background:var(--midbg);border:2px solid var(--mid);color:var(--ink);border-radius:12px;padding:12px 16px;margin-top:14px;font-size:14px} .setup .sm{margin-top:6px} .setup .mode{font-size:15px} .badge{display:inline-block;vertical-align:middle;margin-left:10px;font-size:12px;font-weight:700;letter-spacing:.08em;padding:3px 10px;border-radius:999px;background:var(--midbg);color:var(--mid);border:1.5px solid var(--mid)} .setup code{background:var(--card);padding:1px 6px;border-radius:4px;font-size:13px} .warn{background:var(--midbg);color:var(--mid);border-radius:8px;padding:8px 10px;font-size:13px;margin-bottom:10px}
table{width:100%;border-collapse:separate;border-spacing:4px} th{text-align:left;font-size:13px;color:var(--mute);font-weight:600}
.strip td,.cells td{text-align:center;border-radius:8px;padding:8px 4px;font-size:13px;font-weight:600}
.s-neg{background:var(--negbg);color:var(--neg)} .s-pos{background:var(--posbg);color:var(--pos)} .s-mid{background:var(--midbg);color:var(--mid)} .s-plain{background:var(--bg)}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-bottom:10px} .kpis div{border-radius:8px;padding:8px 10px}
.kpis span{display:block;font-size:12px;color:var(--mute);font-weight:400} .kpis b{font-size:17px}
.lwrap{overflow-x:auto} .ladder{width:100%;min-width:620px;height:auto} .grid{stroke:var(--line);stroke-width:1} .ax{fill:var(--mute);font-size:11px;text-anchor:end}
.kumo{opacity:.35} .kumo.green{fill:var(--pos)} .kumo.red{fill:var(--neg)} .lbl{fill:var(--mute);font-size:11px}
.kij{stroke:var(--kij);stroke-width:2.5} .ten{stroke:var(--ten);stroke-width:2;stroke-dasharray:5 3} .kijt{fill:var(--kij)} .tent{fill:var(--ten)}
.px{fill:var(--ink)} .pxt{fill:var(--ink);font-size:11px;font-weight:700} .tfl{fill:var(--ink);font-weight:700;font-size:13px;text-anchor:middle}
.legend span{display:inline-block;margin-right:14px;font-size:12px;color:var(--mute)} .sw{display:inline-block;width:14px;height:4px;vertical-align:middle;margin-right:5px}
.comp p{margin:4px 0} .pr{color:var(--mute);font-size:13px} .tag{font-size:11px;background:var(--line);border-radius:4px;padding:1px 6px;margin-right:6px;color:var(--mute)}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px} .two ul{margin:4px 0;padding-left:18px} .sa{background:var(--negbg)} .sb{background:var(--posbg)}
.disc{font-size:12px;color:var(--mute);margin-top:18px;border-top:1px solid var(--line);padding-top:10px}
@media (max-width:620px){.two{grid-template-columns:1fr} .strip td{font-size:11px;padding:7px 2px}}
@media print{@page{size:A4;margin:12mm} body{background:#fff} .card{break-inside:avoid}}
"""


def e(s):
    return html.escape(str(s), quote=False)


def fp(x):
    x = float(x)
    if x == 0:
        return "0"
    a = abs(x)
    d = 2 if a >= 1 else 4 if a >= 0.01 else 6
    return f"{x:,.{d}f}"


def pct(x, d=1):
    return f"{x:+.{d}f}"


def norm_tf(tf):
    return TF_NORM.get(str(tf).upper().replace("MIN", ""), str(tf).upper())


CRYPTO_EX = ("BITSTAMP", "BINANCE", "COINBASE", "KRAKEN", "BYBIT", "OKX", "BITFINEX", "CRYPTO", "GEMINI", "KUCOIN", "MEXC", "BITGET")
PRESET_ARG = {"Classic": " classic", "5-Day Week": " 5-day", "Crypto": " crypto"}


def guide_preset(symbol, ct):
    """Preset the Timeframe & Preset Guide uses for this market and chart TF: (market key, preset)."""
    ex, _, name = symbol.upper().rpartition(":")
    seven = ex in CRYPTO_EX or name.endswith(("USDT", "USDC")) or name.startswith(("BTC", "ETH", "SOL", "XRP"))
    if TF_ORDER.get(ct, 9) > 2:                    # intraday decision TF: Classic everywhere
        return "mkt_any", "Classic"
    return ("mkt7", "Crypto") if seven else ("mkt5", "Classic")


def tf_key(tf):
    return TF_ORDER.get(norm_tf(tf), 50)


def tone(v):
    s = str(v)
    if re.search(r"down|bear|weak|−|^-", s, re.I):
        return "s-neg"
    if re.search(r"\bup\b|bull|strong up|^\+", s, re.I):
        return "s-pos"
    return "s-plain"


def group(R, tfs, fn):
    """'label: TF, TF; label: TF' grouped in TF order."""
    g = {}
    for tf in tfs:
        g.setdefault(fn(R[tf]), []).append(tf)
    return g


def gtxt(g, L):
    return "; ".join(f"{L.get(k, k)}: {', '.join(v)}" for k, v in g.items())


DASH_TF_ORDER = ["1H", "4H", "1D", "1W"]
DASH_TF_LABEL = {"1D": "D", "1W": "W"}


def computed_dashboard(I, R):
    """Rebuild the Ichimoku Itto table from ichi.json (same layout as the indicator)."""
    ct = (I or {}).get("chart_tf")
    if not ct or ct not in R or "itto" not in R[ct]:
        return None
    it = R[ct]["itto"]
    fields = [["Score", it["score_live_pct"]], ["Zone", it["zone_live"]], ["Kumo", it["kumo_class"] or "—"]]  # "—" replaced by caller
    rows = []
    order = [t for t in DASH_TF_ORDER if t in R] + [t for t in R if t not in DASH_TF_ORDER]
    for t in order:
        rows.append([DASH_TF_LABEL.get(t, t), R[t]["itto"]["score_closed_pct"], R[t]["itto"]["aligned_closed"]])
    fields_after = [["Trend", it["trend_live"] or "—"]]
    return {"title": "ICHIMOKU ITTO · One Glance, One Cut", "fields": fields + fields_after,
            "tf_header": ["TF", "Score", "Aligned"], "tf_rows": rows, "chart_tf": ct}


def dash_parity(D, CD):
    """Compare a dashboard read from the chart with the computed one. Returns (n_compared, mismatches)."""
    if not D or not CD:
        return 0, []
    norm = lambda v: str(v).replace("\u2212", "-").replace(" ", "").upper()
    n, bad = 0, []
    cf = dict(CD["fields"])
    for k, v in D.get("fields", []):
        if k in cf:
            n += 1
            if norm(v) != norm(cf[k]):
                bad.append(f"{k} {v} / {cf[k]}")
    crow = {r[0]: r for r in CD["tf_rows"]}
    for r in D.get("tf_rows", []):
        c = crow.get(r[0]) or crow.get(DASH_TF_LABEL.get(r[0], r[0]))
        if c is None:
            continue
        for idx in range(1, min(len(r), len(c))):
            n += 1
            if norm(r[idx]) != norm(c[idx]):
                bad.append(f"{r[0]} {D['tf_header'][idx] if idx < len(D.get('tf_header', [])) else idx} {r[idx]} / {c[idx]}")
    return n, bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ichi")
    ap.add_argument("--dashboard")
    ap.add_argument("--lang", default="en", choices=["en"])  # English-only edition
    ap.add_argument("--jp", dest="jp", action="store_true", default=True)
    ap.add_argument("--no-jp", dest="jp", action="store_false")
    ap.add_argument("--generated", default="")
    ap.add_argument("--symbol", default="")
    ap.add_argument("--out-html", default="report.html")
    ap.add_argument("--out-txt", default="report.txt")
    a = ap.parse_args()
    L = T[a.lang]
    J = (lambda k: f" <span class='jp'>{JP[k]}</span>") if a.jp else (lambda k: "")
    I = json.load(open(a.ichi)) if a.ichi else None
    D = json.load(open(a.dashboard)) if a.dashboard else None
    if not I and not D:
        raise SystemExit("need --ichi and/or --dashboard")
    R = {norm_tf(k): v for k, v in (I or {}).get("tfs", {}).items()}
    tfs = sorted(R, key=tf_key)
    symbol = a.symbol or (I or {}).get("symbol") or (D or {}).get("symbol", "")
    asof = (I or {}).get("asof") or (D or {}).get("asof", "")
    lvl = 2 if (I and D) else 1 if I else (0 if D.get("input_level") == 0 else "D")
    params = ((I or {}).get("preset", "Classic") + " " + "/".join(str(p) for p in (I or {}).get("params", [9, 26, 52, 26])))
    txt = []
    body = []
    CD = computed_dashboard(I, R)
    if CD:
        CD["fields"] = [[k, (L["kumo_quick"] if (k == "Kumo" and v == "—") else v)] for k, v in CD["fields"]]
    DV = D or CD                                   # dashboard values shown in summary / sides
    inp = (I or {}).get("inputs", {"slope": 5, "cut": 4, "band": 1, "flat": 8, "keep": 6})

    # ---------- summary ----------
    sents = []
    ctf = (I or {}).get("chart_tf")
    if ctf in R and "itto" in R[ctf]:
        it = R[ctf]["itto"]
        sents.append(L["sum_ct"].format(ct=ctf, sc=it["score_live_pct"], zone=it["zone_live"], trend=it["trend_live"]))
    elif DV and DV.get("fields"):
        sents.append(L["sum_dash"].format(f=", ".join(f"{k} {v}" for k, v in DV["fields"])))
    if R:
        sans = {R[t]["sanyaku"] for t in tfs}
        if len(sans) == 1 and "none" not in sans:
            s_ = sans.pop()
            sents.append(L["sum_all2"].format(n=len(tfs), s=L[s_], desc=L["desc_G" if s_ == "Gyakuten" else "desc_K"]))
        else:
            def cls_(r):
                if r["sanyaku"] == "Gyakuten": return "mx_G"
                if r["sanyaku"] == "Koten": return "mx_K"
                return {"inside": "mx_in", "above": "mx_ab", "below": "mx_be"}[r["pos"]]
            g = group(R, tfs, cls_)
            sents.append(L["sum_mix2"].format(g="; ".join(L[k].format(tfs=", ".join(v)) for k, v in g.items())))
        big = tfs[0]
        sents.append(L["sum_dist"].format(p=fp(R[big]["close"]), d=pct(R[big]["dist_kijun_pct"]), tf=big))
    summary = "\n".join(sents)
    if I:
        mode = (I or {}).get("mode", "quick")
        setup = L["setup"].format(preset=I.get("preset", "Classic"), p="/".join(str(x) for x in I.get("params", [])), mode=mode.upper(), ct=ctf, asof=asof or "—")
        sym_ = e(symbol.split(':')[-1] or 'SYMBOL')
        mline = L["mode_quick" if mode == "quick" else "mode_full"].format(sym=sym_)
        mkt, rec = guide_preset(symbol, ctf or "1D")
        used = I.get("preset", "Classic")
        tip = (L["tip_ok"] if used == rec else L["tip_cut"]).format(preset=used, rec=rec, mkt=L[mkt], ct=e(ctf or "1D"), sym=sym_, arg=PRESET_ARG[rec])
        body.append(f"<div class='setup'><div class='mode'>{mline}</div><div class='sm'><b>⚙ {L['setup_t']}:</b> {e(setup)}</div><div class='sm'>{tip}</div><div class='sm'>{L['setup_q'].format(sym=sym_)}</div></div>")
        txt += [re.sub(r"<[^>]+>", "", mline), f"{L['setup_t'].upper()}: {setup}", re.sub(r"<[^>]+>", "", tip), re.sub(r"<[^>]+>", "", L['setup_q'].format(sym=sym_)), ""]
    body.append(f"<div class='card verdict'><h2>{L['summary']}{J('summary')}</h2>{e(summary).replace(chr(10), '<br>')}</div>")
    txt += [f"{L['summary'].upper()}", summary, ""]

    # ---------- dashboard ----------
    if DV:
        img = bool(D) and D.get("input_level") == 0
        kp = "".join(f"<div class='{tone(v)}'><span>{e(k)}</span><b>{e(v)}</b></div>" for k, v in DV.get("fields", []))
        rows = ""
        if DV.get("tf_header"):
            rows = "<tr>" + "".join(f"<th>{e(h)}</th>" for h in DV["tf_header"]) + "</tr>"
            rows += "".join("<tr><th>" + e(r[0]) + "</th>" + "".join(f"<td class='{tone(c)}'>{e(c)}</td>" for c in r[1:]) + "</tr>"
                            for r in DV.get("tf_rows", []))
        notes = "".join(f"<p class='pr'>{e(n)}</p>" for n in (D or {}).get("notes", []))
        plots = (D or {}).get("plots") or {}
        pl, par, txt_par = "", "", ""
        if plots:
            pl = f"<p class='pr'><b>{L['plots'].format(tf=e(D.get('chart_tf', '')))}:</b> " + " · ".join(
                f"{e(k)} {fp(v) if isinstance(v, (int, float)) else e(v)}" for k, v in plots.items()) + "</p>"
        ctf = norm_tf((D or {}).get("chart_tf", ""))
        if plots and ctf in R:
            r = R[ctf]
            pairs = []
            for k, v in plots.items():
                kl = k.lower()
                if not isinstance(v, (int, float)):
                    continue
                if "kijun" in kl:
                    pairs.append(("Kijun", r["kijun"], v))
                elif "tenkan" in kl:
                    pairs.append(("Tenkan", r["tenkan"], v))
                elif "senkou a" in kl or "span a" in kl:
                    pairs.append(("Senkou A", r["fut_a"], v))
                elif "senkou b" in kl or "span b" in kl:
                    pairs.append(("Senkou B", r["fut_b"], v))
                elif "itto score" in kl and r.get("itto"):
                    pairs.append(("Itto Score", r["itto"]["score_live"] or 0, v))
            if pairs:
                d = max(abs(x - y) for _, x, y in pairs)
                tol = max(0.01, abs(r["close"]) * 1e-5)
                txt_par = L['parity_ok' if d <= tol else 'parity_bad'].format(items=', '.join(p[0] for p in pairs), d=f'{d:.4g}')
                par = f"<div class='note'>{txt_par}</div>"
        dn, dbad = dash_parity(D, CD)
        txt_dpar = ""
        if dn:
            txt_dpar = L["dpar_bad"].format(items="; ".join(dbad)) if dbad else L["dpar_ok"].format(n=dn)
            par += f"<div class='note'>{e(txt_dpar)}</div>"
        src = f"<div class='note'>{L['source']}: {e(D.get('source', ''))}</div>" if D and D.get("source") else ""
        warn = f"<div class='warn'>{L['dash_img']}</div>" if img else ""
        note = L["dash_note"] if D else L["dash_comp_note"]
        extra = ""
        xt = []
        ct = (I or {}).get("chart_tf")
        if ct in R and "itto" in R[ct]:
            it = R[ct]["itto"]
            cl = it["components_live"]
            names = [("b_kumo", "kumo"), ("b_tk", "tk"), ("b_chik", "chikou"), ("b_fut", "future_kumo"), ("b_slope", "kijun_slope")]
            cells = "".join(f"<td class='{'s-pos' if cl[k] > 0 else 's-neg' if cl[k] < 0 else 's-mid'}'>{L[n].format(n=inp['slope'])}<br>{cl[k]:+d}</td>" for n, k in names)
            extra += f"<p class='pr' style='margin-top:12px'><b>{L['breakdown'].format(tf=ct)}</b></p><table class='cells'><tr>{cells}</tr></table>"
            xt.append("  " + L["breakdown"].format(tf=ct) + ": " + ", ".join(f"{L[n].format(n=inp['slope'])} {cl[k]:+d}" for n, k in names))
            evs = it["events"]
            ev_items = []
            for k in ("strong_up", "strong_down", "aligned_up", "aligned_down"):
                v = evs.get(k)
                ev_items.append(f"{L['ev_' + k]}: " + (L["none_ev"] if not v else L["ago"].format(n=v["bars_ago"]) + f" ({v.get('date', '')[:10] + ' · ' if v.get('date') else ''}{fp(v['close'])})"))
            extra += f"<p class='pr'><b>{L['events'].format(tf=ct)}:</b> " + " · ".join(e(x) for x in ev_items) + "</p>"
            xt.append("  " + L["events"].format(tf=ct) + ": " + " · ".join(ev_items))
            mg = it["magnets"]
            mtxt = " · ".join(f"{m['type']} {fp(m['level'])} ({L['ago'].format(n=m['bars_ago'])})" for m in reversed(mg)) or L["mag_none"]
            extra += f"<p class='pr'><b>{L['magnets'].format(tf=ct, k=inp['keep'])}:</b> {e(mtxt)}</p>"
            xt.append("  " + L["magnets"].format(tf=ct, k=inp["keep"]) + ": " + mtxt)
        body.append(f"<div class='card'><h2>{L['dashboard']}{J('dashboard')} <span class='note'>{e(DV.get('title', ''))} {note}</span></h2>"
                    f"{warn}<div class='kpis'>{kp}</div><table class='cells'>{rows}</table>{notes}{extra}{pl}{par}{src}</div>")
        txt += [L["dashboard"].upper() + " " + note] + ([L["dash_img"]] if img else [])
        txt += [f"  {k}: {v}" for k, v in DV.get("fields", [])]
        if DV.get("tf_header"):
            txt.append("  " + " | ".join(DV["tf_header"]))
            txt += ["  " + " | ".join(r) for r in DV.get("tf_rows", [])]
        txt += [f"  {n}" for n in (D or {}).get("notes", [])]
        txt += xt
        if plots:
            txt.append("  " + L["plots"].format(tf=D.get("chart_tf", "")) + ": " + " · ".join(
                f"{k} {fp(v) if isinstance(v, (int, float)) else v}" for k, v in plots.items()))
        if txt_par:
            txt.append("  " + txt_par)
        if txt_dpar:
            txt.append("  " + txt_dpar)
        txt.append("")
    else:
        body.append(f"<div class='card'><h2>{L['dashboard']}{J('dashboard')}</h2><div class='warn'>{L['dash_none']}</div></div>")
        txt += [L["dash_none"], ""]

    sides_l, sides_r, learn = [], [], None
    if R:
        # ---------- state strip ----------
        def c(state, lab):
            return f"<td class='{state}'>{e(lab)}</td>"
        sk = {"below": "s-neg", "above": "s-pos", "inside": "s-mid", "TK<KJ": "s-neg", "TK>KJ": "s-pos", "TK=KJ": "s-mid",
              "red": "s-neg", "green": "s-pos", "Gyakuten": "s-neg", "Koten": "s-pos", "none": "s-mid"}
        rows = ""
        for tf in tfs:
            r = R[tf]
            ch = {"below": "s-neg", "above": "s-pos", "touching": "s-mid"}[r["chikou"]]
            san = L[r["sanyaku"]] + ((" " + JP[r["sanyaku"]]) if a.jp and r["sanyaku"] in JP else "")
            rows += (f"<tr><th>{tf}</th>" + c(sk[r["pos"]], L[r["pos"]]) + c(sk[r["tk"]], L[r["tk"]]) + c(ch, L["c_" + r["chikou"]])
                     + c(sk[r["fut_color"]], L[r["fut_color"]]) + c(sk[r["sanyaku"]], san) + "</tr>")
        jh = (lambda k: f" <span class='jp'>{JP[k]}</span>") if a.jp else (lambda k: "")
        body.append(f"<div class='card'><h2>{L['strip']}{J('strip')} <span class='note'>{L['strip_note']}</span></h2><table class='strip'>"
                    f"<tr><th></th><th>{L['h_kumo']}{jh('kumo')}</th><th>{L['h_tk']}{jh('tk')}</th><th>{L['h_chik']}{jh('chikou')}</th>"
                    f"<th>{L['h_fut']}{jh('future')}</th><th>{L['h_san']}{jh('sanyaku')}</th></tr>{rows}</table>"
                    f"<div class='note'>{L['strip_foot']}</div></div>")
        txt.append(f"{L['strip'].upper()} {L['strip_note']}")
        txt.append(f"  {'TF':<4}| {L['h_kumo']} | {L['h_tk']} | {L['h_chik']} | {L['h_fut']} | {L['h_san']}")
        for tf in tfs:
            r = R[tf]
            txt.append(f"  {tf:<4}| {L[r['pos']]} | {L[r['tk']]} | {L['c_' + r['chikou']]} | {L[r['fut_color']]} | {L[r['sanyaku']]}")
        txt.append("")

        # ---------- ladder ----------
        vals = [R[t][k] for t in tfs for k in ("close", "tenkan", "kijun", "kumo_top", "kumo_bot")]
        span = max(vals) - min(vals) or 1
        lo, hi = min(vals) - span * 0.05, max(vals) + span * 0.05
        Hh, pad, colw, x0a = 420, 20, 185, 66
        y = lambda p: pad + (hi - p) / (hi - lo) * (Hh - 2 * pad - 20)
        W = colw * len(tfs) + 160
        sv = [f"<svg viewBox='0 0 {W} {Hh}' class='ladder' role='img' aria-label='{L['ladder']}'>"]
        raw = span / 6
        mag = 10 ** math.floor(math.log10(raw))
        step = min(m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw)
        g0 = (lo // step + 1) * step
        while g0 < hi:
            sv.append(f"<line x1='60' x2='{colw * len(tfs) + 70}' y1='{y(g0):.1f}' y2='{y(g0):.1f}' class='grid'/>"
                      f"<text x='54' y='{y(g0) + 4:.1f}' class='ax'>{fp(g0) if step < 1 else f'{g0:,.0f}'}</text>")
            g0 += step
        for i, tf in enumerate(tfs):
            r = R[tf]
            x0 = x0a + i * colw
            sv.append(f"<text x='{x0 + colw / 2 - 20}' y='{Hh - 4}' class='tfl'>{tf}</text>")
            kt, kb = y(r["kumo_top"]), y(r["kumo_bot"])
            sv.append(f"<rect x='{x0 + 20}' y='{kt:.1f}' width='{colw - 80}' height='{max(kb - kt, 2):.1f}' class='kumo {r['kumo_color']}'/>")
            labs = [((kt + kb) / 2 + 4, "Kumo", "lbl")]
            for k, cls, nm in (("kijun", "kij", "Kijun"), ("tenkan", "ten", "Tenkan")):
                yy = y(r[k])
                sv.append(f"<line x1='{x0 + 10}' x2='{x0 + colw - 60}' y1='{yy:.1f}' y2='{yy:.1f}' class='{cls}'/>")
                labs.append((yy + 4, f"{nm} {fp(r[k])}", f"lbl {cls}t"))
            labs.sort()
            last = -99
            for ly, t, cl in labs:
                ly = max(ly, last + 12)
                last = ly
                sv.append(f"<text x='{x0 + colw - 56}' y='{ly:.1f}' class='{cl}'>{e(t)}</text>")
            yc = y(r["close"])
            sv.append(f"<circle cx='{x0 + colw / 2 - 20}' cy='{yc:.1f}' r='6' class='px'/>")
            sv.append(f"<text x='{x0 + colw / 2 - 20}' y='{yc + 20:.1f}' class='pxt' text-anchor='middle'>{fp(r['close'])}</text>")
        sv.append("</svg>")
        body.append(f"<div class='card'><h2>{L['ladder']}{J('ladder')}</h2><div class='lwrap'>{''.join(sv)}</div>"
                    f"<div class='legend'><span><i class='sw' style='background:var(--kij)'></i>{L['lg_kij']}</span>"
                    f"<span><i class='sw' style='background:var(--ten)'></i>{L['lg_ten']}</span>"
                    f"<span><i class='sw' style='background:var(--pos);opacity:.4'></i>{L['lg_kumo']}</span><span>● {L['lg_close']}</span></div></div>")

        # ---------- component reading ----------
        thin_tf = min(tfs, key=lambda t: R[t]["kumo_thick_pct"])
        thin = L["o_thin"].format(tf=thin_tf, v=f"{R[thin_tf]['kumo_thick_pct']:.2f}")
        mid_tf = tfs[len(tfs) // 2]
        tk_, kj_, _, dp_ = (I or {}).get("params", [9, 26, 52, 26])
        comp = [
            ("Kumo", "kumo", L["p_kumo"], L["o_kumo"].format(g=gtxt(group(R, tfs, lambda r: r["pos"]), L),
                                                             f=gtxt(group(R, tfs, lambda r: r["fut_color"]), L), thin=thin)),
            ("Tenkan-sen / Kijun-sen", "tk", L["p_tk"].format(t=tk_, k=kj_), L["o_tk"].format(g=gtxt(group(R, tfs, lambda r: r["tk"]), L), tf=mid_tf,
                                                                         a=fp(R[mid_tf]["kijun_prev"]), b=fp(R[mid_tf]["kijun"]))),
            ("Chikou Span", "chikou", L["p_chik"].format(d=dp_), L["o_chik"].format(d=dp_, g=gtxt(group(R, tfs, lambda r: "c_" + r["chikou"]), L))),
            ("Kijun-sen", "equilibrium", L["p_kij"], L["o_kij"].format(g=", ".join(f"{t} {pct(R[t]['dist_kijun_pct'], 2)}%" for t in tfs))),
        ]
        ct = (I or {}).get("chart_tf")
        if ct in R and "itto" in R[ct]:
            it = R[ct]["itto"]
            parts = ", ".join(f"{v:+d}" for v in it["components_live"].values())
            comp.append(("Itto Score", "dashboard", L["p_itto"].format(slope=inp["slope"], band=inp["band"], bandp=inp["band"] * 20, cut=inp["cut"], cutp=inp["cut"] * 20),
                         L["o_itto"].format(tf=ct, sc=it["score_live_pct"], parts=parts, zone=it["zone_live"], trend=it["trend_live"]), "itto"))
        body.append(f"<div class='card comp'><h2>{L['reading']}{J('reading')}</h2>" + "".join(
            f"<p><b>{x[0]}</b>{jh(x[1])}</p><p class='pr'><span class='tag'>{L[x[4]] if len(x) > 4 else L['classic']}</span>{e(x[2])}</p><p>{e(x[3])}</p>" for x in comp) + "</div>")
        txt.append(L["reading"].upper())
        for x in comp:
            txt += [f"* {x[0]}", f"  [{L[x[4]] if len(x) > 4 else L['classic']}] {x[2]}", f"  {x[3]}"]
        txt.append("")

        # ---------- state-change levels ----------
        def lvl_cell(r, k):
            v = r[k]
            return L["cl_above" if r["close"] < v else "cl_below"].format(v=fp(v))
        def kumo_cell(r):
            if r["pos"] == "below":
                return L["cl_above"].format(v=fp(r["kumo_bot"]))
            if r["pos"] == "above":
                return L["cl_below"].format(v=fp(r["kumo_top"]))
            return L["exit"].format(a=fp(r["kumo_top"]), b=fp(r["kumo_bot"]))
        lv_rows = [(tf, "Tenkan " + lvl_cell(R[tf], "tenkan"), "Kijun " + lvl_cell(R[tf], "kijun"), "Kumo " + kumo_cell(R[tf]))
                   for tf in sorted(tfs, key=tf_key, reverse=True)]
        body.append(f"<div class='card'><h2>{L['levels']}{J('levels')} <span class='note'>{L['levels_note']}</span></h2><table class='cells'>"
                    f"<tr><th></th><th>{L['h_mom']}</th><th>{L['h_eq']}</th><th>{L['h_kumo2']}</th></tr>"
                    + "".join(f"<tr><th>{a_}</th><td class='s-plain'>{e(b)}</td><td class='s-plain'>{e(c_)}</td><td class='s-plain'>{e(d)}</td></tr>"
                              for a_, b, c_, d in lv_rows) + "</table></div>")
        txt.append(f"{L['levels'].upper()} {L['levels_note']}")
        txt += [f"  {a_}: {b} | {c_} | {d}" for a_, b, c_, d in lv_rows]
        txt.append("")

        # ---------- two sides ----------
        neg = sum((R[t]["pos"] == "below") + (R[t]["tk"] == "TK<KJ") + (R[t]["chikou"] == "below") + (R[t]["fut_color"] == "red") for t in tfs)
        posn = sum((R[t]["pos"] == "above") + (R[t]["tk"] == "TK>KJ") + (R[t]["chikou"] == "above") + (R[t]["fut_color"] == "green") for t in tfs)
        weak_items, strong_items = [], []
        for key, fn, good in (("s_pos", lambda r: r["pos"], ("below", "above")), ("s_tk", lambda r: r["tk"], ("TK<KJ", "TK>KJ")),
                              ("s_chik", lambda r: "c_" + r["chikou"], ("c_below", "c_above")),
                              ("s_fut", lambda r: r["fut_color"], ("red", "green")), ("s_san", lambda r: r["sanyaku"], ("Gyakuten", "Koten"))):
            g = group(R, tfs, fn)
            for side, val in ((weak_items, good[0]), (strong_items, good[1])):
                if val in g:
                    side.append(L[key].format(s=L[val].lower() if key == "s_chik" else L[val], c=L[val], tfs=", ".join(g[val])))
        near = min(tfs, key=lambda t: abs(R[t]["dist_kijun_pct"]))
        watch = [L["w_near"].format(tf=near, v=f"{abs(R[near]['dist_kijun_pct']):.2f}")]
        far = max(tfs, key=lambda t: abs(R[t]["dist_kijun_pct"]))
        if abs(R[far]["dist_kijun_pct"]) >= 5:
            watch.append(L["w_far"].format(tf=far, v=f"{abs(R[far]['dist_kijun_pct']):.1f}"))
        thin_l = [f"{t} ({R[t]['kumo_thick_pct']:.2f}%)" for t in tfs if R[t]["kumo_thick_pct"] < 0.5]
        if thin_l:
            watch.append(L["w_thin"].format(tf=", ".join(thin_l)))
        for (cc, fc), ts in group(R, tfs, lambda r: (r["kumo_color"], r["fut_color"])).items():
            if cc != fc:
                watch.append(L["w_color"].format(tf=", ".join(ts), a=L[cc], b=L[fc]))
        for t in tfs:
            if R[t]["kijun_flat_bars"] >= 5:
                watch.append(L["w_flat"].format(tf=t, n=R[t]["kijun_flat_bars"], v=fp(R[t]["kijun"])))
        total = neg + posn or 1
        chop = bool(DV) and dict(DV.get("fields", [])).get("Zone", "").lower() == "chop"
        if not chop and (neg / total >= 0.7 or posn / total >= 0.7):
            titles = L["sides_dom"]
            sides_l = weak_items if neg >= posn else strong_items
            if DV:
                sides_l = [L["s_dash"].format(k=k, v=v) for k, v in DV.get("fields", []) if tone(v) != "s-plain"] + sides_l
            sides_r = watch
            cls = ("sa", "sb") if neg >= posn else ("sb", "sa")
            jj = ("weak", "strong") if neg >= posn else ("strong", "weak")
        else:
            titles = L["sides_mix"]
            sides_l, sides_r = weak_items, strong_items
            cls, jj = ("sa", "sb"), ("weak", "strong")
        li = lambda xs: "".join(f"<li>{e(x)}</li>" for x in xs) or f"<li>{L['nothing']}</li>"
        body.append(f"<div class='card two'><div class='card {cls[0]}' style='margin:0'><h2>{titles[0]}{J(jj[0])}</h2><ul>{li(sides_l)}</ul></div>"
                    f"<div class='card {cls[1]}' style='margin:0'><h2>{titles[1]}{J(jj[1])}</h2><ul>{li(sides_r)}</ul></div></div>")
        for t_, xs in zip(titles, (sides_l, sides_r)):
            txt.append(t_.upper())
            txt += [f"  - {x}" for x in xs] or [f"  - {L['nothing']}"]
            txt.append("")
        if titles is L["sides_mix"]:
            body.append(f"<div class='card'><h2>{L['sides_dom'][1]}{J('levels')}</h2><ul>{li(watch)}</ul></div>")
            txt.append(L["sides_dom"][1].upper())
            txt += [f"  - {x}" for x in watch]
            txt.append("")

        # ---------- learning note ----------
        if any(R[t]["future_twists"] > 0 or R[t]["kumo_color"] != R[t]["fut_color"] for t in tfs):
            learn, lj = L["n_twist"], "twist"
        elif len({R[t]["sanyaku"] for t in tfs}) == 1 and R[tfs[0]]["sanyaku"] != "none":
            learn, lj = L["n_sanyaku"], "sanyaku"
        elif any(R[t]["kijun_flat_bars"] >= 5 for t in tfs):
            learn, lj = L["n_flat"], "flat"
        else:
            learn, lj = L["n_eq"], "equilibrium"
        body.append(f"<div class='card'><h2>{L['learn']}: {learn[0]}{J(lj)}</h2>{e(learn[1])}</div>")
        txt += [f"{L['learn'].upper()}: {learn[0]}", learn[1], ""]

    body.append(f"<div class='disc'>{L['disc']}</div>")
    txt += ["-" * 60, L["disc_txt"]]
    fonts = "family=Inter:wght@400;600;700" + "" + ("&family=Noto+Serif+JP:wght@500;700" if a.jp else "")
    meta = L["meta"].format(asof=e(asof or "—"), gen=e(a.generated), lvl=lvl, lvl_txt=L["lvl"][lvl], p=params)
    seal = "<div class='seal'>一<br>目</div>" if a.jp else ""
    badge = f"<span class='badge'>{(I or {}).get('mode', 'quick').upper()} MODE</span>" if I else ""
    head = (f"<!doctype html><html lang='{a.lang}'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>Ichimoku Itto Read · {e(symbol)}</title><link href='https://fonts.googleapis.com/css2?{fonts}&display=swap' rel='stylesheet'>"
            f"<style>:root{{--font:'{L['font']}','Inter'}}{CSS}</style></head><body><div class='wrap'>{seal}"
            f"<div class='brand'>一刀流 ITTO-RYU · {L['brand']}{' · <span class=jpk>' + JP['full'] + '</span>' if a.jp else ''}</div>"
            f"<h1>{e(symbol)}{badge}</h1><div class='meta'>{meta}</div>")
    open(a.out_html, "w", encoding="utf-8").write(head + "".join(body) + "</div></body></html>")
    hdr = [f"ICHIMOKU ITTO READ · {symbol}", re.sub(r"<[^>]+>", "", meta), "=" * 60, ""]
    open(a.out_txt, "w", encoding="utf-8").write("\n".join(hdr + txt) + "\n")
    print(f"wrote {a.out_html} and {a.out_txt} (input level {lvl}, {len(tfs)} TFs)")


if __name__ == "__main__":
    main()
