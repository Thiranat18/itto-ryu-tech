---
name: ichimoku-itto-read-en
description: Read Ichimoku Itto and classic Ichimoku on every timeframe for a symbol (e.g. "ichimoku-itto-read-en BTCUSD") and report the state by principle as an English plain-text summary plus an HTML page. Works with the TradingView connector, CSV files or a chart screenshot. Describes state only, never buy/sell advice.
license: MPL-2.0
---

# ichimoku-itto-read-en (v0.3.2, English edition)

Companion skill for the TradingView indicator **Ichimoku Itto by [Itto-Ryu]**. Give it a symbol
and it rebuilds the Ichimoku Itto dashboard (Score, Zone, Kumo, the 1H/4H/D/W rows, Trend) plus
the classic Ichimoku components from price data, then explains the state by principle. The user
makes every decision. This skill never tells anyone to buy, sell, enter, exit, or where to put a
stop or target.

Everything the skill needs is in this folder. Python 3 standard library only; nothing is
downloaded at run time.

```
SKILL.md
config.yaml                  defaults: language, Japanese accents, chart TF, preset, bars, symbol defaults
references/principles.md     Classic + Itto principles (Itto rules mirror the indicator source)
references/glossary.md       terms in English / Japanese
scripts/ohlcv_to_data.py     TradingView OHLCV results -> data.json
scripts/compute.py           data.json / CSV -> ichi.json (classic Ichimoku + Itto dashboard per TF)
scripts/parse_tables.py      dashboard rows read from a chart or image -> dashboard.json (optional)
scripts/render.py            ichi.json (+ dashboard.json) -> report.html + report.txt
scripts/lint_report.py       blocks advice language before anything is shown
```

## 1. Understand the request

`ichimoku-itto-read-en <SYMBOL> [chart TF] [preset] [quick|full]` — e.g. `ichimoku-itto-read-en BTCUSD`,
`ichimoku-itto-read-en BTCUSD crypto full`, `ichimoku-itto-read-en NYSE:BB 1D`. Plain words work too:
"in detail" / "with Kumo thick/thin" = full; "quick" = quick.
**Language: English only.** This edition writes the HTML report, the text report and the chat summary in
English, whatever language the user writes in or prefers elsewhere. Always run `render.py` with `--lang en`
(it is the only option).
Other defaults come from `config.yaml` (mode `quick`, chart TF `1D`, preset `Classic`), or from
the user's project instructions / memory if they set them. If the user says their Ichimoku Itto uses
another preset or other inputs, use the same values, otherwise the numbers will not match their chart.

**Modes.** Both give the same Score, Zone, Trend, TF rows, Aligned and classic components.
- `quick` (default): fewer bars, lower cost. Kumo Thin/Normal/Thick shows "— (full mode)"; the "last
  marks" and magnets only look back over the bars fetched.
- `full`: every dashboard field, including Kumo Thin/Normal/Thick (percent rank over 252 bars) and marks from ~340 bars.

| Preset | quick: every TF | full: chart TF / other TFs |
|---|---|---|
| Classic 9/26/52/26 | 90 bars | 340 / 90 |
| 5-Day Week 7/22/44/22 | 90 bars | 340 / 90 |
| Crypto 20/60/120/30 | 160 bars | 410 / 160 |

**First run.** Do not ask setup questions before the first report (except an ambiguous symbol). Run
with the defaults; the report shows a QUICK MODE / FULL MODE badge next to the symbol and opens with a
highlighted box whose first line names the mode and how to switch (`ichimoku-itto-read-en <SYMBOL> full` for everything), asks whether the preset matches the user's chart, and shows
the exact commands to change them. In the chat reply, repeat the mode line in one sentence. If the user
answers with different settings, run again right away.

## 2. Pick the input route (check silently, tell the user in one line)

| Route | When | What happens |
|---|---|---|
| **A. TradingView connector** (recommended) | an OHLCV tool is available (names like `get-ohlcv`, `search-symbols`) | fetch bars, compute everything |
| **B. CSV** | the user attaches TradingView CSV exports | compute everything |
| **C. Screenshot** | only an image of the chart with the Ichimoku Itto dashboard | report the dashboard as read from the image |
| **+ Chart read** (optional) | a TradingView desktop MCP that can read Pine tables, with Ichimoku Itto on a chart of the same symbol | read the real dashboard and run the dashboard parity check |

If none is available, say which one would work (connect TradingView, attach CSV, or a screenshot)
and stop.

## 3. Route A — TradingView connector

1. **Resolve the symbol.** If it has no exchange prefix, search for it. Prefer `config.yaml` ->
   `symbol_defaults`; if several exchanges fit and no default exists, ask the user once which one
   (and suggest saving it in `symbol_defaults`).
2. **Fetch OHLCV** for `60`, `240`, `1D`, `1W` with `format: columns`, bar counts from the mode table above.
3. **Save each result to a file exactly as returned** (`h1.json`, `h4.json`, `d.json`, `w.json`).
   If the host already saved the tool result to a file, copy that file. If you must write it from
   an inline result, copy the whole JSON verbatim, never retype selected numbers.
4. `python3 -I scripts/ohlcv_to_data.py --symbol <SYMBOL> 1H=h1.json 4H=h4.json 1D=d.json 1W=w.json --out data.json`
5. `python3 -I scripts/compute.py --data data.json --chart-tf 1D --preset Classic --mode quick --out ichi.json`
   (add `--slope --cut --band --flat --keep` only if the user changed those indicator inputs).
   The last bar of each TF counts as forming until its period has ended: dashboard TF rows use the
   latest **closed** bar (like the indicator); Score, Zone, Kumo and Trend use the live bar.

## 4. Routes B and C

- **B:** `python3 -I scripts/compute.py --csv 1D=daily.csv --csv 4H=h4.csv ... --symbol X --chart-tf 1D --out ichi.json`
- **C:** transcribe every dashboard row from the image exactly as shown into `raw.json`
  (`rows`, `chart_tf`, `symbol`, `asof`, `source`, `input_level: 0`), then
  `python3 -I scripts/parse_tables.py raw.json --out dashboard.json`. Say the values come from an
  image and ask the user to confirm the key numbers.

## 5. Optional chart read (desktop MCP)

Read only. Never change symbol, timeframe, layout, panes or indicators; never open, edit, compile
or save a Pine script; never create alerts or drawings. If the chart shows a different symbol, skip
this step. Otherwise call the Pine-tables tool filtered to `Ichimoku Itto` and the study-values
tool, write the rows exactly as returned into `raw.json` (`input_level: 2`), and run
`parse_tables.py`. `render.py` then compares the real dashboard with the computed one.

## 6. Render, check, deliver

1. `python3 -I scripts/render.py --ichi ichi.json [--dashboard dashboard.json] --lang en --jp --generated YYYY-MM-DD --out-html <SYMBOL>_ichimoku_itto_read.html --out-txt <SYMBOL>_ichimoku_itto_read.txt`
2. Parity lines: if either says ⚠, check symbol, preset, inputs and data before showing the report,
   and tell the user what differed.
3. `python3 -I scripts/lint_report.py <html> <txt>` must PASS; if not, fix wording and render again.
4. Open the HTML once in a headless browser if available and look at it; otherwise skip.
5. Reply with the plain-text summary, starting with the "Settings used" line and its question,
   then Summary, dashboard, state-change levels, the two sides, learning note, disclaimer. Deliver the HTML as an artifact when the host supports that,
   otherwise as a file. The user can print it to PDF from the browser.

## 7. Guardrails (every run)

- Describe state by principle. No buy/sell, entry, exit, stop, target, "should", or forecasts.
  State-change levels say "a close above / below X changes component Y"; the report labels them
  as describing state, not trade levels.
- If the user asks "should I buy/sell?", give the principle reading and hand the decision back in
  one sentence.
- Tag every explanation **Classic** or **Itto** (only what `references/principles.md` defines).
  Never attribute a statement to Hosoda or any author unless `principles.md` cites it.
- Computed dashboard values are labelled as computed by the skill; values read from a chart or an
  image are labelled as such.
- Keep both sides of the reading equal in weight: what supports the current state, and what to watch
  for a change of state.
- Always end with the disclaimer that `render.py` adds.
