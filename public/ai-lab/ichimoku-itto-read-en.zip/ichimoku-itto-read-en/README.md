# ichimoku-itto-read-en

**A Claude skill that reads Ichimoku the Itto-ryu way.** Type a symbol and Claude rebuilds the
**Ichimoku Itto by [Itto-Ryu]** dashboard from price data on 1H, 4H, 1D and 1W, adds the classic
Ichimoku components, and explains what the chart is showing in an English report
(a chat summary plus an HTML page you can open, keep, or print to PDF).

It describes state only. It never tells you to buy or sell, and it never gives entries, stops or targets.
You make every decision.

```
ichimoku-itto-read-en BTCUSD
```

---

## Contents

1. [What you get](#1-what-you-get)
2. [Requirements](#2-requirements)
3. [Install](#3-install)
4. [First run](#4-first-run)
5. [Commands](#5-commands)
6. [Quick mode and full mode](#6-quick-mode-and-full-mode)
7. [Match the skill to your chart](#7-match-the-skill-to-your-chart)
8. [Where the data comes from](#8-where-the-data-comes-from)
9. [How to read the report](#9-how-to-read-the-report)
10. [Settings file](#10-settings-file)
11. [Troubleshooting](#11-troubleshooting)
12. [FAQ](#12-faq)
13. [For developers](#13-for-developers)
14. [License and disclaimer](#14-license-and-disclaimer)

---

## 1. What you get

| | |
|---|---|
| **Ichimoku Itto dashboard** | Score (−100% to +100%), Zone (Trending / Chop), Kumo (Thin / Normal / Thick), the 1H / 4H / D / W rows with Score and Aligned, and the Trend label. The same rules as the indicator, computed by the skill. |
| **Score breakdown** | The five checks behind the Score: price vs Kumo, Tenkan vs Kijun, Chikou, future Kumo colour, Kijun slope. |
| **Classic Ichimoku on every timeframe** | Price vs Kumo, Tenkan vs Kijun, Chikou, future Kumo, Sanyaku (三役). |
| **Recent marks** | When the last Strong Up / Strong Down and 3/3 Aligned marks appeared, and the Equilibrium Magnets (flat Kijun / Span B levels). |
| **State-change levels** | The prices where a component would change state, e.g. "a close above X puts price above the Kumo". These describe state, not trade levels. |
| **Two sides, equal weight** | What supports the current state, and what to watch for a change of state. |
| **Learning note** | One principle explained in plain words, tagged **Classic** or **Itto**. |
| **HTML report** | A clean page with a price ladder and a state strip. Open it in any browser; use the browser's Print → Save as PDF if you want a PDF. |

Original Japanese terms (雲 Kumo, 転換線 Tenkan, 三役 Sanyaku …) appear next to the English names. You can turn them off.

## 2. Requirements

- **Claude** on any plan that supports Skills (web, desktop or mobile), or **Claude Code**.
- **Code execution turned on** in Claude. Skills run small Python scripts.
- **One way to get price data** (see [section 8](#8-where-the-data-comes-from)). The easiest is the
  **TradingView connector** in Claude. With it, you do not need to open TradingView at all.

You do **not** need to install Python packages, API keys or anything else. The scripts use the
Python standard library only and download nothing while they run.

## 3. Install

Download `ichimoku-itto-read-en.zip` from the **Releases** page of this repository.

### Claude (web / desktop)

1. **Settings → Capabilities**: turn on **Code execution and file creation**
   (in newer layouts: **Create and edit files**).
2. **Customize → Skills** → **+** → **Create skill** → **Upload a skill**.
3. Choose `ichimoku-itto-read-en.zip`. Do not unzip it first.
4. Make sure the skill is toggled **on**.

Team / Enterprise: an owner must allow **Skills** and **Code execution** in the organization settings first.
See Anthropic's guide: [Use Skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude).

### Claude Code

Unzip and copy the folder to your personal skills folder:

```
~/.claude/skills/ichimoku-itto-read-en/SKILL.md
```

### Update to a new version

Remove the old skill, then upload the new zip (or replace the folder in Claude Code).

## 4. First run

1. Connect the **TradingView connector** in Claude (recommended), or have a CSV / screenshot ready.
2. Start a new chat and type:

    ```
    ichimoku-itto-read-en XAUUSD
    ```

3. Claude fetches 1H, 4H, 1D and 1W bars, runs the scripts and replies with the summary and the HTML report.

The skill does not ask setup questions first. It runs with the defaults (**Quick mode**, **Classic
preset 9/26/52/26**, chart timeframe **1D**). The top of every report shows a **QUICK MODE** or **FULL
MODE** badge and a highlighted box with the settings used and the exact commands to change them.

If the symbol exists on several exchanges (for example `BTCUSD`), Claude asks once which one you mean.

## 5. Commands

```
ichimoku-itto-read-en <SYMBOL> [chart TF] [preset] [quick | full]
```

| Example | What it does |
|---|---|
| `ichimoku-itto-read-en BTCUSD` | Defaults: quick, Classic, 1D |
| `ichimoku-itto-read-en OANDA:XAUUSD full` | Every field, including Kumo Thin / Normal / Thick |
| `ichimoku-itto-read-en BTCUSD crypto` | Crypto preset 20/60/120/30 |
| `ichimoku-itto-read-en NYSE:BB 5-day` | 5-Day Week preset 7/22/44/22 |
| `ichimoku-itto-read-en EURUSD 4H` | Score / Zone / Kumo / Trend from the 4H live bar |

Plain words work too: "read gold in detail", "quick look at BTC".
Use an exchange prefix (`NASDAQ:AAPL`, `OANDA:XAUUSD`) to skip the exchange question.

## 6. Quick mode and full mode

Both modes give the same Score, Zone, Trend, timeframe rows, Aligned and classic components.

| | **Quick** (default) | **Full** |
|---|---|---|
| Bars fetched | 90 per timeframe (Crypto preset: 160) | 340 on the chart timeframe (Crypto: 410) |
| Kumo Thin / Normal / Thick | shows "— (full mode)" | yes (percent rank over 252 bars, like the indicator) |
| Last Strong / Aligned marks, magnets | within the bars fetched | within ~340 bars |
| Speed and usage | lighter | heavier |

Add `full` to any command for a full read.

## 7. Match the skill to your chart

The skill computes the dashboard from price data, so it must use the **same preset and inputs** as your
Ichimoku Itto on TradingView. If they differ, the numbers will differ.

| Preset | Periods (Tenkan / Kijun / Span B / displacement) | Typical use |
|---|---|---|
| Classic | 9 / 26 / 52 / 26 | default |
| 5-Day Week | 7 / 22 / 44 / 22 | markets that trade 5 days a week |
| Crypto | 20 / 60 / 120 / 30 | 24/7 markets |

Changed other indicator inputs (Kijun slope bars, Strong threshold, Chop band, magnet settings)?
Put the same values in `config.yaml` → `indicator_inputs`, or tell Claude in the request.

**Live bar vs closed bar.** Like the indicator, the 1H / 4H / D / W rows use the latest **closed** bar of each
timeframe, while Score, Zone, Kumo and Trend use the **live** bar of the chart timeframe. Readings taken while a
bar is still forming can change before it closes. When the market is closed, the skill detects it and treats the
last bar as closed.

## 8. Where the data comes from

The skill picks the best route it can find and tells you which one it used.

| Route | You need | You get |
|---|---|---|
| **A. TradingView connector** (recommended) | The TradingView connector added in Claude | Everything, computed from OHLCV. No need to open TradingView. |
| **B. CSV** | TradingView chart exports (1H, 4H, 1D, 1W) attached to the chat | Everything, from your files |
| **C. Screenshot** | A chart image with the Ichimoku Itto dashboard visible | The dashboard as read from the image. Claude asks you to confirm the key numbers. |
| **+ Chart read** (advanced) | A TradingView desktop MCP that can read Pine tables, with Ichimoku Itto on the chart | The real dashboard plus a **parity check** against the computed one |

When the skill reads a chart, it only reads. It never changes your symbol, timeframe, layout or indicators, and
never opens or edits a Pine script, alert or drawing.

## 9. How to read the report

The HTML report and the chat summary follow the same order.

| Section | What it tells you |
|---|---|
| **Mode badge + settings box** | Quick or Full, preset, chart timeframe, data date, and commands to change them. Check this first. |
| **Summary 総括** | Two or three lines: do the timeframes agree, and in which direction. |
| **Ichimoku Itto dashboard** | The indicator's table, labelled *computed by the skill* or *read from chart / image*. |
| **Score breakdown** | Which of the five checks are +1, −1 or 0. |
| **Marks and magnets** | Last Strong Up / Down and 3/3 Aligned marks; flat Kijun / Span B levels. |
| **State strip 状態** | One row per timeframe: Kumo, Tenkan/Kijun, Chikou, future Kumo, Sanyaku. |
| **Price ladder 水準** | Close, Tenkan, Kijun and Kumo edges on one scale. |
| **Component reading 読み** | Each component explained, tagged Classic or Itto. |
| **Change points 変化点** | Prices where a component would change state. Not trade levels. |
| **Two sides 陽 / 陰** | What supports the current state and what would change it, equal weight. When the Zone is Chop or timeframes disagree, this becomes "What to watch". |
| **Learning 学び** | One principle in plain words. |
| **Disclaimer** | Always at the end. |

Tags: **Classic** = standard Ichimoku Kinkō Hyō knowledge. **Itto** = the Ichimoku Itto rules (Score, Zone,
Kumo class, Aligned, Trend, marks, magnets), taken from the open-source indicator code.
Details: [`references/principles.md`](references/principles.md) · terms: [`references/glossary.md`](references/glossary.md).

## 10. Settings file

`config.yaml` holds your defaults. Edit it before zipping, or tell Claude the setting in the request.

```yaml
jp_accents: true          # Japanese terms next to English names
mode: quick               # quick | full
chart_tf: 1D              # timeframe for Score / Zone / Kumo / Trend
dashboard_tfs: [1H, 4H, 1D, 1W]
preset: Classic           # Classic | 5-Day Week | Crypto
indicator_inputs: {kijun_slope: 5, strong_threshold: 4, chop_band: 1, magnet_flat_bars: 8, magnet_keep: 6}
symbol_defaults:          # skip the exchange question
  XAUUSD: OANDA:XAUUSD
  BTCUSD: BITSTAMP:BTCUSD
html_report: true
```

## 11. Troubleshooting

| Problem | What to do |
|---|---|
| The skill does not start | Check it is toggled on in **Customize → Skills** and that code execution is on. Start a new chat. |
| "No data route available" | Add the TradingView connector, or attach CSV exports, or a screenshot. |
| Numbers differ from my chart | Same symbol and exchange? Same preset and inputs? Is the bar still forming? Run with `full` to compare Kumo class. |
| ⚠ parity line in the report | The real dashboard and the computed one differ. The report lists which values; check symbol, preset and inputs. |
| Kumo shows "— (full mode)" | Expected in Quick mode. Add `full`. |
| Upload error | Upload the zip as downloaded; do not rename the folder inside it. |

## 12. FAQ

**Does it give buy or sell signals?** No. It reads state by principle. Every report ends with a disclaimer, and a
built-in check blocks advice words before anything is shown.

**Do I need TradingView Premium?** No. The connector route only needs price data, and the indicator itself is free.

**Do I need the indicator on my chart?** Not for routes A and B. The skill computes the dashboard itself. Add the
indicator on TradingView to see it visually and to compare.

**Which markets?** Anything with OHLCV data: forex, metals, crypto, stocks, indices, futures.

**Is my data sent anywhere?** The scripts run inside Claude's code environment and make no network calls.
Price data comes only from the route you use.

**Another language?** This edition is English only.

## 13. For developers

```
SKILL.md                     instructions Claude follows
config.yaml                  defaults
references/principles.md     Classic + Itto principles (Itto rules mirror the indicator source)
references/glossary.md       English / Japanese terms
scripts/ohlcv_to_data.py     TradingView OHLCV results -> data.json
scripts/compute.py           data.json / CSV -> ichi.json (classic + Itto dashboard per timeframe)
scripts/parse_tables.py      dashboard rows from a chart or image -> dashboard.json
scripts/render.py            ichi.json (+ dashboard.json) -> HTML + text report
scripts/lint_report.py       blocks advice language
tests/selftest.py            end-to-end test on synthetic data
examples/                    sample report and dashboard
```

Run the test: `python3 tests/selftest.py`. Issues and pull requests are welcome. Please keep the rule:
**describe state, never advise.**

## 14. License and disclaimer

MPL-2.0, the same license as the Ichimoku Itto indicator.

This skill is an educational tool. It describes the state of technical indicators by principle and is not
investment advice, a recommendation, or a solicitation to buy or sell any instrument. Markets carry risk;
past behaviour of an indicator does not guarantee future results. You are responsible for your own decisions.

一刀流 ITTO RYU TECH · ittoryutech.com
